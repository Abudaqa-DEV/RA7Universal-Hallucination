--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/custom.lua - YOUR integrations. Everything here is optional: delete what you do not need.

    This file is loaded on BOTH sides (client and server). Define only the functions you use.
    The sections below say which side calls them.
]]

Custom = Custom or {}

-- ----------------------------------------------------------------------
-- 1) Framework  (Config.General.Framework = 'custom')
-- ----------------------------------------------------------------------
-- Custom.Framework = {
--     -- SERVER
--     GetIdentifier = function(src) return 'my-character-id' end,
--     GetJob = function(src) return 'police', true end,          -- job name, on duty
--     IsBusyServer = function(src) return false end,             -- dead / cuffed / jailed
--     RegisterLoadEventsServer = function(onLoaded, onUnload)
--         AddEventHandler('myframework:playerLoaded', function(src) onLoaded(src) end)
--         AddEventHandler('myframework:playerLeft', function(src) onUnload(src) end)
--     end,
--     -- CLIENT
--     IsPlayerLoaded = function() return true end,
--     IsBusy = function() return false end,
--     RegisterLoadEventsClient = function(onLoaded, onUnload) end,
-- }

-- ----------------------------------------------------------------------
-- 2) Notifications (CLIENT)  (Config.Notifications.Provider = 'custom')
-- ----------------------------------------------------------------------
-- Custom.Notify = function(message, ntype, duration)  -- ntype: inform | success | warning | error
--     exports['my_notify']:Send(message, ntype, duration)
-- end

-- ----------------------------------------------------------------------
-- 3) Clothing / appearance (CLIENT)  (Config.Appearance.Provider = 'custom')
-- ----------------------------------------------------------------------
-- Used only by /hswap (real look swap). Doubles use ClonePed and need nothing here.
-- Custom.Appearance = {
--     Get   = function(ped) return exports['my_clothing']:getPedAppearance(ped) end,   -- must return a table
--     Apply = function(ped, data) exports['my_clothing']:setPedAppearance(ped, data) return true end,
-- }

-- ----------------------------------------------------------------------
-- 4) Inventory (SERVER)  (Config.Swap.Items.Provider = 'custom')
-- ----------------------------------------------------------------------
-- Custom.Inventory = {
--     Count  = function(src, name) return 0 end,
--     Remove = function(src, name, count) return true end,   -- must return true only if it really removed
--     Add    = function(src, name, count) return true end,   -- must return true only if it really added
-- }

-- ----------------------------------------------------------------------
-- 5) Voice link (SERVER)  (Config.Director.Voice.Provider = 'custom')
-- ----------------------------------------------------------------------
-- Called so the target hears the controller as if the imaginary person was talking.
-- Custom.Voice = {
--     Link   = function(controllerSrc, targetSrc, channel) end,
--     Unlink = function(controllerSrc, targetSrc, channel) end,
-- }
-- CLIENT side (optional): Custom.Voice.SpeakAs(targetServerId, range)  and  Custom.Voice.Isolate(controllerServerId or nil)
--   Isolate: the local player's microphone is heard ONLY by that player (nil = back to normal).

-- ----------------------------------------------------------------------
-- 6) Hooks (SERVER) - called by the system
-- ----------------------------------------------------------------------
-- ----------------------------------------------------------------------
-- 7) Takeover inventory lock (CLIENT)  (Config.Takeover.Controller.BlockInventory)
-- ----------------------------------------------------------------------
-- ox_inventory and qb-inventory are locked automatically (state bags invBusy / inv_busy + closing the open inventory).
-- For any other inventory: close it and forbid opening it while `on` is true.
-- Custom.Takeover = {
--     Inventory = function(on)
--         LocalPlayer.state:set('myInvBlocked', on, false)       -- or exports['my_inventory']:setLocked(on)
--         if on then exports['my_inventory']:close() end
--     end,
-- }

-- Custom.OnStarted    = function(src, sid, hallucinationType) end
-- Custom.OnEnded      = function(src, sid, hallucinationType, reason) end
-- Custom.OnSuspicious = function(src, reason) end
