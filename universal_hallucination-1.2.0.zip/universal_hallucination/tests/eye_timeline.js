// node tests/eye_timeline.js : the eye "sleep" pattern must open, blink, close COMPLETELY, stay shut, then open until the screen is fully back
global.window = {};
require('../html/eye.js');
const E = window.UH_EYE;
let bad = 0;
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) bad++; };
const tl = E.timeline({ pattern: 'sleep', seconds: 15, seed: 3 });
const at = t => E.openAt(tl, t);
let maxBefore = 0, closedFor = 0, minV = 1, openedAfterClose = false, seenClosed = false;
for (let t = 0; t <= tl.total; t += 0.02) {
  const v = at(t); minV = Math.min(minV, v);
  if (v < 0.02) { closedFor += 0.02; seenClosed = true; }
  if (seenClosed && v > 0.95) openedAfterClose = true;
  maxBefore = Math.max(maxBefore, v);
}
ok(minV < 0.01, 'the eye closes completely');
ok(closedFor >= 2.2, 'it stays shut for a while (' + closedFor.toFixed(1) + ' s)');
ok(openedAfterClose, 'it opens again until the whole screen is back');
ok(at(tl.total) > 0.99, 'it ends fully open');
let blinks = 0, prev = at(0), going = false;
for (let t = 0; t <= tl.total; t += 0.02) { const v = at(t); if (v < prev && v > 0.1 && !going) going = true; prev = v; }
ok(tl.total >= 6, 'length ' + tl.total.toFixed(1) + ' s');
for (const p of ['blink', 'wake', 'heavy', 'close', 'stare']) {
  const t2 = E.timeline({ pattern: p, seconds: 8, seed: 3, blinks: 2 });
  ok(E.openAt(t2, t2.total) > 0.99, "pattern '" + p + "' ends fully open");
}
process.exit(bad ? 1 : 0);
