-- Universal Hallucination - CLIENT logic test (fake game world, virtual clock).
-- Every hallucination type runs through the real engine; the test checks that nothing leaks (peds, timecycle,
-- shake, time scale, NUI overlays), that fake gunfire can never hurt, and that stopping cleans up at once.
local ROOT = os.getenv('UP_ROOT') or './'

local vms, threads = 0, {}
function GetGameTimer() return vms end
function GetCurrentResourceName() return 'universal_hallucination' end
function IsDuplicityVersion() return false end
function CreateThread(fn) threads[#threads + 1] = { co = coroutine.create(fn), wake = 0 } end
function Wait(ms) coroutine.yield(ms) end
function SetTimeout(ms, fn) CreateThread(function() Wait(ms) fn() end) end

-- ---------------- world ----------------
local world = { peds = {}, nextId = 100, player = { x = 0, y = 0, z = 30, h = 0, dead = false, vehicle = false }, other = { x = 5, y = 5, z = 30 } }
local called, undefinedNatives = {}, {}
local nui, serverEvents, handlers, nuiCallbacks = {}, {}, {}, {}
local state = { timecycle = nil, shake = nil, timeScale = 1.0, postfx = {}, frozen = false, camActive = false, focus = nil, controls = {}, lights = false, ctl = {} }
local bullets, weapons = {}, {}
local created, deleted = 0, 0
local pressed, held = {}, {}

local function V(x, y, z) return { x = x, y = y, z = z } end
function vec3(x, y, z) return V(x, y, z) end
function joaat(s) local h = 5381 for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end return h end
GetHashKey = joaat

local function stepWorld(dt)
    for id, p in pairs(world.peds) do
        if p.goal then
            local dx, dy = p.goal.x - p.x, p.goal.y - p.y
            local d = math.sqrt(dx * dx + dy * dy)
            if d > 0.2 then
                local sp = 1.6 * (p.goalSpeed or 1.0) * dt
                p.x, p.y = p.x + dx / d * math.min(sp, d), p.y + dy / d * math.min(sp, d)
            end
        end
    end
end

local natives = {
    PlayerPedId = function() return 1 end, PlayerId = function() return 0 end,
    NetworkIsPlayerActive = function() return true end,
    GetEntityCoords = function(e) if e == 1 then local p = world.player; return V(p.x, p.y, p.z) end
        if e == 2 then return V(world.other.x, world.other.y, world.other.z) end
        local p = world.peds[e]; return V(p.x, p.y, p.z) end,
    GetEntityHeading = function(e) if e == 1 then return world.player.h end return 0.0 end,
    GetGameplayCamRot = function() return V(0, 0, world.player.h) end,
    IsModelInCdimage = function(h) return true end, IsModelValid = function() return true end,
    HasModelLoaded = function() return true end, HasClipSetLoaded = function() return true end, HasAnimDictLoaded = function() return true end,
    HasWeaponAssetLoaded = function() return true end,
    CreatePed = function(_, hash, x, y, z, h, net) assert(net == false, 'CreatePed must be local (isNetwork=false)')
        world.nextId = world.nextId + 1; world.peds[world.nextId] = { x = x, y = y, z = z, alpha = 255, hash = hash }; created = created + 1; return world.nextId end,
    ClonePed = function(src, net) assert(net == false, 'ClonePed must be local')
        world.nextId = world.nextId + 1; world.peds[world.nextId] = { x = 0, y = 0, z = 30, alpha = 255, clone = true }; created = created + 1; return world.nextId end,
    DoesEntityExist = function(e) return e == 1 or e == 2 or world.peds[e] ~= nil end,
    DeleteEntity = function(e) if world.peds[e] then world.peds[e] = nil; deleted = deleted + 1 end end,
    SetEntityCoordsNoOffset = function(e, x, y, z) local p = world.peds[e]; if p then p.x, p.y, p.z = x, y, z end end,
    SetEntityAlpha = function(e, a) if world.peds[e] then world.peds[e].alpha = a end end,
    ResetEntityAlpha = function(e) if world.peds[e] then world.peds[e].alpha = 255 end end,
    GetEntityAlpha = function(e) return world.peds[e] and world.peds[e].alpha or 255 end,
    GetGroundZFor_3dCoord = function(x, y, z) return true, 30.0 end,
    GetInteriorFromEntity = function() return 0 end,
    IsPedInAnyVehicle = function() return world.player.vehicle end,
    IsPedDeadOrDying = function() return world.player.dead end,
    HasEntityClearLosToEntity = function() return true end,
    GetPedBoneCoords = function(e) local c = (e == 1) and world.player or world.peds[e] or world.player; return V(c.x, c.y, (c.z or 30) + 0.6) end,
    GetScreenCoordFromWorldCoord = function() return true, 0.5, 0.4 end,
    GetEntitySpeed = function() return 0.0 end,
    IsPedArmed = function() return true end, IsPlayerFreeAiming = function() return true end, IsPedMale = function() return true end,
    GetGameplayCamRelativeHeading = function() return 0.0 end, GetGameplayCamRelativePitch = function() return 0.0 end,
    GetPlayerFromServerId = function(id) if id == 7 then return 7 end return -1 end,
    GetPlayerPed = function(pl) if pl == 7 then return 2 end return 1 end,
    GetActivePlayers = function() return { 0, 7 } end,
    GetVehiclePedIsIn = function() return 0 end, GetPedInVehicleSeat = function() return 0 end,
    IsControlJustPressed = function(_, c) return pressed[c] == true end, IsDisabledControlJustPressed = function(_, c) return pressed[c] == true end,
    IsControlPressed = function(_, c) return held[c] == true end, IsDisabledControlPressed = function(_, c) return held[c] == true end,
    GetFinalRenderedCamCoord = function() return V(1, 2, 3) end, GetFinalRenderedCamRot = function() return V(0, 0, 90) end, GetFinalRenderedCamFov = function() return 50.0 end,
    CreateCam = function() return 55 end,
    GetEntityModel = function() return 1234 end,
    GetResourceKvpString = function() return nil end, SetResourceKvp = function() end,
    GetResourceState = function() return 'missing' end,
    GetPlayerName = function() return 'Test' end,
    IsPlayerDead = function() return world.player.dead end,
    -- state tracking natives
    SetTimecycleModifier = function(n) state.timecycle = n end, ClearTimecycleModifier = function() state.timecycle = nil end,
    SetTimecycleModifierStrength = function() end,
    ShakeGameplayCam = function(n, a) state.shake = { n, a } end, StopGameplayCamShaking = function() state.shake = nil end,
    SetTimeScale = function(v) state.timeScale = v end,
    AnimpostfxPlay = function(n) state.postfx[n] = true end, AnimpostfxStop = function(n) state.postfx[n] = nil end,
    FreezeEntityPosition = function(e, f) if e == 1 then state.frozen = f end end,
    RenderScriptCams = function(on) state.camActive = on end,
    SetNuiFocus = function(a, b) state.focus = a end,
    SendNUIMessage = function(m) nui[#nui + 1] = m end,
    RegisterNUICallback = function(n, fn) nuiCallbacks[n] = fn end,
    TriggerServerEvent = function(n, ...) serverEvents[#serverEvents + 1] = { name = n, args = { ... } } end,
    RegisterNetEvent = function(n, fn) if fn then handlers[n] = fn end end,
    AddEventHandler = function() end, RegisterCommand = function() end, RegisterKeyMapping = function() end,
    TaskGoStraightToCoord = function(e, x, y, z, sp) if world.peds[e] then world.peds[e].goal = V(x, y, z); world.peds[e].goalSpeed = sp end end,
    TaskFollowToOffsetOfEntity = function(e, t, ox, oy) if world.peds[e] then world.peds[e].goal = V(world.player.x + ox, world.player.y + oy, 30); world.peds[e].goalSpeed = 1 end end,
    ClearPedTasks = function(e) if world.peds[e] then world.peds[e].goal = nil end end,
    TaskStandStill = function(e) if world.peds[e] then world.peds[e].goal = nil end end,
    GiveWeaponToPed = function(ped, hash, ammo) weapons[#weapons + 1] = { hash = hash, ammo = ammo } end,
    ShootSingleBulletBetweenCoords = function(x1, y1, z1, x2, y2, z2, damage) bullets[#bullets + 1] = { damage = damage, from = V(x1, y1, z1), to = V(x2, y2, z2) } end,
    SetArtificialLightsState = function(v) state.lights = v end,
    SetPlayerInvisibleLocally = function() end,
    SetCurrentPedWeapon = function(e, h) state.weaponSet = h end,
    DisableControlAction = function(_, c, d) state.ctl[c] = d end,
    DisablePlayerFiring = function() state.firingOff = true end,
    SetLocalPlayerAsGhost = function(v) state.ghost = v end,
    PlayerId = function() return 0 end,
    PlayerId_ = nil,
}
for k, v in pairs(natives) do if v then _G[k] = v end end
rawset(_G, 'json', { encode = function(t) return '{}' end, decode = function() return {} end })
rawset(_G, 'Locales', {}); rawset(_G, 'LocaleMeta', {}); rawset(_G, 'Custom', {})
rawset(_G, 'exports', setmetatable({}, { __call = function() end, __index = function() return {} end }))
-- Any other PascalCase global is treated as a game native that returns nothing (and is listed at the end for a typo review).
setmetatable(_G, { __index = function(_, k)
    if type(k) == 'string' and k:match('^[A-Z]') and not k:match('^[A-Z][a-z]+$') or (type(k) == 'string' and k:match('^[A-Z][A-Za-z0-9_]+$') and k:match('[A-Z].*[a-z]') and #k > 6) then
        undefinedNatives[k] = true
        local def = nil
        if k:match('^Has.*Loaded$') then def = true end
        return function() return def end
    end
    error('undefined global "' .. tostring(k) .. '"', 2)
end })

dofile(ROOT .. 'config.lua')
Config.General.Framework = 'standalone'
Config.General.PrintBanner = false
Config.General.Language = 'en'
Config.UI.Dialogue.TypeSpeed = 0
Config.Resist.Onset.Enabled = false      -- the warning phase has its own section below; the other sections test the effects themselves
local files = { 'shared/utils.lua', 'shared/locale.lua', 'locales/ar.lua', 'locales/en.lua', 'shared/registry.lua', 'shared/settings.lua',
    'bridge/custom.lua', 'bridge/framework.lua', 'bridge/notifications.lua', 'bridge/appearance.lua',
    'client/state.lua', 'client/nui.lua', 'client/helpers.lua', 'client/entities.lua',
    'client/fx/visual.lua', 'client/fx/audio.lua', 'client/fx/body.lua', 'client/fx/people.lua', 'client/fx/entity_types.lua', 'client/fx/extras.lua', 'client/fx/realism.lua', 'client/fx/more.lua', 'client/fx/takeover.lua', 'client/world.lua', 'client/voice.lua',
    'client/dialogue.lua', 'client/engine.lua', 'client/resist.lua', 'client/main.lua' }
for _, f in ipairs(files) do dofile(ROOT .. f) end

local function advance(seconds)
    local target = vms + seconds * 1000
    while vms < target do
        local dt = 50
        vms = vms + dt
        stepWorld(dt / 1000)
        for _, t in ipairs(threads) do
            if not t.dead and vms >= t.wake then
                local ok, res = coroutine.resume(t.co)
                if not ok then error('thread error: ' .. tostring(res)) end
                if coroutine.status(t.co) == 'dead' then t.dead = true else t.wake = vms + (res or 0) end
            end
        end
        for k in pairs(pressed) do pressed[k] = nil end   -- a "just pressed" lasts one frame
    end
end

local pass, fail = 0, 0
local function check(c, m) if c then pass = pass + 1; print('  PASS  ' .. m) else fail = fail + 1; print('  FAIL  ' .. m) end end
local function pedCount() local n = 0 for _ in pairs(world.peds) do n = n + 1 end return n end
local function nuiOf(action) local n = 0 for _, m in ipairs(nui) do if m.action == action then n = n + 1 end end return n end
local function eventsOf(name) local n = 0 for _, e in ipairs(serverEvents) do if e.name == name then n = n + 1 end end return n end

advance(1)
print('\n[1] boot')
check(State.ready == true, 'client sent the ready signal')
check(eventsOf('universal_halluc:server:ready') == 1, 'server:ready triggered once')
check(nuiCallbacks.ready ~= nil and nuiCallbacks.panelAction ~= nil and nuiCallbacks.reply ~= nil, 'NUI callbacks registered')
nuiCallbacks.ready({}, function() end)   -- the page finished loading: queued messages are delivered
check(nuiOf('config') >= 1, 'the NUI receives the config (brand, colors, texts)')
check(UI.LogoPath('assets/brand/ra7dev_logo.png') == 'assets/brand/ra7dev_logo.png', 'logo: a normal relative path is accepted')
check(UI.LogoPath('') == nil and UI.LogoPath(nil) == nil, 'logo: empty means hidden')

-- jump scare config reaches the page: only safe image paths and plain face ids
local oldJ = Config.Jumpscare
Config.Jumpscare = { Images = { 'assets/scare/a.jpg', '../evil.jpg', 'https://x.y/z.png', 'assets/scare/b.txt', 'assets/scare/c.PNG' }, Faces = { 'ghost_girl', 'bad id', 7 }, ImageChance = 5 }
local jc = UI.JumpscareConfig()
check(#jc.images == 2 and jc.images[1] == 'assets/scare/a.jpg' and jc.images[2] == 'assets/scare/c.PNG', 'jumpscare: only relative jpg/png/webp paths pass')
check(#jc.faces == 1 and jc.faces[1] == 'ghost_girl' and jc.imageChance == 1.0, 'jumpscare: face ids validated, chance clamped')
Config.Jumpscare = oldJ
local jd = UI.JumpscareConfig()
check(#jd.images >= 12 and jd.imageChance > 0, 'jumpscare: default config ships the realistic zombie images')

-- every bundled scare image exists (relative to html/), the manifest ships them
for _, img in ipairs(Config.Jumpscare.Images) do
    local f = io.open('html/' .. img, 'rb')
    check(f ~= nil, 'scare image present: ' .. img)
    if f then f:close() end
end

-- map config: path validated, bounds numeric and ordered, points limited
local oldM = Config.Map
Config.Map = { Image = 'assets/map/atlas.jpg', Bounds = { MinX = 10, MaxX = -10, MinY = -1, MaxY = 1 }, Pois = { { 'A', 1, 2 }, { 'B' }, { 7, 1, 1 } } }
local mc = UI.MapConfig()
check(mc.image == 'assets/map/atlas.jpg', 'map: image path kept')
check(mc.bounds.maxX > mc.bounds.minX, 'map: broken X bounds fall back to the defaults')
check(#mc.pois == 1 and mc.pois[1][1] == 'A', 'map: only well-formed named points pass')
Config.Map = { Image = '../x.jpg' }
check(UI.MapConfig().image == nil, 'map: path traversal rejected')
Config.Map = { Image = 'assets/map/a.txt' }
check(UI.MapConfig().image == nil, 'map: only png/jpg/webp images')
Config.Map = oldM

-- resist levels
for _, lvl in ipairs({ 'easy', 'normal', 'hard', 'nightmare' }) do
    local L, nm = Utils.ResistLevel(lvl)
    check(nm == lvl and L.Difficulty and L.Seconds and L.Mistakes and L.Chain and L.Spikes ~= nil, 'resist level complete: ' .. lvl)
end
local _, fb = Utils.ResistLevel('nonsense')
check(fb == 'normal', 'unknown resist level falls back to normal')
check(Config.Resist.Level == 'hard' and Utils.ResistLevel('hard').Chain >= 2, 'default resist level is hard with a chain of games')
check(Utils.ResistLevel('nightmare').Difficulty > Utils.ResistLevel('normal').Difficulty and Utils.ResistLevel('nightmare').Mistakes == 0, 'nightmare is harder than normal')

-- zombie looks: at least 15, each with models and a name in both languages
local nLooks = 0
for name, look in pairs(Config.Realism.Zombies.Looks) do
    nLooks = nLooks + 1
    check(type(look.Models) == 'table' and #look.Models > 0 and (look.Weight or 0) > 0, 'look ' .. name .. ': models + weight')
    check(Locales.en['look_' .. name] and Locales.ar['look_' .. name], 'look ' .. name .. ': named in en and ar')
    if look.Variant then check(Config.Realism.Zombies.Variants[look.Variant] ~= nil, 'look ' .. name .. ': variant exists') end
end
check(nLooks >= 15, 'at least 15 zombie looks (' .. nLooks .. ')')
check(UI.LogoPath('../x.png') == nil and UI.LogoPath('/x.png') == nil and UI.LogoPath('https://a.b/c.png') == nil and UI.LogoPath('a b.png') == nil, 'logo: no "..", no leading slash, no URLs, no odd characters')

print('\n[2] every type runs, ends by itself, and cleans up')
local names = {}
for _, k in ipairs(Registry.Order) do names[#names + 1] = k end
local entityTypes = { ghost = true, shadow = true, stalker = true, crowd = true, zombie_horde = true, animals = true, gunman = true, double = true, friend = true }
local sidn = 1000
local leaks = {}
for _, key in ipairs(names) do
    if key ~= 'possess' then
        sidn = sidn + 1
        local before = created
        world.player.x, world.player.y, world.player.dead, world.player.vehicle = 0, 0, false, false
        local ok, err = pcall(function()
            handlers['universal_halluc:client:start'](sidn, key, { duration = 22, intensity = 0.9, subject = 7, controlled = false, params = {} })
            advance(26)
        end)
        if not ok then check(false, key .. ' crashed: ' .. tostring(err)) else
            local clean = (Engine.Count() == 0) and pedCount() == 0 and state.timecycle == nil and state.shake == nil and state.timeScale == 1.0 and next(state.postfx) == nil
            if not clean then leaks[#leaks + 1] = key end
            if entityTypes[key] then check(created > before, key .. ' spawned phantoms (' .. (created - before) .. ')') end
        end
    end
end
check(#leaks == 0, 'no leaks after any type: ' .. table.concat(leaks, ','))
check(eventsOf('universal_halluc:server:ended') >= #names - 1, 'every session reported its end to the server')

print('\n[3] gunman can never hurt')
check(#bullets > 0, 'fake shots were fired (' .. #bullets .. ')')
local allZero, allMiss = true, true
for _, b in ipairs(bullets) do
    if b.damage ~= 0 then allZero = false end
    local d = math.sqrt((b.to.x - world.player.x) ^ 2 + (b.to.y - world.player.y) ^ 2)
    if d < 1.0 then allMiss = false end
end
check(allZero, 'every bullet has damage 0')
check(allMiss, 'every bullet passes at least 1 m from the player')
local noAmmo = true
for _, w in ipairs(weapons) do if w.ammo ~= 0 then noAmmo = false end end
check(noAmmo and #weapons > 0, 'weapons are given with 0 ammo')

print('\n[3b] realism: gunfight / scenes / death feeling / zombies')
do
    for i = #bullets, 1, -1 do bullets[i] = nil end
    for i = #weapons, 1, -1 do weapons[i] = nil end
    -- ray maths
    check(Realism.RayDistance(0, 0, 0, 10, 0, 0, 5, 3, 0) == 3, 'ray distance: point beside the line')
    check(Realism.RayDistance(0, 0, 0, 10, 0, 0, 20, 2, 0) == 2, 'ray distance: the bullet keeps flying past the target')
    check(Realism.RayDistance(0, 0, 0, 10, 0, 0, -3, 4, 0) == 5, 'ray distance: behind the shooter')

    handlers['universal_halluc:client:start'](3001, 'gunfight', { duration = 40, intensity = 1.0, params = { mode = 'crossfire' } })
    advance(32)
    check(#bullets > 5, 'gunfight fired bullets (' .. #bullets .. ')')
    local zero, safe = true, true
    for _, b in ipairs(bullets) do
        if b.damage ~= 0 then zero = false end
        for _, dz in ipairs({ 0.0, 0.7, -0.9 }) do
            local d = Realism.RayDistance(b.from.x, b.from.y, b.from.z, b.to.x, b.to.y, b.to.z, world.player.x, world.player.y, world.player.z + dz)
            if d < 1.0 then safe = false end
        end
    end
    check(zero, 'gunfight: every bullet has damage 0')
    check(safe, 'gunfight: every bullet line stays at least 1 m from head, chest and feet')
    local noAmmo = true
    for _, w in ipairs(weapons) do if w.ammo ~= 0 then noAmmo = false end end
    check(noAmmo and #weapons >= 2, 'gunfight: shooters have 0 ammo (' .. #weapons .. ' weapons)')
    handlers['universal_halluc:client:stop'](3001)
    check(pedCount() == 0 and Engine.Count() == 0, 'gunfight cleans every ped')

    -- a line that would pass through the player is refused
    local before = #bullets
    local ctx = { alive = function() return true end, id = function(x) return 'x' .. x end, cfg = {} }
    local fakePed = 0
    local ok = Realism.IsSafeShot(world.player.x - 10, world.player.y, world.player.z, world.player.x, world.player.y, world.player.z)
    check(ok == false, 'a shot aimed at the player is refused')
    check(Realism.IsSafeShot(world.player.x - 10, world.player.y, world.player.z, world.player.x, world.player.y + 3.0, world.player.z) == true, 'a shot 3 m beside the player is allowed')

    -- every scene runs, spawns actors and leaves nothing behind
    for name, sc in pairs(Config.Scenes) do
        handlers['universal_halluc:client:start'](3100, 'scene', { duration = sc.Duration + 2, intensity = 0.8, params = { scene = name } })
        advance(3)
        check(pedCount() > 0, 'scene ' .. name .. ': actors appear')
        advance(sc.Duration + 3)
        check(Engine.Count() == 0 and pedCount() == 0, 'scene ' .. name .. ': ends by itself and cleans up')
    end
    check(state.timecycle == nil, 'scenes leave no timecycle behind')

    -- near-death never kills and finishes alone
    handlers['universal_halluc:client:start'](3200, 'death_feeling', { duration = 60, intensity = 1.0, params = {} })
    advance(50)
    check(Engine.Count() == 0, 'death_feeling ends by itself')
    check(state.timecycle == nil, 'death_feeling leaves no timecycle behind')

    -- zombies: more than one kind of ped
    handlers['universal_halluc:client:start'](3300, 'zombie_horde', { duration = 80, intensity = 1.0, params = {} })
    advance(8)
    check(pedCount() >= 3, 'zombie horde spawned ' .. pedCount() .. ' peds')
    handlers['universal_halluc:client:stop'](3300)
    check(pedCount() == 0, 'zombies removed')

    -- echo: a copy retraces the path the player walked a few seconds ago
    local home = { x = world.player.x, y = world.player.y, z = world.player.z }
    Config.Types.echo.Delay = { min = 6.0, max = 6.0 }
    handlers['universal_halluc:client:start'](3350, 'echo', { duration = 90, intensity = 1.0, params = {} })
    for _ = 1, 24 do world.player.x = world.player.x + 3.0; advance(1) end
    check(pedCount() == 1, 'echo appears behind the walking player')
    local echoPed
    for id, p in pairs(world.peds) do echoPed = p end
    check(echoPed and echoPed.x < world.player.x - 4.0, 'echo is on the old path, behind the player')
    for _ = 1, 15 do advance(1) end   -- the player stands still: the echo catches up and fades away
    check(pedCount() == 0, 'echo vanishes when it reaches the standing player')
    handlers['universal_halluc:client:stop'](3350)
    check(Engine.Count() == 0 and pedCount() == 0, 'echo cleans up')
    world.player.x, world.player.y, world.player.z = home.x, home.y, home.z

    -- fake lag: the walking player freezes for a moment and is never left frozen
    Config.Types.fake_lag.Interval = { min = 2.0, max = 2.0 }
    handlers['universal_halluc:client:start'](3360, 'fake_lag', { duration = 40, intensity = 1.0, params = {} })
    local sawFreeze = false
    local oldSpeed = GetEntitySpeed
    GetEntitySpeed = function() return 3.0 end
    for _ = 1, 40 do advance(0.25); if state.frozen then sawFreeze = true end end
    GetEntitySpeed = oldSpeed
    check(sawFreeze, 'fake lag freezes the character for a moment')
    handlers['universal_halluc:client:stop'](3360)
    check(state.frozen == false and Engine.Count() == 0, 'fake lag leaves the player unfrozen')

    for _, t in ipairs({ 'self_zombie', 'collapse', 'insects', 'drunk', 'underwater', 'echo', 'fake_lag', 'fake_wounds' }) do
        handlers['universal_halluc:client:start'](3400, t, { duration = 60, intensity = 1.0, params = {} })
        advance(25)
        handlers['universal_halluc:client:stop'](3400)
        check(Engine.Count() == 0 and pedCount() == 0 and state.timecycle == nil, t .. ' runs and cleans up')
    end

    -- takeover duel: the mini-game opens by itself, nothing is left behind
    local oldGames = Config.Resist.Games
    Config.Resist.Games = { 'mash' }
    handlers['universal_halluc:client:start'](3500, 'takeover', { duration = 40, intensity = 0.8, subject = 9, params = {} })
    advance(4)
    check(Resist.IsRunning(), 'takeover opens the resist mini-game by itself')
    handlers['universal_halluc:client:stop'](3500)
    advance(12)
    check(Engine.Count() == 0 and state.timecycle == nil, 'takeover duel cleans up')
    Config.Resist.Games = oldGames

    -- takeover ghost: frozen while it runs, free afterwards
    handlers['universal_halluc:client:start'](3600, 'takeover_ghost', { duration = 60, intensity = 0.8, subject = 9, params = {} })
    advance(3)
    check(state.frozen == true, 'ghost is frozen')
    handlers['universal_halluc:client:stop'](3600)
    check(state.frozen == false and state.timecycle == nil and Engine.Count() == 0, 'ghost released: unfrozen, no timecycle left')

    -- takeover ghost that may walk: not frozen, no weapons, no vehicles, ghosted against other players
    state.ctl = {}; state.weaponSet = nil
    handlers['universal_halluc:client:start'](3610, 'takeover_ghost', { duration = 60, intensity = 0.8, subject = 9, params = { move = true } })
    advance(3)
    check(state.frozen == false, 'a walking watcher is not frozen')
    check(state.weaponSet == GetHashKey('WEAPON_UNARMED'), 'a walking watcher has no weapon in hand')
    check(state.ctl[24] == true and state.ctl[23] == true, 'a walking watcher cannot attack or enter vehicles')
    check(state.ghost == true, 'a walking watcher does not collide with other players')
    handlers['universal_halluc:client:stop'](3610)
    check(state.ghost == false and Engine.Count() == 0, 'walking watcher released')

    -- the controller's rules: no weapons, melee, inventory or vehicles until released
    state.ctl = {}; state.weaponSet = nil; state.firingOff = false
    handlers['universal_halluc:client:takeoverLock'](true, { inventory = true, weapons = true, melee = true, vehicles = true, seconds = 60 })
    advance(1)
    check(state.weaponSet == GetHashKey('WEAPON_UNARMED') and state.firingOff, 'controller: weapon put away, firing off')
    check(state.ctl[24] == true and state.ctl[140] == true and state.ctl[23] == true and state.ctl[289] == true, 'controller: attack, melee, vehicle and inventory keys disabled')
    pressed[24] = true; advance(0.2); pressed[24] = nil
    check(true, 'a blocked attack shows a notice without crashing')
    handlers['universal_halluc:client:takeoverLock'](false)
    advance(0.5)
    state.ctl = {}; advance(0.5)
    check(state.ctl[24] == nil, 'controller: everything is free again after the lock ends')
    -- the failsafe: a lock never outlives its time
    handlers['universal_halluc:client:takeoverLock'](true, { weapons = true, seconds = 5 })
    advance(12)
    state.ctl = {}; advance(0.5)
    check(state.ctl[24] == nil, 'the lock expires on its own (failsafe)')
    -- world: frozen while it runs, free afterwards; scenes from the panel are merged
    handlers['universal_halluc:client:start'](3700, 'world_frozen', { duration = 60, intensity = 1.0, params = {} })
    advance(3)
    check(state.frozen == true, 'world_frozen freezes the player')
    handlers['universal_halluc:client:stop'](3700)
    check(state.frozen == false and Engine.Count() == 0, 'world_frozen releases the player')
    handlers['universal_halluc:client:userScenes']({ my_ui_scene = { Label = { ar = 'x', en = 'x' }, Actors = {} } })
    check(Config.Scenes.my_ui_scene ~= nil and Config.Scenes.my_ui_scene.User == true, 'user scenes merged on the client')
    handlers['universal_halluc:client:userScenes']({})
    check(Config.Scenes.my_ui_scene == nil, 'user scenes replaced')
    handlers['universal_halluc:client:fade']('out', 300); handlers['universal_halluc:client:fade']('in', 300)
    check(true, 'fade events do not crash')
    handlers['universal_halluc:client:voiceIsolate'](5)
    handlers['universal_halluc:client:voiceIsolate'](nil)
    check(true, 'voice isolation events do not crash')
end

print('\n[4] stop in the middle')
handlers['universal_halluc:client:start'](2001, 'zombie_horde', { duration = 100, intensity = 1.0, params = {} })
advance(6)
check(pedCount() > 0, 'zombies exist while running')
handlers['universal_halluc:client:stop'](2001)
check(pedCount() == 0 and Engine.Count() == 0, 'client:stop deletes everything immediately')
handlers['universal_halluc:client:start'](2002, 'acid_trip', { duration = 100, intensity = 1.0, params = {} })
handlers['universal_halluc:client:start'](2003, 'distortion', { duration = 100, intensity = 1.0, params = {} })
advance(2)
check(state.timecycle ~= nil, 'timecycle active with two sessions')
handlers['universal_halluc:client:stop'](2002)
check(state.timecycle ~= nil, 'ending one keeps the other one active (stack)')
handlers['universal_halluc:client:stop'](2003)
check(state.timecycle == nil, 'last one clears the timecycle')

print('\n[5] death')
handlers['universal_halluc:client:start'](2004, 'ghost', { duration = 100, intensity = 1.0, params = {} })
advance(3)
world.player.dead = true; advance(1)
check(Engine.Count() == 0 and pedCount() == 0, 'death stops everything and removes phantoms')
world.player.dead = false

print('\n[6] vehicles (NoEntitiesWhileDriving)')
world.player.vehicle = true
local c0 = created
handlers['universal_halluc:client:start'](2005, 'zombie_horde', { duration = 30, intensity = 1.0, params = {} })
advance(10)
check(created == c0, 'no phantoms are spawned while driving')
handlers['universal_halluc:client:stop'](2005)
world.player.vehicle = false

print('\n[7] live intensity')
handlers['universal_halluc:client:start'](2006, 'tint', { duration = 60, intensity = 0.2, params = {} })
advance(1)
local o0 = nuiOf('overlay')
handlers['universal_halluc:client:update'](2006, 0.9)
check(nuiOf('overlay') > o0 and Engine.Get(2006).intensity == 0.9, 'update re-applies the overlay with the new intensity')
handlers['universal_halluc:client:stop'](2006)

print('\n[8] resist mini-games')
Config.Resist.Cooldown = 0
for _, game in ipairs({ 'mash', 'hold', 'timing', 'sequence' }) do
    sidn = sidn + 1
    Config.Resist.Games = { game }
    handlers['universal_halluc:client:start'](sidn, 'distortion', { duration = 120, intensity = 0.7, params = {} })
    advance(1)
    local sc = eventsOf('universal_halluc:server:resist')
    -- press the resist key to start (exactly like a player)
    pressed[Config.Resist.Key] = true
    advance(0.2)
    check(Resist.IsRunning(), game .. ': mini-game opens on the resist key')
    -- auto-play: mash taps every frame; hold keeps pressed; others just run until the time limit
    for _ = 1, 400 do
        if game == 'mash' then pressed[Config.Resist.Key] = true end
        if game == 'hold' then held[Config.Resist.Key] = true end
        advance(0.05)
        if not Resist.IsRunning() then break end
    end
    held[Config.Resist.Key] = nil
    advance(3)
    check(not Resist.IsRunning(), game .. ': mini-game finishes')
    local ev
    for i = #serverEvents, 1, -1 do if serverEvents[i].name == 'universal_halluc:server:resist' then ev = serverEvents[i] break end end
    check(eventsOf('universal_halluc:server:resist') == sc + 1 and ev.args[1] == sidn and type(ev.args[2]) == 'boolean' and ev.args[3] >= 500, game .. ': result reported (' .. tostring(ev and ev.args[2]) .. ', ' .. tostring(ev and ev.args[3]) .. ' ms)')
    if game == 'mash' then check(ev.args[2] == true, 'mash: tapping every frame wins') end
    handlers['universal_halluc:client:stop'](sidn)
end

print('\n[9] cues')
local cueNames = {}
for k in pairs(Config.Cues.Items) do cueNames[#cueNames + 1] = k end
table.sort(cueNames)
for _, k in ipairs(cueNames) do
    local ok, err = pcall(function() handlers['universal_halluc:client:cue'](k, 3, 1.0); advance(5) end)
    check(ok, 'cue ' .. k .. (ok and '' or (': ' .. tostring(err))))
end
check(state.shake == nil and state.lights == false, 'cues leave nothing behind (shake, lights)')

print('\n[10] possession')
handlers['universal_halluc:client:start'](3001, 'possess', { duration = 30, intensity = 1.0, subject = 7, controlled = false, params = {} })
advance(1)
check(state.frozen == true, 'target is frozen')
handlers['universal_halluc:client:possessCam'](3001, 10, 20, 30, 0, 0, 90, 50)
advance(1)
check(state.camActive == true, 'target camera renders the controller view')
handlers['universal_halluc:client:stop'](3001)
check(state.camActive == false and state.frozen == false, 'stop restores camera and movement')
handlers['universal_halluc:client:possessInfo'](3002, true, 5, 'Target', 30)
advance(2)
local streamed = eventsOf('universal_halluc:server:possessCam')
check(streamed >= 15, 'controller streams his camera (' .. streamed .. ' packets in 2 s)')
handlers['universal_halluc:client:possessInfo'](3002, false)
local n1 = eventsOf('universal_halluc:server:possessCam'); advance(2)
check(eventsOf('universal_halluc:server:possessCam') == n1, 'streaming stops when possession ends')

print('\n[11] scripted dialogue')
handlers['universal_halluc:client:start'](4001, 'friend', { duration = 120, intensity = 0.5, params = {} })
advance(8)
check(pedCount() == 1, 'friend phantom present')
world.peds[next(world.peds)].x, world.peds[next(world.peds)].y = 0.5, -1
pressed[Config.Types.friend.TalkKey] = true
advance(0.3)
for i = 1, 40 do pressed[157] = true; advance(0.5) end
check(nuiOf('dialogue') >= 1, 'dialogue shown through the NUI')
local n0 = nuiOf('notify')
Notify.Send('hello', 'inform')
check(nuiOf('notify') == n0 + 1, 'Notify.Send reaches the NUI (default config; was silently disabled by a missing key in 1.1.0)')
Config.Notifications.Enabled = false
Notify.Send('hello', 'inform')
check(nuiOf('notify') == n0 + 1, 'Config.Notifications.Enabled = false mutes notifications')
Config.Notifications.Enabled = true
check(eventsOf('universal_halluc:server:choice') >= 1, 'choices reported to the server')
handlers['universal_halluc:client:say'](4001, 'I am here', 4)
check(nuiOf('dialogue') >= 2, 'director line shown')
handlers['universal_halluc:client:stop'](4001)
check(pedCount() == 0, 'friend removed')

print('\n[12] panel round trip')
handlers['universal_halluc:client:panelData']({ players = {}, types = {} }, true)
check(state.focus == true and State.panel == true, 'panel opens with NUI focus')
local before = #serverEvents
nuiCallbacks.panelAction({ action = 'cue', payload = { target = 1, cue = 'glitch' } }, function() end)
check(#serverEvents == before + 1 and serverEvents[#serverEvents].name == 'universal_halluc:server:panel', 'allowed action forwarded to the server')
nuiCallbacks.panelAction({ action = 'rm_rf', payload = {} }, function() end)
check(#serverEvents == before + 1, 'unknown action never leaves the client')
nuiCallbacks.panelClose({}, function() end)
check(state.focus == false and State.panel == false, 'panel closes and releases focus')

print('\n[13] appearance bridge')
local ok13 = pcall(function() handlers['universal_halluc:client:appearanceGet'](5) end)
check(ok13 and eventsOf('universal_halluc:server:appearanceData') == 1, 'appearanceGet always answers (even without a provider)')

print('\n[14] health: a failed effect says why and never stays silent')
do
    Config.Health.CheckAfter = 3
    local function lastHealth() for i = #serverEvents, 1, -1 do if serverEvents[i].name == 'universal_halluc:server:health' then return serverEvents[i] end end end
    world.player.vehicle = true
    local h0 = eventsOf('universal_halluc:server:health')
    local ov0 = nuiOf('overlay')
    handlers['universal_halluc:client:start'](5001, 'zombie_horde', { duration = 40, intensity = 0.8, params = {} })
    advance(20)
    local hv = lastHealth()
    check(eventsOf('universal_halluc:server:health') == h0 + 1 and hv.args[1] == 5001 and hv.args[2] == false and hv.args[3] == 'in_vehicle', 'zombies in a vehicle: reported as in_vehicle')
    check(nuiOf('overlay') > ov0, 'the fallback scare runs (dark edges) instead of nothing')
    handlers['universal_halluc:client:stop'](5001)
    world.player.vehicle = false

    -- a working effect is not reported
    local h1 = eventsOf('universal_halluc:server:health')
    handlers['universal_halluc:client:start'](5002, 'ghost', { duration = 40, intensity = 0.8, params = {} })
    advance(20)
    check(eventsOf('universal_halluc:server:health') == h1, 'a ghost that appeared is not reported')
    handlers['universal_halluc:client:stop'](5002)

    -- a handler that throws is reported as an error
    Fx.Register('boom_test', function(ctx) error('kaboom') end)
    Registry.Types.boom_test = { cat = 'visual' }; Config.Types.boom_test = { Enabled = true }
    local h2 = eventsOf('universal_halluc:server:health')
    handlers['universal_halluc:client:start'](5003, 'boom_test', { duration = 20, intensity = 0.8, params = {} })
    advance(1)
    local he = lastHealth()
    check(eventsOf('universal_halluc:server:health') == h2 + 1 and he.args[3]:find('^error') ~= nil, 'a script error is reported with its text')
    handlers['universal_halluc:client:stop'](5003)
    Registry.Types.boom_test = nil

    -- self-test sessions report success too
    local h3 = eventsOf('universal_halluc:server:health')
    handlers['universal_halluc:client:start'](5004, 'tint', { duration = 8, intensity = 0.6, params = { selftest = true } })
    advance(7)
    check(eventsOf('universal_halluc:server:health') == h3 + 1 and lastHealth().args[2] == true, 'self-test session reports ok')
    handlers['universal_halluc:client:stop'](5004)
end

print('\n[15] warning phase: RESIST! comes BEFORE the hallucination')
do
    Config.Resist.Onset.Enabled = true
    Config.Resist.Onset.Seconds = 4
    Config.Resist.Cooldown = 0
    Config.Resist.Games = { 'mash' }
    local c0 = created
    handlers['universal_halluc:client:start'](5101, 'ghost', { duration = 60, intensity = 0.8, params = {} })
    advance(1.5)
    check(created == c0, 'nothing spawned during the warning')
    local rp = nil
    for i = #nui, 1, -1 do if nui[i].action == 'resistPrompt' and nui[i].data and nui[i].data.on then rp = nui[i].data break end end
    check(rp and rp.onset == true, 'the RESIST! prompt is already on screen (onset)')
    advance(5)
    check(created > c0, 'the ghost appears after the warning window')
    check(Engine.Get(5101).endsAt - GetGameTimer() > 50000, 'the warning did not eat the duration')
    handlers['universal_halluc:client:stop'](5101)

    -- winning the fight during the warning: the effect waits for the server's answer
    handlers['universal_halluc:client:start'](5102, 'distortion', { duration = 60, intensity = 0.8, params = {} })
    advance(0.5)
    pressed[Config.Resist.Key] = true
    advance(0.3)
    check(Resist.IsRunning(), 'the mini-game opens during the warning')
    handlers['universal_halluc:client:stop'](5102)   -- the server ended it (resist won)
    advance(1)
    check(Engine.Count() == 0 and not Resist.IsRunning(), 'a won fight ends the session before it started')

    -- excluded / weak / controlled sessions start right away
    handlers['universal_halluc:client:start'](5103, 'heartbeat', { duration = 30, intensity = 0.8, params = {} })
    advance(0.5)
    check(Engine.Get(5103).handlerAt ~= nil, 'excluded types start immediately')
    handlers['universal_halluc:client:stop'](5103)
    handlers['universal_halluc:client:start'](5104, 'distortion', { duration = 30, intensity = 0.1, params = {} })
    advance(0.5)
    check(Engine.Get(5104).handlerAt ~= nil, 'very weak sessions start immediately')
    handlers['universal_halluc:client:stop'](5104)
    Config.Resist.Onset.Enabled = false
end

print('\n[16] the eye hallucination')
do
    local n0 = nuiOf('eye')
    handlers['universal_halluc:client:start'](5201, 'eyes', { duration = 30, intensity = 0.7, params = {} })
    advance(4)
    check(nuiOf('eye') > n0, 'the eye is sent to the page')
    local e = nil
    for i = #nui, 1, -1 do if nui[i].action == 'eye' then e = nui[i].data break end end
    check(e and (e.mode == 'lids' or e.mode == 'watcher') and e.seconds > 1.5 and e.id:find('^s5201:') ~= nil, 'eye message is complete and owned by the session')
    check(e and e.mode == 'lids', 'the default eye is the screen turning into an eye (lids), not a giant pupil')
    local sleepSeen = false
    for i = 1, 40 do
        local l, m, pt = Visual.EyeRound({ id = function(x) return 's5201:' .. x end, cfg = Config.Types.eyes, intensity = 0.7, note = function() end }, { mode = 'lids' })
        if pt == 'sleep' and l >= 12 then sleepSeen = true break end
    end
    check(sleepSeen, "the 'sleep' pattern (opens, blinks, shuts completely, opens again) is used")
    handlers['universal_halluc:client:stop'](5201)
    check(nuiOf('eyeStop') >= 1, 'stopping the session closes the eye')
    local n1 = nuiOf('eye')
    Cue.Run('eye_blink', 5, 0.8)
    check(nuiOf('eye') == n1 + 1, 'eye_blink cue works')
    for _, m in ipairs({ 'lids', 'watcher' }) do
        local nn = nuiOf('eye')
        Visual.EyeRound({ id = function(x) return 'x:' .. x end, note = function() end, cfg = {}, intensity = .5 }, { mode = m })
        check(nuiOf('eye') == nn + 1, 'scene event can show the ' .. m .. ' eye')
    end
end

print('\n[17] frameworks and settings on the client')
do
    check(Framework.Normalize('QBX') == 'qbox' and Framework.Normalize('qbx_core') == 'qbox' and Framework.Normalize('qb-core') == 'qbcore' and Framework.Normalize('es_extended') == 'esx' and Framework.Normalize('standalone') == 'standalone' and Framework.Normalize('???') == 'auto', 'framework names and aliases')
    local lvl = Config.Resist.Level
    handlers['universal_halluc:client:settings']({ ['Resist.Level'] = 'nightmare', ['Brand.Colors.Primary'] = '#112233' })
    check(Config.Resist.Level == 'nightmare' and Config.Brand.Colors.Primary == '#112233', 'settings from the server apply to this client')
    handlers['universal_halluc:client:settings']({})
    check(Config.Resist.Level == lvl, 'an empty list brings config.lua back')
end

local list = {}
for k in pairs(undefinedNatives) do list[#list + 1] = k end
table.sort(list)
print('\n[info] natives used without a mock (review names against the FiveM docs):\n  ' .. table.concat(list, ', '))
print(('\n==== %d passed, %d failed ===='):format(pass, fail))
if fail > 0 then error('tests failed') end
