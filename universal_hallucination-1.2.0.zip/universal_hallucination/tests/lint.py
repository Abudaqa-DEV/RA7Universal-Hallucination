#!/usr/bin/env python3
"""Offline checks that catch the bugs a test run on a fake server cannot:
   1. every panel action the server understands is allowed by the client whitelist (client/main.lua ACTIONS)
   2. English and Arabic locales have exactly the same keys
   3. every Locale('key') / T('key') used in code exists
   4. every file in fxmanifest `files` exists (globs included) and every html asset is listed
   5. every sound the code plays exists in html/assets/sounds
usage: python3 tests/lint.py   (exit code 1 on a problem)"""
import glob, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
bad = []
rd = lambda p: open(p, encoding='utf-8').read()

# 1 ----------------------------------------------------------------
server = rd('server/main.lua')
acts = set(re.findall(r"action == '(\w+)'", server))
m = re.search(r"local ACTIONS = \{(.*?)\n\}", rd('client/main.lua'), re.S)
allowed = set(re.findall(r"(\w+) = true", m.group(1))) if m else set()
for a in sorted(acts - allowed): bad.append(f'panel action "{a}" is handled by the server but missing from client ACTIONS (the button would do nothing)')

# 2 ----------------------------------------------------------------
keys = lambda p: set(re.findall(r"^\s*\['([^']+)'\]\s*=", rd(p), re.M))
en, ar = keys('locales/en.lua'), keys('locales/ar.lua')
for k in sorted(en - ar): bad.append(f'locale key only in en: {k}')
for k in sorted(ar - en): bad.append(f'locale key only in ar: {k}')

# 3 ----------------------------------------------------------------
code = ''
for f in glob.glob('**/*.lua', recursive=True):
    if f.startswith(('tests/', 'locales/')): continue
    code += rd(f) + '\n'
dyn = ('type_', 'tn_', 'cue_', 'scn_', 'why_', 'blocked_', 'look_', 'ui_level_', 'ui_diag_k_', 'ui_ev_', 'ui_set_', 'ui_tab_', 'game_')
for k in sorted(set(re.findall(r"Locale\('([\w]+)'", code))):
    if k not in en and not k.endswith('_'): bad.append(f'Locale("{k}") has no text')
js = rd('html/script.js')
for k in sorted(set(re.findall(r"\bT\('([\w]+)'", js))):
    if k not in en and not k.endswith('_') and not any(k == d for d in dyn): bad.append(f'T("{k}") in script.js has no text')

# 4 ----------------------------------------------------------------
fx = rd('fxmanifest.lua')
fb = re.search(r"\nfiles \{(.*?)\n\}", fx, re.S)
patterns = re.findall(r"'([^']+)'", fb.group(1)) if fb else []
listed = set()
for pt in patterns:
    g = glob.glob(pt)
    optional = ('assets/map/', 'assets/scare/')            # folders where the owner may drop only some formats
    if not g and not any(o in pt for o in optional): bad.append(f'fxmanifest files: "{pt}" matches nothing')
    listed.update(g)
for f in glob.glob('html/**/*', recursive=True):
    if os.path.isfile(f) and f not in listed and not f.endswith(('.md',)): bad.append(f'html file not listed in fxmanifest files (it would 404 in game): {f}')
for kind in ('server_scripts', 'client_scripts', 'shared_scripts'):
    b = re.search(kind + r"\s*\{(.*?)\n\}", fx, re.S)
    for pt in (re.findall(r"'([^']+)'", b.group(1)) if b else []):
        if not glob.glob(pt): bad.append(f'{kind}: "{pt}" does not exist')

# 5 ----------------------------------------------------------------
snd = {os.path.basename(f)[:-4] for f in glob.glob('html/assets/sounds/*.ogg')}
used = set(re.findall(r"(?:UI\.Sound\(|Audio\.(?:PlayAt|Play2D|Loop)\()[^,()]*(?:\([^()]*\))?[^,()]*,\s*'([a-z0-9_]+)'", code))
used |= set(re.findall(r"'(eyelid|eye_open|eye_drone|heart_hard|scare_hit|shriek)'", code + js))
for k in sorted(used - snd):
    if k and not k.endswith('_'): bad.append(f'sound used but missing: html/assets/sounds/{k}.ogg')

if bad:
    print('LINT FAILED'); [print('  -', b) for b in bad]; sys.exit(1)
print(f'lint ok: {len(acts)} actions, {len(en)} locale keys, {len(listed)} listed files, {len(snd)} sounds')
