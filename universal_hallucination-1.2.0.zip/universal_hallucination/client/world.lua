--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/world.lua - the client side of the parallel world, scenes created in the panel and the diagnostics.
]]

local EV = 'universal_halluc:client:'

-- ----------------------------------------------------------------------
-- Screen fade (used around a teleport)
-- ----------------------------------------------------------------------
RegisterNetEvent(EV .. 'fade', function(dir, ms)
    ms = math.floor(Utils.Clamp(tonumber(ms) or 600, 50, 5000))
    if dir == 'out' then
        DoScreenFadeOut(ms)
    else
        DoScreenFadeIn(ms)
    end
end)

-- never leave a player with a black screen when the resource stops
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and IsScreenFadedOut() then DoScreenFadeIn(300) end
end)

-- ----------------------------------------------------------------------
-- Scenes created in the panel: merged into Config.Scenes (server sanitises them)
-- ----------------------------------------------------------------------
-- settings saved from the panel: apply to this client's Config and refresh the page
RegisterNetEvent(EV .. 'settings', function(tbl)
    if type(tbl) ~= 'table' then return end
    Settings.Apply(tbl)
    if UI and UI.Init then UI.Init() end
end)

RegisterNetEvent(EV .. 'userScenes', function(scenes)
    if type(scenes) ~= 'table' then return end
    Config.Scenes = Config.Scenes or {}
    for k, v in pairs(Config.Scenes) do
        if type(v) == 'table' and v.User then Config.Scenes[k] = nil end
    end
    for k, v in pairs(scenes) do
        if type(k) == 'string' and type(v) == 'table' then
            v.User = true
            Config.Scenes[k] = v
        end
    end
end)

-- ----------------------------------------------------------------------
-- World: the moved player can only look (Fx world_frozen)
-- ----------------------------------------------------------------------
Fx.Register('world_frozen', function(ctx)
    local K = Config.World or {}
    local o = ctx.id('wf')
    UI.Send('possessHud', { on = true, role = 'world', seconds = ctx.left() })
    UI.Overlay(ctx.id('vig'), 'vignette', true, { color = '#050A18', strength = 0.3, pulse = false })
    ctx.onStop(function()
        local p = PlayerPedId()
        FreezeEntityPosition(p, false)
        SetEntityInvincible(p, false)
        UI.Send('possessHud', { on = false })
    end)
    while ctx.alive() do
        local ped = PlayerPedId()
        if K.TargetFrozen ~= false then FreezeEntityPosition(ped, true) end
        if K.TargetInvincible ~= false then SetEntityInvincible(ped, true) end
        DisableAllControlActions(0)
        EnableControlAction(0, 1, true)      -- look
        EnableControlAction(0, 2, true)
        EnableControlAction(0, 249, true)    -- push to talk
        EnableControlAction(0, 200, true)    -- pause menu
        Wait(0)
    end
end)

-- ----------------------------------------------------------------------
-- Diagnostics: checks every name written in the config against the game and reports what is wrong
-- ----------------------------------------------------------------------
local Diag = {}
local running = false

local MODEL_KEYS = { Model = true, Models = true, Creatures = true, PropModels = true }

local function collect()
    local items, seen = {}, {}
    local function add(kind, name, where)
        if type(name) ~= 'string' or name == '' or name == 'self' or name == 'subject' then return end
        local k = kind .. ':' .. name
        if seen[k] then return end
        seen[k] = true
        items[#items + 1] = { kind = kind, name = name, where = where }
    end
    local function walk(t, path, depth)
        if depth > 7 or type(t) ~= 'table' then return end
        if t.Asset and t.Name and type(t.Asset) == 'string' then add('ptfx', t.Asset, path) end
        if t.dict and t.name and type(t.dict) == 'string' then add('anim', t.dict, path) end
        for k, v in pairs(t) do
            local p = path .. '.' .. tostring(k)
            if type(k) == 'string' then
                if MODEL_KEYS[k] then
                    if type(v) == 'string' then add('model', v, p)
                    elseif type(v) == 'table' then for _, m in ipairs(v) do add('model', m, p) end end
                elseif k == 'Clipset' and type(v) == 'string' then add('clipset', v, p)
                elseif k == 'Clipsets' and type(v) == 'table' then for _, m in ipairs(v) do add('clipset', m, p) end
                elseif k == 'Weapon' and type(v) == 'string' then add('weapon', v, p) end
            end
            if type(v) == 'table' then walk(v, p, depth + 1) end
        end
    end
    walk({ Types = Config.Types, Realism = Config.Realism, Scenes = Config.Scenes, Appearance = Config.Appearance }, 'Config', 0)
    return items
end

local function check(it)
    if it.kind == 'model' then
        local h = joaat(it.name)
        return IsModelInCdimage(h) and IsModelValid(h)
    elseif it.kind == 'clipset' then
        return Helpers.LoadClipSet(it.name, 1200)
    elseif it.kind == 'anim' then
        return Helpers.LoadAnimDict(it.name, 1200)
    elseif it.kind == 'ptfx' then
        RequestNamedPtfxAsset(it.name)
        local t = GetGameTimer() + 700
        while not HasNamedPtfxAssetLoaded(it.name) and GetGameTimer() < t do Wait(0) end
        return HasNamedPtfxAssetLoaded(it.name)
    elseif it.kind == 'weapon' then
        return IsWeaponValid(joaat(it.name))
    end
    return true
end

function Diag.Run()
    if running then return end
    running = true
    CreateThread(function()
        local items = collect()
        local bad = {}
        UI.Send('diagProgress', { done = 0, total = #items })
        for i, it in ipairs(items) do
            local ok, res = pcall(check, it)
            if not (ok and res) then bad[#bad + 1] = it end
            if i % 8 == 0 then UI.Send('diagProgress', { done = i, total = #items }) end
            Wait(0)
        end
        local res = {}
        local V = Config.Voice or {}
        if V.Enabled and V.Provider and V.Provider ~= 'custom' then
            local st = GetResourceState(V.Provider)
            res[#res + 1] = { name = V.Provider, kind = 'resource', ok = (st == 'started'), note = st }
        end
        local fw = GetResourceState('es_extended') == 'started' and 'ESX' or GetResourceState('qbx_core') == 'started' and 'Qbox' or GetResourceState('qb-core') == 'started' and 'QBCore' or 'standalone'
        res[#res + 1] = { name = fw, kind = 'framework', ok = true }
        res[#res + 1] = { name = 'OneSync', kind = 'server', ok = GetConvar('onesync', 'off') ~= 'off', note = GetConvar('onesync', 'off') }
        local log = {}
        for _, l in ipairs(Utils.DebugLog or {}) do log[#log + 1] = l end
        UI.Send('diagResult', { total = #items, bad = bad, info = res, log = log })
        running = false
    end)
end

RegisterNUICallback('diagRun', function(_, cb)
    cb({ ok = true })
    Diag.Run()
end)
