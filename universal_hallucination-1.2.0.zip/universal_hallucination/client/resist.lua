--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/resist.lua - the resist mini-games.

    The logic runs here (controls are read from the game); the NUI only draws the state.
    The result goes to the server, which validates it (minimum time, cooldown, session ownership)
    and then lowers/raises the intensity or ends the hallucination.

      mash      press the key fast to fill the bar before it drains
      hold      breath control: hold the key to raise the marker, release to lower it, keep it in the zone
      timing    stop the needle inside the zone (3-5 rounds)
      sequence  press the arrows in the order shown (on hard levels the far end is hidden: remember it)

    Difficulty comes from Config.Resist.Level (easy / normal / hard / nightmare, see Config.Resist.Levels):
      Difficulty  how tight every game is        Seconds   time per game
      Mistakes    errors you may make            Chain     games in a row you must win (a different one each time)
      Spikes      scares that hit you mid-game (flash of a face + a penalty)
]]

Resist = {}

local running = false
local cooldownUntil = 0
local promptUntil = 0
local nextPrompt = 0

local function RKEY() return Utils.Num(Config.Resist.Key, 47, 0, 360) end

local ARROWS = {
    { code = 174, name = 'left' }, { code = 175, name = 'right' },
    { code = 172, name = 'up' },   { code = 173, name = 'down' },
}

local function now() return GetGameTimer() end

local function allowed(typeKey)
    local R = Config.Resist
    if not R.Enabled then return false end
    if Utils.Contains(R.Exclude, typeKey) then return false end
    local c = Config.Types[typeKey]
    if c and c.Resist == false then return false end
    return true
end

--- The most intense eligible session (the one the player is fighting).
local function pickSession()
    local best
    for _, ctx in pairs(Engine.sessions) do
        if allowed(ctx.type) and (not best or ctx.intensity > best.intensity) then best = ctx end
    end
    return best
end

local function settings(ctx, game)
    local o = type(ctx.cfg.Resist) == 'table' and ctx.cfg.Resist or {}
    local R = Config.Resist
    local name = tostring(ctx.params.pressure or o.Level or R.Level or 'normal')
    local L = Utils.ResistLevel(name)
    local d = tonumber(o.Difficulty) or tonumber(L.Difficulty) or tonumber(R.Difficulty) or 0.5
    local seconds = Utils.Clamp(tonumber(o.Seconds) or tonumber(L.Seconds) or tonumber(R.GameSeconds) or 7, 3, 30)
    local st = {
        game = game or o.Game or Utils.Pick(R.Games) or 'mash',
        level = name,
        -- the fear of the hallucination makes it harder: x0.85 .. x1.15 (1.0 is the hardest the games reach)
        difficulty = Utils.Clamp(d * (0.85 + 0.3 * ctx.intensity), 0.0, 1.0),
        seconds = seconds,
        mistakes = math.floor(Utils.Clamp(tonumber(L.Mistakes) or 1, 0, 6)),
        spikes = math.floor(Utils.Clamp(tonumber(L.Spikes) or 0, 0, 8)),
    }
    -- when each scare hits (seconds from the start of the game)
    st.spikeAt = {}
    for i = 1, st.spikes do st.spikeAt[i] = seconds * (0.15 + 0.75 * (i - 1 + math.random()) / st.spikes) end
    return st
end

--- true once for every scare whose time has come
local function spike(st, elapsed)
    local at = st.spikeAt
    for i = 1, #at do
        if at[i] and elapsed >= at[i] then
            at[i] = false
            UI.Send('resistSpike', { n = i })
            UI.Sound('resist_spike', Config.Sounds.Layered ~= false and 'scare_hit' or 'thump', { volume = 0.8 })
            return true
        end
    end
    return false
end

local function keyDown() return IsControlPressed(0, RKEY()) or IsDisabledControlPressed(0, RKEY()) end
local function keyHit() return IsControlJustPressed(0, RKEY()) or IsDisabledControlJustPressed(0, RKEY()) end

local function blockControls(game)
    DisableControlAction(0, RKEY(), true)
    if game == 'sequence' then
        for _, a in ipairs(ARROWS) do DisableControlAction(0, a.code, true) end
    end
end

-- ----------------------------------------------------------------------
-- Games: each returns true (won) / false (lost) / nil (cancelled), ticks at frame rate
-- ----------------------------------------------------------------------
local function push(state) UI.Send('resist', state) end

local GAMES = {}

GAMES.mash = function(st, alive)
    local needed = math.floor(12 + 20 * st.difficulty)       -- presses to fill the bar
    local drain = 0.06 + 0.07 * st.difficulty                 -- how fast it drains per second
    local progress = 0.0
    local t0, last, lastPush = now(), now(), 0
    while alive() do
        local t = now()
        local dt = (t - last) / 1000.0
        last = t
        blockControls('mash')
        local e = (t - t0) / 1000.0
        if keyHit() then
            progress = progress + 1.0 / needed
            UI.Send('resistTap', {})
        end
        if spike(st, e) then progress = math.max(0.0, progress - 0.10 - 0.08 * st.difficulty) end   -- the scare knocks you back
        progress = math.max(0.0, progress - drain * dt)
        local left = st.seconds - e
        if t - lastPush > 40 then
            lastPush = t
            push({ game = 'mash', progress = progress, left = left, total = st.seconds })
        end
        if progress >= 1.0 then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

GAMES.hold = function(st, alive)
    local d = st.difficulty
    local need = 2.2 + 1.8 * d                  -- seconds that must be spent inside the zone
    local width = 0.26 - 0.12 * d
    local window = st.seconds + 2.0
    local pos, inZone = 0.2, 0.0
    local t0, last, lastPush = now(), now(), 0
    local seed, seed2 = math.random() * 6.28, math.random() * 6.28
    while alive() do
        local t = now()
        local dt = (t - last) / 1000.0
        last = t
        blockControls('hold')
        local e = (t - t0) / 1000.0
        -- the zone drifts and shivers: faster and more erratic with the difficulty
        local center = 0.5 + 0.28 * math.sin(e * (0.9 + 1.0 * d) + seed)
            + (0.06 + 0.08 * d) * math.sin(e * (2.3 + 2.2 * d) + seed2)
        center = Utils.Clamp(center, width / 2, 1.0 - width / 2)
        local rise = keyDown() and (0.75 + 0.2 * d) or -(0.55 + 0.2 * d)
        if spike(st, e) then pos = Utils.Clamp(pos + (math.random() < 0.5 and -1 or 1) * (0.18 + 0.12 * d), 0.0, 1.0) end   -- the scare shoves the marker
        pos = Utils.Clamp(pos + rise * dt, 0.0, 1.0)
        local inside = math.abs(pos - center) <= width / 2
        if inside then inZone = inZone + dt else inZone = math.max(0.0, inZone - dt * (0.6 + 0.7 * d)) end
        local left = window - e
        if t - lastPush > 40 then
            lastPush = t
            push({ game = 'hold', pos = pos, center = center, width = width, progress = inZone / need, inside = inside, left = left, total = window })
        end
        if inZone >= need then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

GAMES.timing = function(st, alive)
    local d = st.difficulty
    local rounds = 3 + (d >= 0.7 and 1 or 0) + (d >= 0.95 and 1 or 0)
    local lives = st.mistakes + 1
    local maxLives = lives
    local hits = 0
    local total = st.seconds * rounds * 0.75 + 2.0
    local t0, lastPush = now(), 0
    for round = 1, rounds do
        local width = math.max(0.06, 0.20 - 0.08 * d - 0.01 * round)
        local zone = Utils.Rand(0.2, 0.8)
        local speed = 0.55 + 0.6 * d + 0.1 * round
        local phase = math.random() * 2.0
        local last = now()
        local settled = false
        while alive() and not settled do
            local t = now()
            local dt = (t - last) / 1000.0
            last = t
            blockControls('timing')
            local e = (t - t0) / 1000.0
            if spike(st, e) then zone = Utils.Clamp(zone + (math.random() < 0.5 and -1 or 1) * 0.25, 0.15, 0.85) end   -- the scare moves the zone
            phase = phase + dt * speed * 2.0
            local needle = math.abs((phase % 2.0) - 1.0)    -- ping-pong 0..1..0
            local left = total - e
            if t - lastPush > 40 then
                lastPush = t
                push({ game = 'timing', needle = needle, zone = zone, width = width, round = round, rounds = rounds, hits = hits, lives = lives, maxLives = maxLives, left = left, total = total })
            end
            if keyHit() then
                if math.abs(needle - zone) <= width / 2 then
                    hits = hits + 1
                    UI.Send('resistTap', { good = true })
                    settled = true
                    Wait(300)
                else
                    lives = lives - 1
                    UI.Send('resistTap', { good = false })
                    if lives <= 0 then return false end
                    Wait(220)
                    last = now()
                end
            end
            if left <= 0 then return false end
            Wait(0)
        end
        if not alive() then return nil end
    end
    return hits >= rounds
end

GAMES.sequence = function(st, alive)
    local d = st.difficulty
    local n = math.floor(5 + 6 * d)
    local window = st.seconds + 2.0
    local reveal = d >= 0.7 and 4 or nil           -- hard levels: only the next 4 arrows are shown, the rest is "?"
    local seq = {}
    for i = 1, n do seq[i] = math.random(1, #ARROWS) end
    local idx = 1
    local t0, lastPush = now(), 0
    local lives = st.mistakes + 1
    local maxLives = lives
    local list = {}
    for i, k in ipairs(seq) do list[i] = ARROWS[k].name end
    while alive() do
        local t = now()
        blockControls('sequence')
        local e = (t - t0) / 1000.0
        local left = window - e
        if spike(st, e) then idx = math.max(1, idx - 1) end    -- the scare makes you lose your place
        if t - lastPush > 60 then
            lastPush = t
            push({ game = 'sequence', seq = list, idx = idx, reveal = reveal, lives = lives, maxLives = maxLives, left = left, total = window })
        end
        for k, a in ipairs(ARROWS) do
            if IsDisabledControlJustPressed(0, a.code) or IsControlJustPressed(0, a.code) then
                if k == seq[idx] then
                    idx = idx + 1
                    UI.Send('resistTap', { good = true })
                else
                    lives = lives - 1
                    UI.Send('resistTap', { good = false })
                    if lives <= 0 then return false end
                    if d >= 0.7 then idx = 1 end           -- hard levels: a mistake sends you back to the start
                end
            end
        end
        if idx > n then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

-- ----------------------------------------------------------------------
-- Flow
-- ----------------------------------------------------------------------
function Resist.IsRunning() return running end

function Resist.Start(ctx)
    if running or not ctx then return false end
    running = true
    local sid = ctx.sid
    local R = Config.Resist
    local o = type(ctx.cfg.Resist) == 'table' and ctx.cfg.Resist or {}
    local L, levelName = Utils.ResistLevel(o.Level or R.Level)
    local chain = (ctx.type == 'takeover') and 1 or math.floor(Utils.Clamp(tonumber(L.Chain) or 1, 1, 5))
    -- the games of the chain: a different one each time when there are enough
    local pool, order = {}, {}
    for _, g in ipairs(R.Games) do if GAMES[g] then pool[#pool + 1] = g end end
    if #pool == 0 then pool = { 'mash' } end
    if o.Game and GAMES[o.Game] then pool = { o.Game } end
    local bag = {}
    for i = 1, chain do
        if #bag == 0 then for _, g in ipairs(pool) do bag[#bag + 1] = g end end
        order[i] = table.remove(bag, math.random(1, #bag))
    end
    cooldownUntil = now() + math.floor(R.Cooldown * 1000)
    local t0 = now()

    CreateThread(function()
        local won, cancelled = true, false
        for round = 1, chain do
            local st = settings(ctx, order[round])
            UI.Send('resistOpen', { game = st.game, key = R.KeyLabel, type = ctx.type, label = Locale('type_' .. ctx.type),
                seconds = st.seconds, level = levelName, round = round, rounds = chain })
            Wait(round == 1 and 550 or 450)   -- let the UI appear before the clock starts
            local ok, res = pcall(GAMES[st.game] or GAMES.mash, st, function() return Engine.sessions[sid] ~= nil and not Helpers.IsDead() end)
            if not ok then Utils.Error('resist: ' .. tostring(res)) res = nil end
            if res == nil then cancelled = true break end
            if res ~= true then won = false break end
            if round < chain then
                UI.Send('resistEnd', { ok = true, more = true })
                UI.Sound('resist_step', 'success', { volume = 0.5 })
                Wait(700)
            end
        end
        local elapsed = now() - t0
        running = false
        if cancelled then
            UI.Send('resistClose', {})
            return
        end
        UI.Send('resistEnd', { ok = won })
        UI.Sound('resist_end', won and 'success' or 'fail', { volume = 0.7 })
        Wait(1400)
        UI.Send('resistClose', {})
        TriggerServerEvent('universal_halluc:server:resist', sid, won, math.floor(elapsed))
    end)
    return true
end

local doneAt = {}   -- sid -> time the server confirmed the last result (the warning phase waits for it)

-- ----------------------------------------------------------------------
-- Warning phase: RESIST! is offered BEFORE a hallucination begins (Config.Resist.Onset)
-- ----------------------------------------------------------------------
--- Seconds of warning for this session, or nil when it should start right away.
function Resist.OnsetSeconds(ctx)
    local O = Config.Resist.Onset
    if type(O) ~= 'table' or O.Enabled == false or not Config.Resist.Enabled then return nil end
    if not allowed(ctx.type) or Utils.Contains(O.Exclude, ctx.type) then return nil end
    if ctx.controlled or ctx.params.selftest or Helpers.IsDead() then return nil end
    if ctx.intensity < (tonumber(O.MinIntensity) or 0.3) then return nil end
    if ctx.cfg.Onset == false then return nil end                      -- Config.Types.<type>.Onset = false opts a type out
    if Resist.IsRunning() then return nil end                          -- already fighting something else
    return Utils.Clamp(tonumber(O.Seconds) or 5.0, 1.5, 15.0)
end

--- Blocks (inside the session thread) while the player may resist; returns when the window is over or the fight is done.
function Resist.Onset(ctx, seconds)
    local R = Config.Resist
    local _, lvName = Utils.ResistLevel(R.Level)
    local untilT = now() + math.floor(seconds * 1000)
    local owner = ('s%d:onset'):format(ctx.sid)
    UI.Overlay(ctx.id('onv'), 'vignette', true, { strength = 0.4 + 0.35 * ctx.intensity, pulse = true })
    UI.Sound(ctx.id('onh'), 'heart_hard', { loop = true, volume = 0.7, fade = 0.4 })
    Visual.Shake(owner, 'HAND_SHAKE', 0.08 + 0.1 * ctx.intensity)
    UI.Send('resistPrompt', { on = true, key = R.KeyLabel, seconds = seconds, level = lvName, onset = true })
    promptUntil = untilT
    nextPrompt = math.max(nextPrompt, untilT + 20000)                  -- no second invitation right after this one

    local fought = false
    while ctx.alive() and now() < untilT do
        if running then fought = true break end
        Wait(50)
    end
    if fought then
        local began = now()
        while ctx.alive() and running do Wait(100) end
        -- the server answers a moment after the game ends: ended / weaker / stronger. Wait for it, then go on.
        local limit = now() + 2800
        while ctx.alive() and now() < limit and (doneAt[ctx.sid] or 0) < began do Wait(100) end
    end
    doneAt[ctx.sid] = nil
    UI.Send('resistPrompt', { on = false })
    promptUntil = 0
    UI.Overlay(ctx.id('onv'), 'vignette', false)
    UI.SoundStop(ctx.id('onh'), 1.0)
    Visual.ShakeOff(owner)
end

--- Server confirmed the result.
function Resist.Done(sid, success, ended)
    doneAt[sid] = now()
    local c = Engine.Get and Engine.Get(sid)
    if c and c.type == 'takeover' then
        Notify.Key(success and 'takeover_round_ok' or 'takeover_round_fail', success and 'success' or 'error')
        return
    end
    Notify.Key(ended and 'resist_ended' or (success and 'resist_ok' or 'resist_fail'), success and 'success' or 'warning')
end

-- key / prompt loop
CreateThread(function()
    nextPrompt = now() + math.floor((tonumber((Config.Resist.Prompt or {}).FirstAfter) or 4.0) * 1000)
    while true do
        if not Config.Resist.Enabled or Engine.Count() == 0 then
            Wait(800)
        else
            local ctx = pickSession()
            if not ctx then
                Wait(800)
            else
                local t = now()
                local P = Config.Resist.Prompt
                -- automatic invitation
                if P and P.Enabled and not running and t >= nextPrompt and t >= cooldownUntil then
                    nextPrompt = t + math.floor(Utils.Range(P.Every, 55.0) * 1000)
                    if ctx.intensity >= 0.25 then
                        promptUntil = t + math.floor((tonumber(P.Seconds) or 8) * 1000)
                        local _, lvName = Utils.ResistLevel(Config.Resist.Level)
                        UI.Send('resistPrompt', { on = true, key = Config.Resist.KeyLabel, seconds = tonumber(P.Seconds) or 8, level = lvName })
                        UI.Sound('resist_prompt', 'heartbeat', { volume = 0.6, rate = 1.5 })
                    end
                end
                if promptUntil > 0 and t > promptUntil then
                    promptUntil = 0
                    UI.Send('resistPrompt', { on = false })
                end
                -- key
                if not running and not State.panel and (IsControlJustPressed(0, RKEY())) then
                    if t >= cooldownUntil then
                        promptUntil = 0
                        UI.Send('resistPrompt', { on = false })
                        Resist.Start(ctx)
                    else
                        Notify.Key('resist_cooldown', 'inform', 2500, math.ceil((cooldownUntil - t) / 1000))
                    end
                end
                Wait(0)
            end
        end
    end
end)
