--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/helpers.lua - geometry, camera and model helpers used by the effects.
]]

Helpers = {}

local rad, deg = math.rad, math.deg

function Helpers.Now() return GetGameTimer() end

function Helpers.Ped() return PlayerPedId() end

function Helpers.Coords()
    local c = GetEntityCoords(PlayerPedId())
    return c.x, c.y, c.z
end

--- Camera heading in degrees (0-360), the way the player is looking.
function Helpers.CamHeading()
    local rot = GetGameplayCamRot(2)
    return (rot.z + 360.0) % 360.0
end

--- Unit vector (x, y) of a game heading (0 = north, counter-clockwise like GTA).
function Helpers.HeadingVec(h)
    local r = rad(h)
    return -math.sin(r), math.cos(r)
end

function Helpers.HeadingTo(fromX, fromY, toX, toY)
    local dx, dy = toX - fromX, toY - fromY
    return (deg(math.atan(-dx, dy)) + 360.0) % 360.0
end

--- Smallest signed angle between two headings, -180..180.
function Helpers.AngleDiff(a, b)
    local d = (a - b + 540.0) % 360.0 - 180.0
    return d
end

--- Is the point inside the player's view cone? (`halfAngle` in degrees)
function Helpers.IsInView(x, y, halfAngle)
    local px, py = Helpers.Coords()
    local want = Helpers.HeadingTo(px, py, x, y)
    return math.abs(Helpers.AngleDiff(Helpers.CamHeading(), want)) <= (halfAngle or 55.0)
end

--- Is the entity visible on screen and roughly in front of the camera?
function Helpers.IsLookingAt(entity, halfAngle)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return false end
    local c = GetEntityCoords(entity)
    if not Helpers.IsInView(c.x, c.y, halfAngle or 28.0) then return false end
    local px, py, pz = Helpers.Coords()
    if Utils.Dist3(px, py, pz, c.x, c.y, c.z) > 60.0 then return false end
    return HasEntityClearLosToEntity(PlayerPedId(), entity, 17)
end

--- Pan (-1 left .. 1 right) and "rear" (behind the player) of a world point relative to the camera.
function Helpers.PanOf(x, y)
    local px, py = Helpers.Coords()
    local rel = Helpers.AngleDiff(Helpers.HeadingTo(px, py, x, y), Helpers.CamHeading())  -- + = to the left
    local pan = -math.sin(rad(rel))
    local rear = math.abs(rel) > 100.0
    return Utils.Clamp(pan, -1.0, 1.0), rear
end

function Helpers.GroundZ(x, y, z)
    local ok, gz = GetGroundZFor_3dCoord(x, y, z + 1.5, false)
    if ok then return gz end
    return nil
end

function Helpers.IsIndoors()
    local ped = PlayerPedId()
    local ok, id = pcall(GetInteriorFromEntity, ped)
    return ok and id ~= nil and id ~= 0
end

function Helpers.InVehicle()
    return IsPedInAnyVehicle(PlayerPedId(), false)
end

function Helpers.IsDead()
    return IsPedDeadOrDying(PlayerPedId(), true)
end

--- Distance to the first wall / building / prop between two points (nil = the way is clear). Map only.
function Helpers.Blocked(x1, y1, z1, x2, y2, z2)
    local ok, hit, ex, ey, ez = pcall(function()
        local h = StartShapeTestLosProbe(x1, y1, z1, x2, y2, z2, 1, PlayerPedId(), 4)
        for _ = 1, 8 do
            local ret, did, c = GetShapeTestResult(h)
            if ret ~= 1 then return did, c and c.x, c and c.y, c and c.z end
            Wait(0)
        end
        return false
    end)
    if not ok or not hit then return nil end
    if ex then return Utils.Dist3(x1, y1, z1, ex, ey, ez) end
    return 0.0
end

--- Picks a random ground point at a distance from the player.
--- opts: behind (bool) | front (bool) | offscreen (bool) | maxZDiff (number)
--- Returns x, y, z, heading-to-player   or nil when no valid point was found.
function Helpers.PickSpot(minD, maxD, opts)
    opts = opts or {}
    local px, py, pz = Helpers.Coords()
    local cam = Helpers.CamHeading()
    local baseZ = opts.maxZDiff or 6.0

    -- pass 1: the ideal spot. pass 2: closer (narrow streets, indoors). pass 3: same but walls are ignored
    -- (a spot behind a wall is better than an effect that never appears at all).
    local passes = {
        { scale = 1.0, zmul = 1.0, los = opts.los ~= false, tries = 14 },
        { scale = 0.55, zmul = 1.6, los = opts.los ~= false, tries = 10 },
        { scale = 0.5, zmul = 2.0, los = false, tries = 8 },
    }
    for pi, pass in ipairs(passes) do
        local lo, hi = math.max(1.5, minD * pass.scale), math.max(2.5, maxD * pass.scale)
        for _ = 1, pass.tries do
            local dist = Utils.Rand(lo, hi)
            local rel
            if opts.behind then rel = Utils.Rand(135.0, 225.0)
            elseif opts.angle then rel = Utils.Rand(tonumber(opts.angle.min) or -60.0, tonumber(opts.angle.max) or 60.0)
            elseif opts.front then rel = Utils.Rand(-40.0, 40.0)
            else rel = Utils.Rand(0.0, 360.0) end
            if pi == 3 then rel = Utils.Rand(0.0, 360.0) end     -- last resort: any direction
            local h = (cam + rel) % 360.0
            local vx, vy = Helpers.HeadingVec(h)
            local x, y = px + vx * dist, py + vy * dist
            local gz = Helpers.GroundZ(x, y, pz)
            if gz and math.abs(gz - pz) <= baseZ * pass.zmul then
                if not (opts.offscreen and pi < 3 and Helpers.IsInView(x, y, 62.0)) then
                    -- not behind a wall: otherwise the player never sees it and it gets stuck against the building
                    if not pass.los or not Helpers.Blocked(px, py, pz + 0.7, x, y, gz + 1.0) then
                        return x, y, gz, Helpers.HeadingTo(x, y, px, py)
                    end
                end
            end
        end
    end
    Helpers.lastFail = { reason = 'no_spot', at = GetGameTimer() }
    return nil
end

--- Loads a model by name or hash. Returns the hash or nil (never blocks longer than `timeout` ms).
function Helpers.LoadModel(model, timeout)
    local hash = type(model) == 'number' and model or joaat(tostring(model))
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        Helpers.lastModelFail = tostring(model)
        return nil
    end
    if HasModelLoaded(hash) then return hash end
    RequestModel(hash)
    local deadline = GetGameTimer() + (timeout or 3500)
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then
            SetModelAsNoLongerNeeded(hash)
            Helpers.lastModelFail = tostring(model)
            return nil
        end
        Wait(20)
    end
    return hash
end

function Helpers.LoadAnimDict(dict, timeout)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + (timeout or 2500)
    while not HasAnimDictLoaded(dict) do
        if GetGameTimer() > deadline then return false end
        Wait(20)
    end
    return true
end

function Helpers.LoadClipSet(set, timeout)
    if HasClipSetLoaded(set) then return true end
    RequestClipSet(set)
    local deadline = GetGameTimer() + (timeout or 2500)
    while not HasClipSetLoaded(set) do
        if GetGameTimer() > deadline then return false end
        Wait(20)
    end
    return true
end

--- Loads a particle asset (true when ready within the timeout).
function Helpers.LoadPtfx(asset, timeout)
    if type(asset) ~= 'string' or asset == '' then return false end
    if HasNamedPtfxAssetLoaded(asset) then return true end
    RequestNamedPtfxAsset(asset)
    local deadline = GetGameTimer() + (timeout or 700)
    while not HasNamedPtfxAssetLoaded(asset) do
        if GetGameTimer() > deadline then return false end
        Wait(20)
    end
    return true
end

--- Resolves a server id into a ped on THIS client (nil when the player is not streamed in).
function Helpers.PedOfServerId(serverId)
    local pl = GetPlayerFromServerId(tonumber(serverId) or -1)
    if not pl or pl == -1 then return nil end
    local ped = GetPlayerPed(pl)
    if ped and ped ~= 0 and DoesEntityExist(ped) then return ped end
    return nil
end

--- Multiplies a { min, max } range or a number by intensity (0..1) mapped to 0.4..1.6.
function Helpers.IScale(intensity)
    return 0.4 + 1.2 * Utils.Clamp(intensity or 0.5, 0.0, 1.0)
end
