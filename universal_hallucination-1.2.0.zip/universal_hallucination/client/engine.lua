--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/engine.lua - runs one session per hallucination: context, threads, automatic cleanup.

    A handler (Fx.Register) receives a `ctx`:
        ctx.sid, ctx.type, ctx.cfg, ctx.intensity (0..1), ctx.subject, ctx.controlled, ctx.params
        ctx.alive()            -> false once the session is stopped or expired
        ctx.left()             -> seconds left
        ctx.wait(ms)           -> sleeps in small steps, returns ctx.alive()
        ctx.thread(fn)         -> CreateThread that is wrapped in pcall and stops with the session
        ctx.onStop(fn)         -> cleanup callback (runs in reverse order, always)
        ctx.opt(Name, name)    -> value from the start params (lowercase name) or the type config (Name)
        ctx.id(suffix)         -> NUI id owned by this session (cleared automatically)
        ctx.finish()           -> ends the session from inside the handler
        ctx.canSpawn()         -> false when entities are not allowed right now (driving, dead...)
]]

Engine = { sessions = {} }

local function now() return GetGameTimer() end

local function buildCtx(sid, typeKey, data)
    local cfg = Config.Types[typeKey] or {}
    local ctx = {
        sid = sid, type = typeKey, cfg = cfg,
        intensity = Utils.Clamp(tonumber(data.intensity) or cfg.Intensity or 0.5, 0.0, 1.0),
        subject = tonumber(data.subject),
        controlled = data.controlled == true,
        params = type(data.params) == 'table' and data.params or {},
        endsAt = now() + math.floor((tonumber(data.duration) or cfg.Duration or 30) * 1000),
        stopped = false,
        stops = {},
        updaters = {},
        produced = {},          -- what the effect has made so far (entity / ui / visual ...): the health check reads it
    }

    function ctx.alive() return not ctx.stopped and now() < ctx.endsAt end
    function ctx.left() return math.max(0.0, (ctx.endsAt - now()) / 1000.0) end

    function ctx.wait(ms)
        local target = now() + ms
        while ctx.alive() and now() < target do
            Wait(math.max(0, math.min(100, target - now())))
        end
        return ctx.alive()
    end

    function ctx.thread(fn)
        CreateThread(function()
            local ok, err = pcall(fn)
            if not ok then
                Utils.Error(('%s (session %s): %s'):format(typeKey, tostring(sid), tostring(err)))
                ctx.failReason = 'error'
                Engine.Report(ctx, false, 'error: ' .. tostring(err):sub(1, 70))
            end
        end)
    end

    --- Something visible / audible was made for this session (counts for the health check).
    function ctx.note(kind) ctx.produced[kind or 'x'] = (ctx.produced[kind or 'x'] or 0) + 1 end

    --- A handler that cannot do its job says why (shown to admins in Diagnostics).
    function ctx.fail(reason) ctx.failReason = tostring(reason or 'no_effect') end

    function ctx.onStop(fn) ctx.stops[#ctx.stops + 1] = fn end

    --- Registers a function that re-applies the effect when the intensity changes live (resist / Director).
    function ctx.live(fn, skipNow)
        ctx.updaters[#ctx.updaters + 1] = fn
        if not skipNow then pcall(fn) end
    end

    function ctx.opt(name, lower)
        local v = ctx.params[lower or name:lower()]
        if v == nil then v = ctx.params[name] end
        if v == nil then v = cfg[name] end
        return v
    end

    function ctx.id(suffix) return ('s%d:%s'):format(sid, suffix or ctx.type) end

    function ctx.finish() Engine.Stop(sid, true) end

    function ctx.canSpawn()
        if not ctx.alive() then return false end
        if Config.Safety.NoEntitiesWhileDriving and Helpers.InVehicle() then return false end
        if Helpers.IsDead() then return false end
        return true
    end

    return ctx
end

--- Starts a session from the server's `client:start` event.
function Engine.Start(sid, typeKey, data)
    if type(sid) ~= 'number' or type(typeKey) ~= 'string' or type(data) ~= 'table' then return end
    if Engine.sessions[sid] then Engine.Stop(sid, false) end

    local handler = Fx.handlers[typeKey]
    if not handler then
        Utils.Warn('no client effect for type ' .. typeKey)
        TriggerServerEvent('universal_halluc:server:ended', sid)
        return
    end

    local ctx = buildCtx(sid, typeKey, data)
    Engine.sessions[sid] = ctx
    Utils.Debug('start', sid, typeKey, ctx.intensity)

    ctx.thread(function()
        -- warning phase: RESIST! is offered BEFORE the effect begins (Config.Resist.Onset)
        local onset = Resist and Resist.OnsetSeconds and Resist.OnsetSeconds(ctx)
        if onset then
            ctx.endsAt = ctx.endsAt + math.floor(onset * 1000)       -- the warning does not eat the duration
            ctx.note('onset')
            local ok, err = pcall(Resist.Onset, ctx, onset)
            if not ok then Utils.Debug('onset failed', tostring(err)) end
        end
        if not ctx.alive() then return end
        ctx.handlerAt = now()
        handler(ctx)
    end)
    Engine.Watch(ctx)
end

--- ctx.note() for a session id (used by Ents / UI / Visual when they make something for a session).
function Engine.Note(sid, kind)
    local ctx = Engine.sessions[sid]
    if ctx then ctx.note(kind) end
end

-- ----------------------------------------------------------------------
-- Health: did the effect do anything? If not, say why and run a simple fallback scare.
-- ----------------------------------------------------------------------
local ENTITY_CATS = { entity = true }

function Engine.GuessReason(ctx)
    if ctx.failReason then return ctx.failReason end
    local meta = Registry and Registry.Types and Registry.Types[ctx.type]
    local entityType = meta and ENTITY_CATS[meta.cat]
    if Helpers.IsDead() then return 'dead' end
    if entityType and Config.Safety.NoEntitiesWhileDriving and Helpers.InVehicle() then return 'in_vehicle' end
    local f = Ents.lastFail
    if entityType and f and now() - f.at < 40000 then return f.reason end
    f = Helpers.lastFail
    if entityType and f and now() - f.at < 40000 then return f.reason end
    return 'no_effect'
end

function Engine.Report(ctx, ok, reason)
    if ctx.reported and ctx.reported == (ok and 'ok' or 'fail') then return end
    ctx.reported = ok and 'ok' or 'fail'
    local n = 0
    for _, v in pairs(ctx.produced) do n = n + v end
    TriggerServerEvent('universal_halluc:server:health', ctx.sid, ok == true, tostring(reason or ''), n)
end

--- A small scare so a failed effect is never silent: dark edges, heartbeat, a faint shake.
function Engine.Fallback(ctx)
    local I = ctx.intensity
    local owner = ('s%d:fallback'):format(ctx.sid)
    UI.Overlay(ctx.id('fbv'), 'vignette', true, { strength = 0.35 + 0.4 * I, pulse = true })
    UI.Sound(ctx.id('fbh'), 'heartbeat', { loop = true, volume = 0.45 + 0.4 * I, rate = 1.0 + 0.5 * I, fade = 1.2 })
    Visual.Shake(owner, 'HAND_SHAKE', 0.12 + 0.2 * I)
    ctx.onStop(function() Visual.ShakeOff(owner) end)
    CreateThread(function()
        local until_ = now() + math.floor(math.min(ctx.left(), 25.0) * 1000)
        while ctx.alive() and now() < until_ do Wait(500) end
        if Engine.sessions[ctx.sid] == ctx then
            UI.Overlay(ctx.id('fbv'), 'vignette', false)
            UI.SoundStop(ctx.id('fbh'), 1.5)
            Visual.ShakeOff(owner)
        end
    end)
end

function Engine.Watch(ctx)
    local H = Config.Health
    if type(H) ~= 'table' or H.Enabled == false then return end
    local selftest = ctx.params.selftest == true
    local meta = Registry and Registry.Types and Registry.Types[ctx.type]
    local isEntity = meta ~= nil and ENTITY_CATS[meta.cat] == true
    CreateThread(function()
        local guard = now() + 90000
        while ctx.alive() and not ctx.handlerAt and now() < guard do Wait(200) end
        if not ctx.alive() or not ctx.handlerAt then return end
        -- people / creatures should show up soon; give effects that wait for a random moment a fair chance
        local after
        if selftest then after = 5.5
        elseif isEntity then after = math.min(30.0, math.max(tonumber(H.CheckAfter) or 6.0, 10.0, ctx.left() * 0.35))
        else after = math.min(25.0, math.max(tonumber(H.CheckAfter) or 6.0, ctx.left() * 0.3)) end
        local target = ctx.handlerAt + math.floor(after * 1000)
        while ctx.alive() and not ctx.stopped and now() < target do Wait(150) end
        if not ctx.alive() then return end
        local n = 0
        for k, v in pairs(ctx.produced) do if k ~= 'onset' then n = n + v end end
        local signal = n > 0       -- something was made for this session (a person, an overlay, a sound, a screen change)
        -- an entity type that made no entity has failed; any other type is judged only by an explicit failure
        -- (many screen / audio effects have no visible trace to count, so silence is not proof)
        local failed = ctx.failReason ~= nil or (isEntity and not signal)
        if not failed then
            if selftest then Engine.Report(ctx, true, signal and 'ok' or 'no_signal') end
            return
        end
        local why = Engine.GuessReason(ctx)
        Utils.Warn(('%s did nothing visible (%s)'):format(ctx.type, why))
        Engine.Report(ctx, false, why)
        if H.Fallback ~= false and not selftest then Engine.Fallback(ctx) end
    end)
end

--- Stops one session and removes everything it created.
function Engine.Stop(sid, tellServer)
    local ctx = Engine.sessions[sid]
    if not ctx then return end
    Engine.sessions[sid] = nil
    ctx.stopped = true
    for i = #ctx.stops, 1, -1 do
        local ok, err = pcall(ctx.stops[i])
        if not ok then Utils.Debug('cleanup error', tostring(err)) end
    end
    ctx.stops = {}
    Ents.CleanSession(sid)
    if Dialogue then Dialogue.CleanSession(sid) end
    UI.Send('clearSession', { prefix = ('s%d:'):format(sid) })
    if tellServer then TriggerServerEvent('universal_halluc:server:ended', sid) end
end

function Engine.StopAll(tellServer)
    local ids = {}
    for sid in pairs(Engine.sessions) do ids[#ids + 1] = sid end
    for _, sid in ipairs(ids) do Engine.Stop(sid, tellServer) end
    -- anything that might still be left
    Ents.CleanAll()
    if Visual and Visual.Reset then Visual.Reset() end
    UI.ClearAll()
end

--- Live intensity change from the server (resist mini-game, /hadjust, panel slider).
function Engine.Update(sid, intensity)
    local ctx = Engine.sessions[sid]
    if not ctx then return end
    ctx.intensity = Utils.Clamp(tonumber(intensity) or ctx.intensity, 0.0, 1.0)
    for _, fn in ipairs(ctx.updaters) do pcall(fn) end
end

function Engine.Count()
    local n = 0
    for _ in pairs(Engine.sessions) do n = n + 1 end
    return n
end

function Engine.Get(sid) return Engine.sessions[sid] end

--- Sessions expire here; a dead player ends everything.
CreateThread(function()
    while true do
        Wait(250)
        if next(Engine.sessions) then
            local dead = Config.Safety.StopOnDeath and Helpers.IsDead()
            local ids = {}
            for sid, ctx in pairs(Engine.sessions) do
                if dead or now() >= ctx.endsAt then ids[#ids + 1] = sid end
            end
            for _, sid in ipairs(ids) do Engine.Stop(sid, true) end
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    Engine.StopAll(false)
    if State.panel then SetNuiFocus(false, false) end
    ClearTimecycleModifier()
    SetTimeScale(1.0)
end)
