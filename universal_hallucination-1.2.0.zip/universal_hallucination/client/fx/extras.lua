--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/extras.lua - instant cues (the "show") and possession (watching through the admin's eyes).
]]

-- ======================================================================
-- Cues: short, local, harmless
-- ======================================================================
Cue = {}

local cueSeq = 0

local function pseudoCtx(seconds, intensity)
    cueSeq = cueSeq + 1
    local id = cueSeq
    local untilT = GetGameTimer() + math.floor(seconds * 1000)
    return {
        sid = -id, type = 'cue', cfg = { Volume = 0.9 }, intensity = intensity,
        alive = function() return GetGameTimer() < untilT end,
        id = function(s) return ('cue%d:%s'):format(id, s or 'x') end,
        live = function() end, onStop = function() end, note = function() end,
    }
end

local running = {}   -- cue name -> true (a cue does not stack on itself)

local RUN = {}

RUN.jumpscare = function(ctx, sec, I)
    UI.Send('cue', { name = 'jumpscare', seconds = sec, strength = I })
    UI.Sound(ctx.id('js'), 'jumpscare', { volume = 1.0 })
    if Config.Sounds.Layered ~= false then UI.Sound(ctx.id('js2'), 'shriek', { volume = 0.55 }) end   -- a second layer: the scream on top of the hit
    Visual.Kick('LARGE_EXPLOSION_SHAKE', 0.35 + 0.4 * I)
    UI.Flash('#FFFFFF', 90, 0.9)
end

RUN.blackout = function(ctx, sec, I)
    UI.Send('cue', { name = 'blackout', seconds = sec, strength = I })
    UI.Sound(ctx.id('bo'), 'thump', { volume = 0.9 })
    pcall(SetArtificialLightsState, true)
    pcall(SetArtificialLightsStateAffectsVehicles, false)
    SetTimeout(math.floor(sec * 1000), function()
        pcall(SetArtificialLightsState, false)
    end)
end

RUN.heartbeat_rush = function(ctx, sec, I)
    local id = ctx.id('hb')
    UI.Sound(id, 'heartbeat', { loop = true, volume = 1.0, rate = 1.7, fade = 0.4 })
    UI.Send('cue', { name = 'pulse', seconds = sec, strength = I })
    local o = 'cue_hb'
    Visual.Shake(o, 'HAND_SHAKE', 0.3 + 0.3 * I)
    SetTimeout(math.floor(sec * 1000), function()
        UI.SoundStop(id, 1.2)
        Visual.ShakeOff(o)
    end)
end

RUN.glitch = function(ctx, sec, I)
    UI.Send('cue', { name = 'glitch', seconds = sec, strength = I })
    UI.Sound(ctx.id('gl'), 'glitch', { volume = 0.8 })
end

RUN.quake = function(ctx, sec, I)
    local o = 'cue_quake'
    Visual.Shake(o, 'LARGE_EXPLOSION_SHAKE', 0.25 + 0.35 * I)
    UI.Sound(ctx.id('qk'), 'rumble', { volume = 1.0, loop = true, fade = 0.3 })
    SetTimeout(math.floor(sec * 1000), function()
        Visual.ShakeOff(o)
        UI.SoundStop(ctx.id('qk'), 1.0)
    end)
end

RUN.whispers = function(ctx, sec, I)
    CreateThread(function()
        local n = math.max(3, math.floor(sec / 1.6))
        for i = 1, n do
            if not ctx.alive() then break end
            local x, y = Audio.PointFor('around', Utils.Rand(1.5, 5.0))
            Audio.PlayAt(ctx, 'whisper_' .. math.random(1, 3), x, y, 0.5 + 0.5 * I)
            Wait(math.random(600, 1600))
        end
    end)
end

RUN.blood_rain = function(ctx, sec, I)
    local id = ctx.id('br')
    UI.Overlay(id, 'blood', true, { strength = 0.7 + 0.3 * I, color = Config.UI.BloodColor })
    UI.Sound(ctx.id('brs'), 'sting', { volume = 0.7 })
    SetTimeout(math.floor(sec * 1000), function() UI.Overlay(id, 'blood', false) end)
end

RUN.freeze = function(ctx, sec, I)
    UI.Send('cue', { name = 'frost', seconds = sec, strength = I })
    UI.Sound(ctx.id('fr'), 'breath_cold', { volume = 0.9 })
end

RUN.eye_blink = function(ctx, sec, I)
    Visual.EyeRound(ctx, { mode = 'lids', pattern = 'blink', blinks = 2, seconds = math.max(3.0, sec), intensity = I })
end

function Cue.Run(name, seconds, intensity)
    local fn = RUN[name]
    if not fn or running[name] then return end
    running[name] = true
    seconds = Utils.Clamp(tonumber(seconds) or 3.0, 0.5, 30.0)
    intensity = Utils.Clamp(tonumber(intensity) or 0.8, 0.1, 1.0)
    local ctx = pseudoCtx(seconds + 1.0, intensity)
    local ok, err = pcall(fn, ctx, seconds, intensity)
    if not ok then Utils.Error('cue ' .. name .. ': ' .. tostring(err)) end
    SetTimeout(math.floor(seconds * 1000) + 300, function() running[name] = nil end)
end

-- ======================================================================
-- Possession
-- ======================================================================
Possessing = { target = nil, ctrl = nil }

local lastCam = nil      -- latest packet from the controller
local camHandle = nil

local function setMute(on)
    if Custom and type(Custom.Mute) == 'function' then
        pcall(Custom.Mute, on)
        return
    end
    pcall(NetworkSetVoiceActive, not on)
end

--- TARGET side: frozen, silent, looking through the controller's camera.
Fx.Register('possess', function(ctx)
    local P = Config.Possess
    local ped = PlayerPedId()
    lastCam = nil
    local cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    camHandle = cam
    local first = true

    if P.FreezeTarget then FreezeEntityPosition(ped, true) end
    if P.MuteTarget then setMute(true) end
    if P.ShowHud then UI.Send('possessHud', { on = true, role = 'target', seconds = ctx.left() }) end

    ctx.onStop(function()
        lastCam, camHandle = nil, nil
        RenderScriptCams(false, true, 600, true, false)
        SetCamActive(cam, false)
        DestroyCam(cam, false)
        ClearFocus()
        local p = PlayerPedId()
        FreezeEntityPosition(p, false)
        if P.MuteTarget then setMute(false) end
        UI.Send('possessHud', { on = false })
    end)

    local cx, cy, cz, crx, cry, crz, cfov
    while ctx.alive() do
        DisableAllControlActions(0)
        EnableControlAction(0, 200, true)    -- pause menu stays available
        if lastCam then
            local c = lastCam
            if first then
                cx, cy, cz, crx, cry, crz, cfov = c.x, c.y, c.z, c.rx, c.ry, c.rz, c.fov
                SetCamCoord(cam, cx, cy, cz)
                SetCamRot(cam, crx, cry, crz, 2)
                SetCamFov(cam, cfov)
                SetCamActive(cam, true)
                RenderScriptCams(true, true, 700, true, false)
                first = false
            else
                -- smooth towards the newest packet
                local k = 0.35
                cx, cy, cz = cx + (c.x - cx) * k, cy + (c.y - cy) * k, cz + (c.z - cz) * k
                crx = crx + (c.rx - crx) * k
                cry = cry + (c.ry - cry) * k
                crz = crz + Helpers.AngleDiff(c.rz, crz) * k
                cfov = cfov + (c.fov - cfov) * k
                SetCamCoord(cam, cx, cy, cz)
                SetCamRot(cam, crx, cry, crz, 2)
                SetCamFov(cam, cfov)
            end
            SetFocusPosAndVel(cx, cy, cz, 0.0, 0.0, 0.0)
        end
        Wait(0)
    end
end)

function Possessing.OnCam(sid, x, y, z, rx, ry, rz, fov)
    if not Engine.Get(sid) then return end
    lastCam = { x = x, y = y, z = z, rx = rx, ry = ry, rz = rz, fov = fov }
end

--- CONTROLLER side: streams his camera to the server (which relays it to the target).
function Possessing.Info(sid, on, target, targetName, seconds)
    if not on then
        Possessing.target = nil
        UI.Send('possessHud', { on = false })
        return
    end
    Possessing.target = sid
    local hz = Utils.Clamp(tonumber(Config.Possess.CamHz) or 12, 4, 20)
    local gap = math.floor(1000 / hz)
    UI.Send('possessHud', {
        on = true, role = 'controller', name = targetName, seconds = seconds,
        cmd = Config.Commands.Unpossess,
    })
    CreateThread(function()
        while Possessing.target == sid do
            local c = GetFinalRenderedCamCoord()
            local r = GetFinalRenderedCamRot(2)
            TriggerServerEvent('universal_halluc:server:possessCam', sid,
                c.x + 0.0, c.y + 0.0, c.z + 0.0, r.x + 0.0, r.y + 0.0, r.z + 0.0, GetFinalRenderedCamFov() + 0.0)
            Wait(gap)
        end
    end)
end
