--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/takeover.lua - the target's side of the "takeover by swapping" (see server/takeover.lua).

      takeover        the duel: rounds of the resist mini-game until the server decides
      takeover_ghost  after losing: invincible, unseen and unheard (except by the controller); frozen, or free to walk
                      inside a small radius when the controller chose "the watcher moves" (params.move)
      takeoverLock    (event) the CONTROLLER's rules: no inventory, no weapons, no melee, no vehicles (Config.Takeover.Controller)
]]

local function owner(ctx) return ctx.id('to') end

Fx.Register('takeover', function(ctx)
    UI.Overlay(ctx.id('tint'), 'tint', true, { color = '#5A0000', strength = 0.35, pulse = true })
    UI.Overlay(ctx.id('vig'), 'vignette', true, { color = '#000000', strength = 0.6, pulse = true })
    UI.Sound(ctx.id('hb'), 'heartbeat', { loop = true, volume = 0.9, rate = 1.4, fade = 0.5 })
    UI.Flash('#FFFFFF', 160, 0.5)
    local o = owner(ctx)
    Visual.Shake(o, 'DRUNK_SHAKE', 0.2)
    ctx.onStop(function() Visual.ShakeOff(o) end)

    if not ctx.wait(1500) then return end
    while ctx.alive() do
        if not Resist.IsRunning() and not Helpers.IsDead() then
            Resist.Start(ctx)
            ctx.wait(800)
            while ctx.alive() and Resist.IsRunning() do ctx.wait(100) end
            if not ctx.wait(2200) then break end     -- the result stays on the screen for a moment
        else
            ctx.wait(300)
        end
    end
end)

local UNARMED = GetHashKey('WEAPON_UNARMED')

--- Weapons are put away and every way of attacking is switched off for this frame.
local WEAPON_CTRL = { 24, 25, 37, 45, 47, 58, 68, 69, 70, 91, 92, 99, 100, 114, 12, 13, 14, 15, 16, 17, 157, 158, 159, 160, 161, 162, 163, 164, 165, 257, 261, 262 }
local MELEE_CTRL = { 140, 141, 142, 143, 263, 264 }
local MOVE_CTRL = { 30, 31, 32, 33, 34, 35, 21, 22, 36, 1, 2, 249, 200 }

local function putWeaponsAway(ped)
    if GetSelectedPedWeapon(ped) ~= UNARMED then SetCurrentPedWeapon(ped, UNARMED, true) end
    DisablePlayerFiring(PlayerId(), true)
    HudWeaponWheelIgnoreSelection()
    HideHudComponentThisFrame(19)
    for _, c in ipairs(WEAPON_CTRL) do DisableControlAction(0, c, true) end
end

local function blockMelee()
    for _, c in ipairs(MELEE_CTRL) do DisableControlAction(0, c, true) end
end

Fx.Register('takeover_ghost', function(ctx)
    local K = Config.Takeover or {}
    local G = K.Ghost or {}
    local o = owner(ctx)
    local ped = PlayerPedId()
    local move = ctx.params.move == true
    local roam = Utils.Num(G.MaxRoam, 25.0, 3.0, 200.0)
    local h0 = GetEntityCoords(ped)
    local home = { x = h0.x, y = h0.y, z = h0.z }
    local last = { x = h0.x, y = h0.y, z = h0.z }

    UI.Send('possessHud', { on = true, role = 'ghost', seconds = ctx.left(), move = move })
    UI.Overlay(ctx.id('vig'), 'vignette', true, { color = '#0A1A33', strength = 0.35, pulse = false })
    Visual.Timecycle(o, 'NG_filmic02', 0.35)
    ctx.note('ghost')
    if move then pcall(SetLocalPlayerAsGhost, true) end          -- walking watcher: no collision with other players

    ctx.onStop(function()
        local p = PlayerPedId()
        FreezeEntityPosition(p, false)
        SetEntityInvincible(p, false)
        if move then pcall(SetLocalPlayerAsGhost, false) end
        Visual.TimecycleOff(o)
        UI.Send('possessHud', { on = false })
    end)

    while ctx.alive() do
        ped = PlayerPedId()
        if G.Invincible ~= false then SetEntityInvincible(ped, true) end
        DisableAllControlActions(0)
        if move then
            -- he may walk and look around, nothing else: no weapons, no vehicles, no interaction
            FreezeEntityPosition(ped, false)
            for _, c in ipairs(MOVE_CTRL) do EnableControlAction(0, c, true) end
            putWeaponsAway(ped)
            blockMelee()
            DisableControlAction(0, 23, true)      -- no vehicles
            local pos = GetEntityCoords(ped)
            if Utils.Dist3(pos.x, pos.y, pos.z, home.x, home.y, home.z) > roam then
                SetEntityCoords(ped, last.x, last.y, last.z, false, false, false, false)     -- back to the last spot inside the radius
            else
                last.x, last.y, last.z = pos.x, pos.y, pos.z
            end
        else
            if G.Freeze ~= false then FreezeEntityPosition(ped, true) end
            EnableControlAction(0, 1, true)      -- look
            EnableControlAction(0, 2, true)
            EnableControlAction(0, 249, true)    -- push to talk
            EnableControlAction(0, 200, true)    -- pause menu
        end
        EnableControlAction(0, 249, true)        -- push to talk
        Wait(0)
    end
end)

-- ----------------------------------------------------------------------
-- The CONTROLLER's rules while he plays the player's character (server: Takeover.Lock)
-- ----------------------------------------------------------------------
local lock = { token = 0, on = false }

local function inventoryBusy(on)
    pcall(function() LocalPlayer.state:set('invBusy', on, false) end)      -- ox_inventory
    pcall(function() LocalPlayer.state:set('inv_busy', on, false) end)     -- qb-inventory
    if on then
        pcall(function() if GetResourceState('ox_inventory') == 'started' then exports.ox_inventory:closeInventory() end end)
    end
    if Custom and type(Custom.Takeover) == 'table' and type(Custom.Takeover.Inventory) == 'function' then
        pcall(Custom.Takeover.Inventory, on)       -- your own inventory: close it / forbid it here (bridge/custom.lua)
    end
end

function TakeoverLock(on, o)
    lock.token = lock.token + 1
    local token = lock.token
    if not on then
        if lock.on then
            lock.on = false
            inventoryBusy(false)
            pcall(SetPlayerCanDoDriveBy, PlayerId(), true)
        end
        return
    end
    o = type(o) == 'table' and o or {}
    lock.on = true
    local untilAt = GetGameTimer() + math.floor((tonumber(o.seconds) or 300) * 1000) + 5000   -- failsafe: never stays locked forever
    if o.inventory then inventoryBusy(true) end
    CreateThread(function()
        local nextNote, nextInv = 0, GetGameTimer() + 1500
        while lock.on and lock.token == token and GetGameTimer() < untilAt do
            local ped = PlayerPedId()
            local t = GetGameTimer()
            if o.weapons then
                putWeaponsAway(ped)
                pcall(SetPlayerCanDoDriveBy, PlayerId(), false)
            end
            if o.melee then blockMelee() end
            if o.vehicles then DisableControlAction(0, 23, true) end
            if o.inventory then DisableControlAction(0, 289, true) end
            -- tell him once in a while why nothing happens
            if t >= nextNote and (IsDisabledControlJustPressed(0, 24) or IsDisabledControlJustPressed(0, 37) or IsDisabledControlJustPressed(0, 289) or IsDisabledControlJustPressed(0, 23)) then
                nextNote = t + 4000
                Notify.Key('takeover_locked', 'warning', 3000)
            end
            if o.inventory and t >= nextInv then
                nextInv = t + 1500
                inventoryBusy(true)
            end
            Wait(0)
        end
        if lock.token == token and lock.on then TakeoverLock(false) end
    end)
end

RegisterNetEvent('universal_halluc:client:takeoverLock', function(on, o)
    TakeoverLock(on == true, o)
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then TakeoverLock(false) end
end)
