--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/entities.lua - safe LOCAL peds for hallucinations.

    Every ped is created with isNetwork = false: it exists only on this client, nobody else can see
    or interact with it. Every ped is harmless by construction (invincible, no combat, passes through the
    player, neutral relationship group, no ammo) and is tracked per session so it is always cleaned up.

    IMPORTANT: the ped keeps its world collision. A ped with SetEntityCollision(false) FALLS THROUGH THE MAP
    (it vanishes under the ground). Instead it only ignores the player (SetEntityNoCollisionEntity).
]]

Ents = {}

local bySession = {}   -- sid -> { [ped] = true }
local GROUP = joaat('UNIVERSAL_HALLUC')
local groupReady = false

local function ensureGroup()
    if groupReady then return end
    groupReady = true
    pcall(AddRelationshipGroup, 'UNIVERSAL_HALLUC')
    pcall(SetRelationshipBetweenGroups, 3, GROUP, joaat('PLAYER'))
    pcall(SetRelationshipBetweenGroups, 3, joaat('PLAYER'), GROUP)
end

local watcher = false

local function track(sid, ped)
    bySession[sid] = bySession[sid] or {}
    bySession[sid][ped] = true
    if Engine and Engine.Note then Engine.Note(sid, 'entity') end
    if not watcher then
        watcher = true
        -- keeps every local ped passing through the player (the player handle changes after a respawn)
        CreateThread(function()
            while true do
                Wait(400)
                local any = false
                local me = PlayerPedId()
                for _, set in pairs(bySession) do
                    for p in pairs(set) do
                        if DoesEntityExist(p) then
                            any = true
                            pcall(SetEntityNoCollisionEntity, p, me, false)
                        end
                    end
                end
                if not any then Wait(1500) end
            end
        end)
    end
end

--- Makes a ped harmless and invisible to the world's AI.
local function harmless(ped, alpha, collision)
    ensureGroup()
    SetEntityAsMissionEntity(ped, true, true)
    SetEntityInvincible(ped, true)
    SetEntityCanBeDamaged(ped, false)
    SetPedCanRagdoll(ped, false)
    SetPedDiesWhenInjured(ped, false)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    SetPedCombatAttributes(ped, 46, false)
    SetPedCanBeTargetted(ped, false)
    SetPedSeeingRange(ped, 0.0)
    SetPedHearingRange(ped, 0.0)
    SetPedAlertness(ped, 0)
    SetPedRelationshipGroupHash(ped, GROUP)
    SetPedKeepTask(ped, true)
    pcall(SetEntityNoCollisionEntity, ped, PlayerPedId(), false)     -- the player walks through it, the ground still holds it
    if alpha and alpha < 255 then SetEntityAlpha(ped, math.floor(Utils.Clamp(alpha, 0, 255)), false) end
end

--- Spawns a local ped from a model name.
---@return number|nil ped
local function sessionGone(sid)
    -- a spawn that was waiting (model loading, line-of-sight test) must not create a ped after its session ended
    return type(sid) == 'number' and Engine and Engine.sessions and Engine.sessions[sid] == nil and sid > 0
end

function Ents.Spawn(sid, model, x, y, z, heading, alpha)
    local hash = Helpers.LoadModel(model)
    if sessionGone(sid) then
        if hash then SetModelAsNoLongerNeeded(hash) end
        return nil
    end
    if not hash then
        Utils.Debug('model not available, skipped:', tostring(model))
        Ents.lastFail = { reason = 'no_model:' .. tostring(model):sub(1, 40), at = GetGameTimer() }
        return nil
    end
    local ped = CreatePed(4, hash, x, y, z, heading or 0.0, false, false)
    SetModelAsNoLongerNeeded(hash)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return nil end
    harmless(ped, alpha)
    track(sid, ped)
    return ped
end

--- Clones an existing ped (copies face, clothes, props): needs no clothing system.
---@return number|nil ped
function Ents.Clone(sid, source, x, y, z, heading, alpha)
    if not source or source == 0 or not DoesEntityExist(source) then return nil end
    local ok, ped = pcall(ClonePed, source, false, false, true)
    if not ok or not ped or ped == 0 or not DoesEntityExist(ped) then return nil end
    harmless(ped, alpha)
    SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)
    SetEntityHeading(ped, heading or 0.0)
    ClearPedTasksImmediately(ped)
    track(sid, ped)
    return ped
end

--- Spawns the look a session asks for: 'model' | 'self' | 'subject'.
--- `models` is the list used when source = 'model'. Falls back to a model when the clone is impossible.
function Ents.Look(sid, source, models, subject, x, y, z, heading, alpha, overrideModel)
    if overrideModel and overrideModel ~= '' then
        return Ents.Spawn(sid, overrideModel, x, y, z, heading, alpha)
    end
    if source == 'self' then
        local p = Ents.Clone(sid, PlayerPedId(), x, y, z, heading, alpha)
        if p then return p end
    elseif source == 'subject' and subject then
        local other = Helpers.PedOfServerId(subject)
        if other then
            local p = Ents.Clone(sid, other, x, y, z, heading, alpha)
            if p then return p end
        end
    end
    local list = models
    if type(list) ~= 'table' or #list == 0 then list = { 'a_m_y_hipster_01' } end
    -- try up to 3 random models (a missing model never breaks the effect)
    for _ = 1, 3 do
        local p = Ents.Spawn(sid, Utils.Pick(list), x, y, z, heading, alpha)
        if p then return p end
    end
    return nil
end

function Ents.Exists(ped)
    return ped ~= nil and ped ~= 0 and DoesEntityExist(ped)
end

function Ents.Alpha(ped, alpha)
    if not Ents.Exists(ped) then return end
    alpha = math.floor(Utils.Clamp(alpha, 0, 255))
    if alpha >= 255 then ResetEntityAlpha(ped) else SetEntityAlpha(ped, alpha, false) end
end

--- Fades a ped out and deletes it (non-blocking).
function Ents.FadeOut(sid, ped, ms)
    if not Ents.Exists(ped) then return end
    CreateThread(function()
        local steps = 8
        local base = GetEntityAlpha(ped)
        if base == 0 then base = 255 end
        for i = steps, 0, -1 do
            if not Ents.Exists(ped) then return end
            SetEntityAlpha(ped, math.floor(base * i / steps), false)
            Wait(math.max(10, math.floor((ms or 400) / steps)))
        end
        Ents.Delete(sid, ped)
    end)
end

function Ents.Delete(sid, ped)
    if ped and ped ~= 0 and DoesEntityExist(ped) then
        SetEntityAsMissionEntity(ped, true, true)
        DeleteEntity(ped)
    end
    if sid and bySession[sid] then bySession[sid][ped] = nil end
end

function Ents.CleanSession(sid)
    local set = bySession[sid]
    if not set then return end
    bySession[sid] = nil
    for ped in pairs(set) do
        if DoesEntityExist(ped) then
            SetEntityAsMissionEntity(ped, true, true)
            DeleteEntity(ped)
        end
    end
end

function Ents.CleanAll()
    local list = {}
    for sid in pairs(bySession) do list[#list + 1] = sid end
    for _, sid in ipairs(list) do Ents.CleanSession(sid) end
end

function Ents.Count(sid)
    local n = 0
    for _ in pairs(bySession[sid] or {}) do n = n + 1 end
    return n
end

--- Walks a ped towards a point.
function Ents.Walk(ped, x, y, z, speed)
    if not Ents.Exists(ped) then return end
    TaskGoStraightToCoord(ped, x, y, z, speed or 1.0, -1, GetEntityHeading(ped), 0.0)
end

function Ents.Face(ped, x, y)
    if not Ents.Exists(ped) then return end
    local c = GetEntityCoords(ped)
    SetEntityHeading(ped, Helpers.HeadingTo(c.x, c.y, x, y))
end

function Ents.Stand(ped)
    if not Ents.Exists(ped) then return end
    TaskStandStill(ped, 1500)
end

--- A scenario idle animation (loops until cleared).
function Ents.Idle(ped, scenario)
    if not Ents.Exists(ped) then return end
    TaskStartScenarioInPlace(ped, scenario or 'WORLD_HUMAN_STAND_IMPATIENT', 0, true)
end

function Ents.Distance(ped)
    if not Ents.Exists(ped) then return 9999.0 end
    local px, py, pz = Helpers.Coords()
    local c = GetEntityCoords(ped)
    return Utils.Dist3(px, py, pz, c.x, c.y, c.z)
end
