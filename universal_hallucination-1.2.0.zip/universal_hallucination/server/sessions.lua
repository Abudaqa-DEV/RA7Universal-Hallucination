--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/sessions.lua - the authoritative engine (SERVER).

    A "session" = one hallucination of one type for one or more targets. The server validates everything
    (permissions are checked by the callers), clamps duration/intensity, enforces the safety rules, tells
    the target clients to run the effect (entities are local to the target, nobody else sees them) and
    ends it on time / death / disconnect.
]]

Hall = { Sessions = {}, Online = {} }

local Sessions = Hall.Sessions
local ByTarget = {}          -- [src] = { [sid] = true }
local nextSid = 0

local function now() return GetGameTimer() end

local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end

local function hook(name, ...)
    local f = Custom and Custom[name]
    if type(f) == 'function' then pcall(f, ...) end
end

local function pname(src)
    local n = (src and src > 0) and GetPlayerName(src) or nil
    return n or (src == 0 and 'console' or tostring(src))
end

--- Audit line (console + optional Discord webhook).
function Hall.Audit(text)
    if Config.Safety.LogToConsole then Utils.Log(text) end
    local url = Config.Safety.DiscordWebhook
    if type(url) == 'string' and url ~= '' and PerformHttpRequest then
        PerformHttpRequest(url, function() end, 'POST',
            json.encode({ username = Config.Brand.ScriptName, content = text:sub(1, 1800) }),
            { ['Content-Type'] = 'application/json' })
    end
end

local function updateBag(src)
    if not Config.Integration.StateBags then return end
    local n = 0
    for _ in pairs(ByTarget[src] or {}) do n = n + 1 end
    local ok = pcall(function()
        local st = Player(src).state
        st:set('halluc_active', n > 0, true)
        st:set('halluc_count', n, true)
    end)
    return ok
end

-- ----------------------------------------------------------------------
-- Online players (a client announces itself with the "ready" event)
-- ----------------------------------------------------------------------
function Hall.IsOnline(src)
    return src ~= nil and Hall.Online[src] ~= nil
end

function Hall.OnlineList()
    local l = {}
    for src in pairs(Hall.Online) do l[#l + 1] = src end
    table.sort(l)
    return l
end

function Hall.EndHooks(s, reason)
    if Director and Director.OnSessionEnd then Director.OnSessionEnd(s, reason) end
    if Possess and Possess.OnSessionEnd then Possess.OnSessionEnd(s, reason) end
    if Voice and Voice.OnSessionEnd then Voice.OnSessionEnd(s) end
    if Takeover and Takeover.OnSessionEnd then Takeover.OnSessionEnd(s, reason) end
    if World and World.OnSessionEnd then World.OnSessionEnd(s, reason) end
end

local function isDead(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    return GetEntityHealth(ped) <= 0
end

-- ----------------------------------------------------------------------
-- Parameter sanitising (nothing from a command or a client reaches the effect unchecked)
-- ----------------------------------------------------------------------
local SOURCES   = { model = true, self = true, subject = true }
local BEHAVIORS = { stare = true, follow = true, mimic = true }
local MODES = { ambush = true, crossfire = true, distant = true }
local DIRECTIONS = { behind = true, left = true, right = true, front = true, random = true, around = true }

local function modelAllowed(typeKey, model)
    local cfg = Config.Types[typeKey]
    if cfg and type(cfg.Models) == 'table' and Utils.Contains(cfg.Models, model) then return true end
    return Config.Safety.AllowCustomModels == true
end

local function sanitizeParams(typeKey, p)
    local out = {}
    if p == nil then return out end
    if type(p) ~= 'table' then return nil, 'invalid' end

    if p.model ~= nil then
        if type(p.model) ~= 'string' or #p.model > 64 or not p.model:match('^[%w_]+$') or not modelAllowed(typeKey, p.model) then
            return nil, 'bad_model'
        end
        out.model = p.model
    end
    if p.selftest == true then out.selftest = true end     -- only the server's own self-test sets this
    if p.move == true then out.move = true end                -- takeover: the watcher may walk (set by the server's Takeover module)
    if type(p.pressure) == 'string' and Config.Resist.Levels[p.pressure] then out.pressure = p.pressure end  -- takeover duel difficulty
    if SOURCES[p.source] then out.source = p.source end
    if BEHAVIORS[p.behavior] then out.behavior = p.behavior end
    if DIRECTIONS[p.direction] then out.direction = p.direction end
    if type(p.dialogue) == 'string' and Config.Dialogues[p.dialogue] then out.dialogue = p.dialogue end
    if p.alpha ~= nil then out.alpha = math.floor(Utils.Num(p.alpha, 150, 0, 255)) end
    if p.color ~= nil and Utils.IsHexColor(p.color) then out.color = p.color end
    if p.Color ~= nil and Utils.IsHexColor(p.Color) then out.color = p.Color end   -- scenarios use PascalCase
    if p.Dialogue ~= nil and type(p.Dialogue) == 'string' and Config.Dialogues[p.Dialogue] then out.dialogue = p.Dialogue end
    local sc = p.scene or p.Scene
    if sc ~= nil then
        if type(sc) ~= 'string' or not Config.Scenes[sc] then return nil, 'bad_scene' end
        if not Registry.SwitchOn('Scenes', sc) then return nil, 'scene_disabled' end
        out.scene = sc
    end
    local md = p.mode or p.Mode
    if MODES[md] then out.mode = md end
    if p.count ~= nil then out.count = math.floor(Utils.Num(p.count, 3, 1, 30)) end
    if p.speed ~= nil then out.speed = Utils.Num(p.speed, 1.0, 0.3, 3.0) end
    if type(p.weapon) == 'string' and #p.weapon <= 40 and p.weapon:match('^WEAPON_[%u%d_]+$') then out.weapon = p.weapon end
    return out
end

-- ----------------------------------------------------------------------
-- Targets
-- ----------------------------------------------------------------------
--- number | numeric string | 'all' | { ... }  ->  list of online server ids
function Hall.ResolveTargets(target)
    local list, seen = {}, {}
    local function add(v)
        v = tonumber(v)
        if v and not seen[v] and Hall.IsOnline(v) then
            seen[v] = true
            list[#list + 1] = v
        end
    end
    if target == 'all' then
        for _, s in ipairs(Hall.OnlineList()) do add(s) end
    elseif type(target) == 'table' then
        for _, v in ipairs(target) do add(v) end
    else
        add(target)
    end
    return list
end

local function countOf(src)
    local n = 0
    for _ in pairs(ByTarget[src] or {}) do n = n + 1 end
    return n
end

--- Can this player receive a hallucination? returns true or a locale key.
function Hall.CanReceive(src, opts)
    local o = Hall.Online[src]
    if not o then return 'player_not_found' end
    if Config.Safety.BlockWhenDead and isDead(src) then return 'blocked_dead' end
    if Config.Safety.BlockWhenBusy and Framework.IsBusy(src) then return 'blocked_busy' end
    if o.optout and Config.Safety.AllowOptOut and not opts.force then
        local fromScript = (opts.source == nil or opts.source == 'script')
        if not fromScript or Config.Safety.OptOutBlocksScripts then return 'blocked_optout' end
    end
    if countOf(src) >= Config.Safety.MaxConcurrentPerPlayer then return 'too_many' end
    return true
end

-- ----------------------------------------------------------------------
-- Start / send
-- ----------------------------------------------------------------------
local function send(s, src)
    local remaining = math.max(1, math.ceil((s.endsAt - now()) / 1000))
    TriggerClientEvent('universal_halluc:client:start', src, s.sid, s.type, {
        duration  = remaining,
        intensity = s.intensity,
        subject   = s.subject,
        controlled = s.controller ~= nil,
        params    = s.params,
    })
end

local function addTarget(s, src)
    s.targets[src] = true
    ByTarget[src] = ByTarget[src] or {}
    ByTarget[src][s.sid] = true
    updateBag(src)
end

local function nextTargetCount(s)
    local n = 0
    for _ in pairs(s.targets) do n = n + 1 end
    return n
end

--- Start a hallucination.
---@param target number|string|table   server id | 'all' | list
---@param typeKey string               a key of Config.Types
---@param opts? table  { duration, intensity, delay, subject, controller, params, source, force, by, scenario }
---@return number|false sid, string? reason, string? extra
function Hall.Start(target, typeKey, opts)
    opts = opts or {}

    if not Config.General.Enabled then return false, 'system_disabled' end
    if not Registry.Has(typeKey) then return false, 'unknown_type', tostring(typeKey) end
    if not Registry.IsEnabled(typeKey) then return false, 'type_disabled', typeKey end

    local meta, cfg = Registry.Types[typeKey], Config.Types[typeKey]

    local subject = tonumber(opts.subject)
    if meta.needsSubject and not subject then return false, 'need_subject' end
    if subject and not Hall.IsOnline(subject) then return false, 'subject_offline' end

    local params, perr = sanitizeParams(typeKey, opts.params)
    if not params then return false, perr end
    if params.source == 'subject' and not subject then return false, 'need_subject' end

    local controller = tonumber(opts.controller)
    if controller and not Hall.IsOnline(controller) then controller = nil end

    -- who actually runs the effect
    local requested = Hall.ResolveTargets(target)
    local viewers
    local scope = meta.scope or 'targets'
    local runOn = {}

    if scope == 'all_except' then
        if #requested == 0 then return false, 'player_not_found' end
        viewers = {}
        for _, v in ipairs(requested) do viewers[v] = true end
        for _, src in ipairs(Hall.OnlineList()) do
            if not viewers[src] and src ~= subject then runOn[#runOn + 1] = src end
        end
    else
        local firstFail
        for _, src in ipairs(requested) do
            if src ~= subject or not meta.needsSubject then
                local r = Hall.CanReceive(src, opts)
                if r == true then runOn[#runOn + 1] = src else firstFail = firstFail or r end
            end
        end
        if #runOn == 0 then return false, firstFail or 'player_not_found' end
    end

    local duration = Utils.Num(opts.duration, cfg.Duration, 1, Config.Safety.MaxDuration)
    local intensity = Utils.Num(opts.intensity, cfg.Intensity, Config.Safety.MinIntensity, 1.0)
    local delay = Utils.Num(opts.delay, 0, 0, 3600)

    nextSid = nextSid + 1
    local t = now()
    local s = {
        sid = nextSid, type = typeKey, targets = {}, viewers = viewers, scope = scope,
        subject = subject, controller = controller, params = params,
        intensity = intensity, startedAt = t,
        startsAt = t + math.floor(delay * 1000),
        endsAt = t + math.floor((delay + duration) * 1000),
        source = opts.source or 'script', by = opts.by, scenario = opts.scenario,
        sent = false,
    }
    Sessions[s.sid] = s
    for _, src in ipairs(runOn) do addTarget(s, src) end

    if delay <= 0 then
        s.sent = true
        for src in pairs(s.targets) do send(s, src) end
    end

    local first = runOn[1]
    Hall.Audit(('%s -> %s: %s (%.0fs, %.2f) session %d%s'):format(
        pname(opts.by or 0), scope == 'all_except' and ('viewers ' .. #requested) or (#runOn == 1 and pname(first) or (#runOn .. ' players')),
        typeKey, duration, intensity, s.sid, subject and (' subject ' .. subject) or ''))

    if Health and Health.OnStart then Health.OnStart(typeKey) end
    for src in pairs(s.targets) do
        emit('started', src, s.sid, typeKey)
        hook('OnStarted', src, s.sid, typeKey)
    end
    return s.sid
end

-- ----------------------------------------------------------------------
-- Stop
-- ----------------------------------------------------------------------
local function endedEvents(s, src, reason)
    emit('ended', src, s.sid, s.type, reason)
    hook('OnEnded', src, s.sid, s.type, reason)
end

--- Removes one target from a session (the session ends when nobody is left).
local function removeTarget(s, src, reason, notifyClient)
    if not s.targets[src] then return end
    s.targets[src] = nil
    if ByTarget[src] then
        ByTarget[src][s.sid] = nil
        if next(ByTarget[src]) == nil then ByTarget[src] = nil end
    end
    if notifyClient and s.sent and Hall.IsOnline(src) then
        TriggerClientEvent('universal_halluc:client:stop', src, s.sid)
    end
    updateBag(src)
    endedEvents(s, src, reason)
end

function Hall.Stop(sid, reason)
    local s = Sessions[sid]
    if not s then return false end
    reason = reason or 'stopped'
    Sessions[sid] = nil
    local list = {}
    for src in pairs(s.targets) do list[#list + 1] = src end
    for _, src in ipairs(list) do
        s.targets[src] = true
        removeTarget(s, src, reason, true)
    end
    Hall.EndHooks(s, reason)
    return true
end

--- Stops everything a player is running (sessions where he is a target). Returns the number stopped.
function Hall.StopFor(src, reason, onlyScriptless)
    local set = ByTarget[src]
    if not set then return 0 end
    local ids = {}
    for sid in pairs(set) do ids[#ids + 1] = sid end
    local n = 0
    for _, sid in ipairs(ids) do
        local s = Sessions[sid]
        if s then
            if onlyScriptless and (s.source == 'script' and not Config.Safety.OptOutBlocksScripts) then
                -- keep scripts' hallucinations when a player opts out (unless configured otherwise)
            else
                n = n + 1
                removeTarget(s, src, reason or 'stopped', true)
                if nextTargetCount(s) == 0 then
                    Sessions[sid] = nil
                    Hall.EndHooks(s, reason or 'stopped')
                end
            end
        end
    end
    return n
end

function Hall.StopAllSessions(reason)
    local ids = {}
    for sid in pairs(Sessions) do ids[#ids + 1] = sid end
    for _, sid in ipairs(ids) do Hall.Stop(sid, reason or 'stopped') end
    return #ids
end

-- ----------------------------------------------------------------------
-- Queries
-- ----------------------------------------------------------------------
function Hall.GetActive(src)
    local list = {}
    local t = now()
    for sid in pairs(ByTarget[src] or {}) do
        local s = Sessions[sid]
        if s then
            list[#list + 1] = { sid = sid, type = s.type, intensity = s.intensity,
                remaining = math.max(0, math.floor((s.endsAt - t) / 1000)), scenario = s.scenario, controlled = s.controller ~= nil }
        end
    end
    table.sort(list, function(a, b) return a.sid < b.sid end)
    return list
end

function Hall.IsDead(src) return isDead(src) end

--- Live control: change the intensity of one session (clients update in place).
function Hall.SetIntensity(sid, value)
    local s = Sessions[sid]
    if not s then return false end
    s.intensity = Utils.Clamp(Utils.Num(value, s.intensity, 0, 1), Config.Safety.MinIntensity, 1.0)
    for src in pairs(s.targets) do
        if s.sent then TriggerClientEvent('universal_halluc:client:update', src, s.sid, s.intensity) end
    end
    return true, s.intensity
end

--- Changes the intensity of every session a player is a target of. Returns how many were changed.
function Hall.SetIntensityFor(src, value)
    local n = 0
    for sid in pairs(ByTarget[src] or {}) do
        if Hall.SetIntensity(sid, value) then n = n + 1 end
    end
    return n
end

function Hall.IsHallucinating(src)
    return next(ByTarget[src] or {}) ~= nil
end

function Hall.FindByController(src)
    local best
    for _, s in pairs(Sessions) do
        if s.controller == src and (not best or s.sid > best.sid) then best = s end
    end
    return best
end

function Hall.FindForTarget(src)
    local best
    for sid in pairs(ByTarget[src] or {}) do
        local s = Sessions[sid]
        if s and (s.controller or s.type == 'friend') and (not best or s.sid > best.sid) then best = s end
    end
    return best
end

-- ----------------------------------------------------------------------
-- Player lifecycle
-- ----------------------------------------------------------------------
function Hall.OnReady(src, optout)
    Hall.Online[src] = { optout = optout == true and Config.Safety.AllowOptOut == true }

    -- (re)send what already runs for this player (client restarted) ...
    for sid in pairs(ByTarget[src] or {}) do
        local s = Sessions[sid]
        if s and s.sent then send(s, src) end
    end
    -- ... and the "everybody except the viewers" sessions (solo_visible) for late joiners
    for _, s in pairs(Sessions) do
        if s.scope == 'all_except' and s.sent and not s.targets[src] and not (s.viewers and s.viewers[src]) and s.subject ~= src then
            addTarget(s, src)
            send(s, src)
        end
    end
end

function Hall.OnDrop(src)
    local ids = {}
    for sid, s in pairs(Sessions) do
        if s.targets[src] or s.controller == src or s.subject == src then ids[#ids + 1] = sid end
    end
    for _, sid in ipairs(ids) do
        local s = Sessions[sid]
        if s then
            if s.subject == src then
                Hall.Stop(sid, 'subject_left')
            elseif s.controller == src and Config.Director.MustStayOnline then
                Hall.Stop(sid, 'controller_left')
            else
                if s.controller == src then s.controller = nil end
                if s.targets[src] then
                    removeTarget(s, src, 'left', false)
                    if nextTargetCount(s) == 0 then
                        Sessions[sid] = nil
                        Hall.EndHooks(s, 'left')
                    end
                end
            end
        end
    end
    ByTarget[src] = nil
    Hall.Online[src] = nil
end

--- The client says one of its effects finished by itself.
function Hall.OnClientEnded(src, sid)
    local s = Sessions[sid]
    if not s or not s.targets[src] then return false end
    removeTarget(s, src, 'client_ended', false)
    if nextTargetCount(s) == 0 then
        Sessions[sid] = nil
        Hall.EndHooks(s, 'client_ended')
    end
    return true
end

function Hall.SetOptOut(src, state)
    local o = Hall.Online[src]
    if not o then return false end
    if not Config.Safety.AllowOptOut then return false end
    o.optout = state == true
    if o.optout then Hall.StopFor(src, 'optout', true) end
    return true
end

-- ----------------------------------------------------------------------
-- Tick: timers (start of delayed sessions, end of sessions) and death
-- ----------------------------------------------------------------------
function Hall.Tick()
    local t = now()
    local due, late = {}, {}
    for sid, s in pairs(Sessions) do
        if not s.sent and t >= s.startsAt then late[#late + 1] = sid end
        if t >= s.endsAt then due[#due + 1] = sid end
    end
    for _, sid in ipairs(late) do
        local s = Sessions[sid]
        if s and not s.sent then
            s.sent = true
            for src in pairs(s.targets) do send(s, src) end
        end
    end
    for _, sid in ipairs(due) do Hall.Stop(sid, 'timeout') end

    if Config.Safety.StopOnDeath then
        local dead = {}
        for src in pairs(ByTarget) do
            if isDead(src) then dead[#dead + 1] = src end
        end
        for _, src in ipairs(dead) do Hall.StopFor(src, 'death') end
    end

    -- controller too far from the target
    local maxD = tonumber(Config.Director.MaxDistance) or 0
    if maxD > 0 then
        for sid, s in pairs(Sessions) do
            if s.controller then
                local cp = GetPlayerPed(s.controller)
                for src in pairs(s.targets) do
                    local tp = GetPlayerPed(src)
                    if cp ~= 0 and tp ~= 0 then
                        local a, b = GetEntityCoords(cp), GetEntityCoords(tp)
                        if Utils.Dist3(a.x, a.y, a.z, b.x, b.y, b.z) > maxD then
                            TriggerClientEvent('universal_halluc:client:notify', s.controller, 'director_limit', 'warning')
                            Hall.Stop(sid, 'distance')
                            break
                        end
                    end
                end
            end
        end
    end
end

function Hall.Count()
    local n = 0
    for _ in pairs(Sessions) do n = n + 1 end
    return n
end
