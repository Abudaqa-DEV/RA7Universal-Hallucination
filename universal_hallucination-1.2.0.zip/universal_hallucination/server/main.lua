--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/main.lua - bootstrap, net events, commands, panel, exports (SERVER).
]]

local RESOURCE = GetCurrentResourceName()
local booted = false

-- ----------------------------------------------------------------------
-- Helpers
-- ----------------------------------------------------------------------
local function say(src, text)
    if src == 0 then
        print(('[universal_hallucination] %s'):format(text))
    else
        TriggerClientEvent('chat:addMessage', src, { args = { Config.Brand.ScriptName, text } })
    end
end

local function tellKey(src, key, ntype, ...)
    if src == 0 then
        print(('[universal_hallucination] %s'):format(Locale(key, ...)))
    else
        TriggerClientEvent('universal_halluc:client:notify', src, key, ntype or 'inform', nil, ...)
    end
end

--- Explains a failure code from Hall/Director/Swap to the person who asked.
local function explain(src, reason, extra)
    say(src, Locale(reason or 'invalid', extra))
end

local function targetArg(src, arg)
    if arg == nil or arg == 'me' then return src > 0 and src or nil end
    if arg == 'all' then return Security.Can(src, 'Admin') and 'all' or nil end
    return tonumber(arg)
end

local function isAdmin(src) return Security.Can(src, 'Admin') end

-- ----------------------------------------------------------------------
-- Boot
-- ----------------------------------------------------------------------
local function banner()
    if not Config.General.PrintBanner then return end
    print('^5========================================================^7')
    print(('^5  %s ^7v%s ^5| Ra7 DEV^7 (Dev by: %s)'):format(Config.Brand.ScriptName, Config.General.Version, Config.General.Developer))
    print(('  Server: ^2%s^7'):format(tostring(Config.Brand.ServerName)))
    print(('  Framework: ^2%s^7 | Language: ^2%s^7 | Types: ^2%d^7 | Scenarios: ^2%d^7'):format(
        Framework.name, Config.General.Language, Registry.Count(), #Scenarios.List()))
    print(('  Appearance/Items: configured from config.lua | Discord: %s'):format(Config.General.Discord))
    print('^5========================================================^7')
end

CreateThread(function()
    Utils.SanitizeConfig()
    if RESOURCE ~= Config.General.ResourceName then
        Utils.Warn(('The folder name is "%s" (expected "%s"). The script still works, but exports must use the real folder name.'):format(RESOURCE, Config.General.ResourceName))
    end
    Framework.Init()
    Swap.Load()
    Store.Load()
    Swap.RegisterEvents()
    booted = true
    banner()

    while true do
        Wait(500)
        local ok, err = pcall(function() Hall.Tick() Swap.Tick() Possess.Tick() end)
        if not ok then Utils.Error('tick: ' .. tostring(err)) end
    end
end)

-- ----------------------------------------------------------------------
-- Net events (clients may only report / answer: everything is validated)
-- ----------------------------------------------------------------------
RegisterNetEvent('universal_halluc:server:ready', function(optout)
    local src = source
    if not Security.Allow(src, 'ready') then return end
    Hall.OnReady(src, optout == true)
    Store.Broadcast(src)
    Mind.OnReady(src)
    Swap.OnReady(src)
end)

RegisterNetEvent('universal_halluc:server:ended', function(sid)
    local src = source
    if not Security.Allow(src, 'ended') then return end
    if type(sid) ~= 'number' then Security.Strike(src, 'ended: bad sid') return end
    Hall.OnClientEnded(src, sid)
end)

RegisterNetEvent('universal_halluc:server:reply', function(sid, text)
    local src = source
    if not Security.Allow(src, 'reply') then return end
    if type(sid) ~= 'number' or type(text) ~= 'string' then Security.Strike(src, 'reply: bad payload') return end
    Director.OnReply(src, sid, text)
end)

RegisterNetEvent('universal_halluc:server:choice', function(sid, dialogueId, nodeId, index)
    local src = source
    if not Security.Allow(src, 'reply') then return end
    if type(sid) ~= 'number' or not Security.IsString(dialogueId, 64) or not Security.IsString(nodeId, 64) or type(index) ~= 'number' then
        Security.Strike(src, 'choice: bad payload')
        return
    end
    Director.OnChoice(src, sid, dialogueId, nodeId, math.floor(index))
end)

RegisterNetEvent('universal_halluc:server:optout', function(state)
    local src = source
    if not Security.Allow(src, 'optout') then return end
    Hall.SetOptOut(src, state == true)
end)

RegisterNetEvent('universal_halluc:server:appearanceData', function(id, ok, data, model)
    local src = source
    if not Security.Allow(src, 'appear') then return end
    if type(id) ~= 'number' then return end
    if data ~= nil then
        local good, enc = pcall(json.encode, data)
        if type(data) ~= 'table' or not good or #enc > 150000 then Security.Strike(src, 'appearanceData: bad data') return end
    end
    AppearanceServer.OnResponse(src, id, ok == true, data, model)
end)

AddEventHandler('playerDropped', function()
    local src = source
    World.OnDrop(src)
    Zones.OnDrop(src)
    Mind.OnDrop(src)
    Takeover.Stop(src, 'left')
    Possess.Stop(src, 'left')
    Voice.Release(src)
    Scenarios.OnDrop(src)
    Swap.OnDrop(src)
    Hall.OnDrop(src)
    Security.Cleanup(src)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= RESOURCE then return end
    Scenarios.StopAll('resource_stop')
    Hall.StopAllSessions('resource_stop')
end)

-- ----------------------------------------------------------------------
-- Commands
-- ----------------------------------------------------------------------
local function cmd(name, perm, fn)
    if type(name) ~= 'string' or name == '' then return end
    RegisterCommand(name, function(src, args)
        if src ~= 0 and not Security.Allow(src, 'command') then return end
        if perm and not Security.Can(src, perm) then return say(src, Locale('no_permission')) end
        fn(src, args)
    end, false)
end

local C = Config.Commands

cmd(C.Start, 'Use', function(src, a)
    local target, typeKey = targetArg(src, a[1]), a[2]
    if not target or not typeKey then return say(src, Locale('usage_start', C.Start)) end
    local sid, why, extra = Hall.Start(target, typeKey, {
        duration = tonumber(a[3]), intensity = tonumber(a[4]), source = 'command', by = src, force = isAdmin(src),
    })
    if not sid then return explain(src, why, extra) end
    say(src, Locale('started', typeKey, tostring(GetPlayerName(target) or target), sid))
end)

cmd(C.Scenario, 'Use', function(src, a)
    local target, name = targetArg(src, a[1]), a[2]
    if not target or target == 'all' or not name then return say(src, Locale('usage_scenario', C.Scenario)) end
    local id, why, extra = Scenarios.Run(target, name, { seconds = tonumber(a[3]), source = 'command', by = src, force = isAdmin(src) })
    if not id then return explain(src, why, extra) end
    say(src, Locale('scenario_started', name, tostring(GetPlayerName(target) or target)))
end)

cmd(C.Stop, 'Use', function(src, a)
    local arg = a[1]
    local n = 0
    if arg == 'all' then
        if not isAdmin(src) then return say(src, Locale('no_permission')) end
        Scenarios.StopAll('stopped')
        n = Hall.StopAllSessions('stopped')
    else
        local target = targetArg(src, arg)
        if not target then return say(src, Locale('player_not_found')) end
        Scenarios.StopFor(target, 'stopped')
        n = Hall.StopFor(target, 'stopped')
    end
    say(src, n > 0 and Locale('stopped', n) or Locale('nothing_to_stop'))
end)

cmd(C.List, 'Use', function(src)
    say(src, Locale('list_types'))
    local line = {}
    for _, key in ipairs(Registry.Order) do
        line[#line + 1] = ('%s%s'):format(key, Registry.IsEnabled(key) and '' or ' (off)')
        if #line == 8 then say(src, table.concat(line, ', ')) line = {} end
    end
    if #line > 0 then say(src, table.concat(line, ', ')) end
    say(src, Locale('list_scenarios'))
    local sc = {}
    for _, s in ipairs(Scenarios.List()) do sc[#sc + 1] = ('%s (%s)'):format(s.key, s.label) end
    say(src, table.concat(sc, ', '))
end)

cmd(C.Hide, 'Use', function(src, a)
    local viewer, subject = (a[1] == 'all') and 'all' or tonumber(a[1]), tonumber(a[2])
    if not viewer or not subject then return say(src, Locale('usage_hide', C.Hide)) end
    local sid, why, extra = Hall.Start(viewer, 'hide_player', { subject = subject, duration = tonumber(a[3]), source = 'command', by = src, force = isAdmin(src) })
    if not sid then return explain(src, why, extra) end
    say(src, Locale('started', 'hide_player', tostring(a[1]), sid))
end)

cmd(C.Solo, 'Use', function(src, a)
    local subject, viewer = tonumber(a[1]), tonumber(a[2])
    if not subject or not viewer then return say(src, Locale('usage_solo', C.Solo)) end
    local sid, why, extra = Hall.Start(viewer, 'solo_visible', { subject = subject, duration = tonumber(a[3]), source = 'command', by = src, force = isAdmin(src) })
    if not sid then return explain(src, why, extra) end
    say(src, Locale('started', 'solo_visible', tostring(subject), sid))
end)

cmd(C.Ghost, 'Use', function(src, a)
    local target = targetArg(src, a[1])
    if not target then return say(src, Locale('usage_ghost', C.Ghost)) end
    local sid, why, extra = Hall.Start(target, 'ghost_vision', {
        duration = tonumber(a[3]), params = { alpha = tonumber(a[2]) }, source = 'command', by = src, force = isAdmin(src),
    })
    if not sid then return explain(src, why, extra) end
    say(src, Locale('started', 'ghost_vision', tostring(GetPlayerName(target) or target), sid))
end)

cmd(C.Direct, 'Director', function(src, a)
    local target = tonumber(a[1])
    if src == 0 then return say(src, Locale('usage_direct', C.Direct)) end
    if not target then return say(src, Locale('usage_direct', C.Direct)) end
    local sid, why, extra = Director.Start(src, target, a[2], a[3])
    if not sid then return explain(src, why, extra) end
    say(src, Locale('director_started', tostring(GetPlayerName(target) or target)))
end)

cmd(C.Say, 'Director', function(src, a)
    local ok, why = Director.Say(src, table.concat(a, ' '))
    if not ok then return say(src, Locale(why == 'invalid' and 'usage_say' or why, C.Say)) end
    say(src, Locale('say_sent', why))
end)

-- /hr is for the TARGET of a hallucination: anybody may answer an imaginary person talking to him
cmd(C.Reply, nil, function(src, a)
    local text = table.concat(a, ' ')
    local s = Hall.FindForTarget(src)
    if not s then return say(src, Locale('reply_none')) end
    local ok, clean = Director.OnReply(src, s.sid, text)
    if not ok then return say(src, Locale('usage_reply', C.Reply)) end
    say(src, Locale('reply_sent', clean))
end)

cmd(C.Swap, 'Swap', function(src, a)
    local x, y = tonumber(a[1]), tonumber(a[2])
    if not x or not y then return say(src, Locale('usage_swap', C.Swap)) end
    Swap.Looks(src, x, y, tonumber(a[3]), function(ok, why, items)
        if not ok then return explain(src, why) end
        say(src, Locale('swap_done', tostring(GetPlayerName(x) or x), tostring(GetPlayerName(y) or y)) .. (items and Locale('swap_items_done') or ''))
    end)
end)

cmd(C.Restore, 'Swap', function(src, a)
    local id = tonumber(a[1]) or src
    if Swap.Restore(id, 'command') then say(src, Locale('swap_restored')) else say(src, Locale('nothing_to_stop')) end
end)

cmd(C.Appear, 'Director', function(src, a)
    local target = tonumber(a[1])
    if src == 0 or not target then return say(src, Locale('usage_appear', C.Appear)) end
    local sid, why, extra = Possess.Appear(src, target, tonumber(a[2]))
    if not sid then return explain(src, why, extra) end
    say(src, Locale('appear_started', tostring(GetPlayerName(target) or target)))
end)

cmd(C.Possess, 'Director', function(src, a)
    local target = tonumber(a[1])
    if src == 0 or not target then return say(src, Locale('usage_possess', C.Possess)) end
    Possess.Start(src, target, tonumber(a[2]), function(sid, why, extra)
        if not sid then return explain(src, why, extra) end
        say(src, Locale('possess_started', tostring(GetPlayerName(target) or target)))
    end)
end)

cmd(C.Unpossess, 'Director', function(src, a)
    local id = tonumber(a[1]) or src
    if Possess.Stop(id, 'stopped') then say(src, Locale('possess_ended')) else say(src, Locale('nothing_to_stop')) end
end)

cmd(C.Cue, 'Use', function(src, a)
    local target, key = targetArg(src, a[1]), a[2]
    if not target or not key then return say(src, Locale('usage_cue', C.Cue)) end
    local n, why, extra = Cues.Fire(target, key, { by = src, force = isAdmin(src), source = 'command' })
    if not n then return explain(src, why, extra) end
    say(src, Locale('cue_fired', key, n))
end)

cmd(C.Adjust, 'Use', function(src, a)
    local target, v = targetArg(src, a[1]), tonumber(a[2])
    if not target or target == 'all' or not v then return say(src, Locale('usage_adjust', C.Adjust)) end
    local n = Hall.SetIntensityFor(target, Utils.Clamp(v, 0, 1))
    say(src, n > 0 and Locale('adjusted', n) or Locale('nothing_to_stop'))
end)

cmd(C.Scene, 'Use', function(src, a)
    local target, name = targetArg(src, a[1]), a[2]
    if not target or type(name) ~= 'string' or not Config.Scenes[name] then return say(src, Locale('usage_scene', C.Scene)) end
    if not Registry.SwitchOn('Scenes', name) then return say(src, Locale('scene_disabled')) end
    local sid, why, extra = Hall.Start(target, 'scene', {
        duration = tonumber(a[3]) or Config.Scenes[name].Duration, params = { scene = name },
        source = 'command', by = src, force = isAdmin(src),
    })
    if not sid then return explain(src, why, extra) end
    say(src, Locale('started', 'scene:' .. name, tostring(GetPlayerName(target) or target), sid))
end)

cmd(C.Take, 'Director', function(src, a)
    local target = tonumber(a[1])
    if src == 0 or not target then return say(src, Locale('usage_take', C.Take)) end
    local opts = { pressure = a[2], ghostMove = (a[3] == 'move') or nil }      -- /htake <id> [easy|normal|hard|nightmare] [move]
    if opts.pressure and not Config.Resist.Levels[opts.pressure] then opts.pressure = nil end
    local ok, why, extra = Takeover.Talk(src, target, opts)
    if not ok then return explain(src, why, extra) end
    say(src, Locale('takeover_talk', tostring(GetPlayerName(target) or target), C.Seize))
end)

cmd(C.Seize, 'Director', function(src)
    local ok, why, extra = Takeover.Seize(src)
    if not ok then return explain(src, why, extra) end
    say(src, Locale('takeover_dueling'))
end)

cmd(C.Back, 'Director', function(src, a)
    local id = tonumber(a[1]) or src
    if Takeover.Back(id) then say(src, Locale('takeover_back_done')) else say(src, Locale('takeover_none')) end
end)

cmd(C.Release, 'Director', function(src, a)
    local id = tonumber(a[1]) or src
    if Takeover.Stop(id, 'released') then say(src, Locale('takeover_ended')) else say(src, Locale('takeover_none')) end
end)

cmd(C.Voice, 'Director', function(src, a)
    local target = targetArg(src, a[1])
    if src == 0 or not target then return say(src, Locale('usage_voice', C.Voice)) end
    if not Voice.Enabled() then return say(src, Locale('voice_disabled')) end
    if Voice.IsLinked('m' .. src) then
        Voice.Unlink('m' .. src)
        return say(src, Locale('voice_off'))
    end
    if Voice.Toggle(src, target) then
        say(src, Locale('voice_on', tostring(GetPlayerName(target) or target)))
    else
        say(src, Locale('voice_failed'))
    end
end)

cmd(C.OptOut, nil, function(src)
    if src == 0 then return end
    if not Config.Safety.AllowOptOut then return say(src, Locale('optout_disabled')) end
    local o = Hall.Online[src]
    local state = not (o and o.optout)
    Hall.SetOptOut(src, state)
    TriggerClientEvent('universal_halluc:client:optout', src, state)
    say(src, Locale(state and 'optout_on' or 'optout_off'))
end)

cmd(C.Carry, 'Admin', function(src, a)
    local id = tonumber(a[1]) or src
    local ok, n = Swap.Deliver(id)
    if not ok then return explain(src, n) end
    say(src, Locale('carry_done', n))
end)

-- ----------------------------------------------------------------------
-- Panel (NUI): data + actions. Every action re-checks the permission here.
-- ----------------------------------------------------------------------
local function panelTypes()
    local list = {}
    for _, key in ipairs(Registry.Order) do
        local meta, cfg = Registry.Types[key], Config.Types[key] or {}
        if not meta.hidden then list[#list + 1] = {
            key = key, cat = meta.cat, label = Locale('type_' .. key), short = Locale('tn_' .. key), enabled = Registry.IsEnabled(key),
            duration = cfg.Duration, intensity = cfg.Intensity,
            needsSubject = meta.needsSubject or false, subjectOpt = meta.subjectOpt or false,
            controllable = meta.controllable or false,
            models = (type(cfg.Models) == 'table') and cfg.Models or nil,
        } end
    end
    return list
end

local function panelData(src, full)
    local players = {}
    local mapOn = Config.Map and Config.Map.Enabled ~= false
    for _, id in ipairs(Hall.OnlineList()) do
        local pl = { id = id, name = GetPlayerName(id) or ('#' .. id), active = #Hall.GetActive(id), swapped = Swap.IsSwapped(id), stress = math.floor(Mind.Get(id) + 0.5) }
        if mapOn then
            local ped = GetPlayerPed(id)
            if ped and ped ~= 0 then local c = GetEntityCoords(ped) pl.x, pl.y, pl.hd = math.floor(c.x * 10) / 10, math.floor(c.y * 10) / 10, math.floor(GetEntityHeading(ped)) end
        end
        players[#players + 1] = pl
    end
    local active = {}
    for _, p in ipairs(players) do
        for _, a in ipairs(Hall.GetActive(p.id)) do
            a.target, a.targetName = p.id, p.name
            a.label = Locale('type_' .. a.type)
            active[#active + 1] = a
        end
    end
    local scenarios = {}
    for _, s in ipairs(Scenarios.List()) do scenarios[#scenarios + 1] = { key = s.key, label = s.label, duration = s.duration } end
    local scenes = {}
    for k, sc in pairs(Config.Scenes) do if Registry.SwitchOn('Scenes', k) then scenes[#scenes + 1] = { key = k, label = Utils.Text(sc.Label) ~= '' and Utils.Text(sc.Label) or k, mode = sc.Mode, duration = sc.Duration } end end
    table.sort(scenes, function(a, b) return a.key < b.key end)
    local dialogues = {}
    for k, d in pairs(Config.Dialogues) do dialogues[#dialogues + 1] = { key = k, label = Utils.Text(d.Speaker) } end
    table.sort(dialogues, function(a, b) return a.key < b.key end)
    local dir = Hall.FindByController(src)

    return {
        me = src, players = players, types = panelTypes(), scenarios = scenarios, scenes = scenes, active = active, dialogues = dialogues,
        perms = { use = Security.Can(src, 'Use'), director = Security.Can(src, 'Director'), swap = Security.Can(src, 'Swap'), admin = Security.Can(src, 'Admin') },
        directing = dir and { sid = dir.sid, type = dir.type, targets = (function() local t = {} for k in pairs(dir.targets) do t[#t + 1] = k end return t end)() } or nil,
        cues = Config.Cues.Enabled and Cues.List() or {},
        resist = { enabled = Config.Resist.Enabled, key = Config.Resist.KeyLabel },
        possess = Config.Possess.Enabled,
        mapOn = mapOn,
        settings = Security.Can(src, 'Admin') and Settings.Panel(Store.settings) or nil,
        health = Security.Can(src, 'Admin') and Health.Panel() or nil,
        places = Store.Places(), zones = Store.zones, mindCfg = { enabled = Config.Mind.Enabled, max = Config.Mind.Max, levels = Config.Mind.Levels }, zoneCfg = { enabled = Config.Zones.Enabled, defaults = Config.Zones.Defaults, max = Config.Zones.MaxZones }, zoneTypes = (function() local t = {} for _, k in ipairs(Registry.Order or {}) do local m2 = Registry.Types[k] if m2 and not m2.hidden and not m2.needsSubject and Registry.IsEnabled(k) then t[#t + 1] = k end end return t end)(), worlds = World.List(), worldCfg = { enabled = Config.World.Enabled, bucket = Config.World.UseBucket ~= false, fade = Config.World.Fade ~= false, max = Config.World.MaxSeconds, maxStaff = Config.World.MaxStaff },
        takeover = Config.Takeover.Enabled and Takeover.Status(src) or nil, takeoverEnabled = Config.Takeover.Enabled,
        takeoverCfg = { pressure = (Config.Takeover.Contest or {}).Pressure or Config.Resist.Level, ghostMove = (Config.Takeover.Ghost or {}).Freeze == false,
                        levels = { 'easy', 'normal', 'hard', 'nightmare' } },
        sceneDefs = (function() local t = {} for k, v in pairs(Config.Scenes) do if full or v.User then t[k] = v end end return t end)(),
        userScenes = (function() local t = {} for k, v in pairs(Config.Scenes) do if v.User then t[#t + 1] = k end end table.sort(t) return t end)(),
        swapEnabled = Config.Swap.Enabled and Config.Swap.Looks.Enabled,
        itemsSwap = Config.Swap.Items.Enabled,
    }
end

RegisterNetEvent('universal_halluc:server:panelOpen', function()
    local src = source
    if not Config.Panel.Enabled then return end
    if not Security.Allow(src, 'panel') then return end
    if not (Security.Can(src, 'Use') or Security.Can(src, 'Director') or Security.Can(src, 'Swap')) then
        tellKey(src, 'panel_denied', 'error')
        return
    end
    TriggerClientEvent('universal_halluc:client:panelData', src, panelData(src, true), true)
end)

RegisterNetEvent('universal_halluc:server:panelRefresh', function()
    local src = source
    if not Config.Panel.Enabled or not Security.Allow(src, 'panel') then return end
    if not (Security.Can(src, 'Use') or Security.Can(src, 'Director') or Security.Can(src, 'Swap')) then return end
    TriggerClientEvent('universal_halluc:client:panelData', src, panelData(src), false)
end)

local function result(src, action, ok, key, extra)
    TriggerClientEvent('universal_halluc:client:panelResult', src, action, ok == true, key and Locale(key, extra) or '')
end

local function num(v, lo, hi) return Utils.Num(v, nil, lo, hi) end

RegisterNetEvent('universal_halluc:server:panel', function(action, p)
    local src = source
    if not Config.Panel.Enabled or not Security.Allow(src, 'panel') then return end
    if type(action) ~= 'string' or type(p) ~= 'table' then Security.Strike(src, 'panel: bad payload') return end

    local function deny() result(src, action, false, 'no_permission') end
    local function fail(why, extra) result(src, action, false, why or 'invalid', extra) end

    if action == 'start' then
        if not Security.Can(src, 'Use') then return deny() end
        local target = (p.target == 'all') and (isAdmin(src) and 'all' or nil) or tonumber(p.target)
        if not target or type(p.type) ~= 'string' then return fail('invalid') end
        local params = {}
        if type(p.params) == 'table' then
            params.model, params.source, params.alpha, params.dialogue = p.params.model, p.params.source, p.params.alpha, p.params.dialogue
            params.scene, params.mode = p.params.scene, p.params.mode
        end
        local sid, why, extra = Hall.Start(target, p.type, {
            duration = num(p.duration, 1, Config.Safety.MaxDuration), intensity = num(p.intensity, 0, 1),
            subject = tonumber(p.subject), params = params, source = 'command', by = src, force = isAdmin(src),
        })
        if not sid then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('started', p.type, tostring(GetPlayerName(tonumber(target) or 0) or target), sid))

    elseif action == 'scenario' then
        if not Security.Can(src, 'Use') then return deny() end
        local target = tonumber(p.target)
        if not target or type(p.name) ~= 'string' then return fail('invalid') end
        local id, why, extra = Scenarios.Run(target, p.name, { seconds = num(p.duration, 1, Config.Safety.MaxDuration), source = 'command', by = src, force = isAdmin(src) })
        if not id then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('scenario_started', p.name, tostring(GetPlayerName(target) or target)))

    elseif action == 'stop' then
        if not Security.Can(src, 'Use') then return deny() end
        local n = 0
        if p.sid then
            if Hall.Stop(tonumber(p.sid) or -1, 'stopped') then n = 1 end
        elseif p.target == 'all' then
            if not isAdmin(src) then return deny() end
            Scenarios.StopAll('stopped')
            n = Hall.StopAllSessions('stopped')
        else
            local t = tonumber(p.target)
            if not t then return fail('invalid') end
            Scenarios.StopFor(t, 'stopped')
            n = Hall.StopFor(t, 'stopped')
        end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, n > 0 and Locale('stopped', n) or Locale('nothing_to_stop'))

    elseif action == 'direct' then
        if not Security.Can(src, 'Director') then return deny() end
        local target = tonumber(p.target)
        if not target then return fail('invalid') end
        local spec = p.spec
        if type(spec) ~= 'string' then spec = nil end
        local sid, why, extra = Director.Start(src, target, type(p.type) == 'string' and p.type or 'friend', spec)
        if not sid then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('director_started', tostring(GetPlayerName(target) or target)))

    elseif action == 'say' then
        if not Security.Can(src, 'Director') then return deny() end
        local ok, why = Director.Say(src, type(p.text) == 'string' and p.text or '')
        if not ok then return fail(why == 'invalid' and 'invalid' or why) end
        return TriggerClientEvent('universal_halluc:client:panelLog', src, 'say', src, why)

    elseif action == 'swap' then
        if not Security.Can(src, 'Swap') then return deny() end
        Swap.Looks(src, p.a, p.b, num(p.duration, 10, Config.Swap.Looks.MaxSeconds), function(ok, why, items)
            if not ok then return fail(why) end
            TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('swap_done', tostring(GetPlayerName(tonumber(p.a) or 0) or p.a), tostring(GetPlayerName(tonumber(p.b) or 0) or p.b)))
        end)
        return

    elseif action == 'restore' then
        if not Security.Can(src, 'Swap') then return deny() end
        local id = tonumber(p.id)
        if id and Swap.Restore(id, 'panel') then
            return result(src, action, true, 'swap_restored')
        end
        return fail('nothing_to_stop')

    elseif action == 'cue' then
        if not Security.Can(src, 'Use') then return deny() end
        local t = (p.target == 'all') and (isAdmin(src) and 'all' or nil) or tonumber(p.target)
        if not t or type(p.cue) ~= 'string' then return fail('invalid') end
        local n, why, extra = Cues.Fire(t, p.cue, { by = src, force = isAdmin(src), source = 'command' })
        if not n then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('cue_fired', p.cue, n))

    elseif action == 'adjust' then
        if not Security.Can(src, 'Use') then return deny() end
        local t, v = tonumber(p.target), tonumber(p.value)
        if not t or not v then return fail('invalid') end
        local n
        if p.sid then n = Hall.SetIntensity(tonumber(p.sid) or -1, Utils.Clamp(v, 0, 1)) and 1 or 0
        else n = Hall.SetIntensityFor(t, Utils.Clamp(v, 0, 1)) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, n > 0, n > 0 and Locale('adjusted', n) or Locale('nothing_to_stop'))

    elseif action == 'appear' then
        if not Security.Can(src, 'Director') then return deny() end
        local sid, why, extra = Possess.Appear(src, tonumber(p.target), num(p.duration, 5, Config.Safety.MaxDuration))
        if not sid then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('appear_started', tostring(GetPlayerName(tonumber(p.target)) or p.target)))

    elseif action == 'possess' then
        if not Security.Can(src, 'Director') then return deny() end
        Possess.Start(src, tonumber(p.target), num(p.duration, 10, Config.Possess.MaxSeconds), function(sid, why, extra)
            if not sid then return fail(why, extra) end
            TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('possess_started', tostring(GetPlayerName(tonumber(p.target)) or p.target)))
        end)
        return

    elseif action == 'unpossess' then
        if not Security.Can(src, 'Director') then return deny() end
        if Possess.Stop(src, 'stopped') then return result(src, action, true, 'possess_ended') end
        return fail('nothing_to_stop')

    elseif action == 'hide' or action == 'solo' or action == 'ghost' then
        if not Security.Can(src, 'Use') then return deny() end
        local sid, why, extra
        if action == 'hide' then
            sid, why, extra = Hall.Start((p.viewer == 'all') and (isAdmin(src) and 'all' or nil) or tonumber(p.viewer), 'hide_player',
                { subject = tonumber(p.subject), duration = num(p.duration, 1, Config.Safety.MaxDuration), source = 'command', by = src, force = isAdmin(src) })
        elseif action == 'solo' then
            sid, why, extra = Hall.Start(tonumber(p.viewer), 'solo_visible',
                { subject = tonumber(p.subject), duration = num(p.duration, 1, Config.Safety.MaxDuration), source = 'command', by = src, force = isAdmin(src) })
        else
            sid, why, extra = Hall.Start(tonumber(p.target), 'ghost_vision',
                { duration = num(p.duration, 1, Config.Safety.MaxDuration), params = { alpha = tonumber(p.alpha) }, source = 'command', by = src, force = isAdmin(src) })
        end
        if not sid then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('started', action, '-', sid))

    -- ------------------------------------------------------------ takeover (from the panel)
    elseif action == 'takeover_talk' or action == 'takeover_seize' or action == 'takeover_release' or action == 'takeover_back' then
        if not Security.Can(src, 'Director') then return deny() end
        if action == 'takeover_back' then
            if Takeover.Back(src) then return result(src, action, true, 'takeover_back_done') end
            return fail('takeover_none')
        end
        local opts = {}
        if type(p.pressure) == 'string' and Config.Resist.Levels[p.pressure] then opts.pressure = p.pressure end
        if p.ghostMove ~= nil then opts.ghostMove = p.ghostMove == true end
        if action == 'takeover_release' then
            if Takeover.Stop(src, 'released') or World.Return(src, 'released') then
                return result(src, action, true, 'takeover_ended')
            end
            return fail('takeover_none')
        end
        local ok, why, extra
        if action == 'takeover_talk' then ok, why, extra = Takeover.Talk(src, tonumber(p.target), opts)
        else ok, why, extra = Takeover.Seize(src, opts) end
        if not ok then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale(action == 'takeover_talk' and 'takeover_talk_ok' or 'takeover_dueling'))

    -- ------------------------------------------------------------ parallel world + places
    elseif action == 'world_send' then
        if not Security.Can(src, 'Director') then return deny() end
        local staff = {}
        for i, id in ipairs(type(p.staff) == 'table' and p.staff or {}) do if i <= 40 then staff[#staff + 1] = tonumber(id) end end
        local ok, why, extra = World.Send(src, tonumber(p.target), type(p.place) == 'string' and p.place or '', {
            staff = staff, seconds = num(p.seconds, 10, Config.World.MaxSeconds), bucket = (p.bucket == nil) and nil or (p.bucket == true), join = p.join ~= false })
        if not ok then return fail(why, extra) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('world_sent', tostring(GetPlayerName(tonumber(p.target)) or p.target)))

    elseif action == 'world_return' then
        if not Security.Can(src, 'Director') then return deny() end
        if World.Return(tonumber(p.target) or src, 'returned') then
            return result(src, action, true, 'world_returned')
        end
        return fail('world_none')

    elseif action == 'world_join' then
        if not Security.Can(src, 'Director') then return deny() end
        local ok, why = World.Join(src, tonumber(p.target), tonumber(p.id))
        if not ok then return fail(why) end
        return result(src, action, true, 'world_joined')

    elseif action == 'place_save' then
        if not Security.Can(src, 'Director') then return deny() end
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return fail('invalid') end
        local c = GetEntityCoords(ped)
        local ok, why = Store.SavePlace(src, p.name, c.x, c.y, c.z, GetEntityHeading(ped))
        if not ok then return fail(why) end
        return result(src, action, true, 'place_saved')

    elseif action == 'place_delete' then
        if not Security.Can(src, 'Director') then return deny() end
        if type(p.key) == 'string' and Store.DeletePlace(p.key) then
            return result(src, action, true, 'place_deleted')
        end
        return fail('invalid')

    -- ------------------------------------------------------------ zones + mind
    elseif action == 'zone_save' then
        if not Security.Can(src, 'Admin') then return deny() end
        local z = type(p.zone) == 'table' and p.zone or {}
        if p.here == true then
            local ped = GetPlayerPed(src)
            if not ped or ped == 0 then return fail('invalid') end
            local c = GetEntityCoords(ped)
            z.x, z.y, z.z = c.x, c.y, c.z
        elseif type(p.at) == 'table' and tonumber(p.at.x) and tonumber(p.at.y) then
            -- picked on the map: no height, the zone ignores it (flat)
            z.x, z.y, z.z, z.flat = p.at.x + 0.0, p.at.y + 0.0, 0.0, true
        end
        if type(z.key) ~= 'string' or z.key == '' then z.key = Store.NewZoneKey(type(z.label) == 'string' and z.label or (type(z.label) == 'table' and z.label.en) or '') end
        local ok, why = Store.SaveZone(z)
        if not ok then return fail(why) end
        return result(src, action, true, 'zone_saved')

    -- ------------------------------------------------------------ reliability (admin only)
    elseif action == 'selftest_start' then
        if not Security.Can(src, 'Admin') then return deny() end
        local ok, why = Health.StartSelftest(src)
        if not ok then return fail(why) end
        return result(src, action, true, 'selftest_started')

    elseif action == 'selftest_stop' then
        if not Security.Can(src, 'Admin') then return deny() end
        Health.StopSelftest()
        return result(src, action, true, 'selftest_stopped')

    elseif action == 'health_reset' then
        if not Security.Can(src, 'Admin') then return deny() end
        Health.Reset()
        return result(src, action, true, 'health_reset_ok')

    -- ------------------------------------------------------------ settings (admin only, whitelist in shared/settings.lua)
    elseif action == 'setting_set' then
        if not Security.Can(src, 'Admin') then return deny() end
        if type(p.key) ~= 'string' then return fail('invalid') end
        local ok, why = Store.SetSetting(p.key, p.value)
        if not ok then return fail(why) end
        return result(src, action, true, 'setting_saved')

    elseif action == 'setting_clear' then
        if not Security.Can(src, 'Admin') then return deny() end
        if type(p.key) ~= 'string' or not Settings.Def(p.key) then return fail('invalid') end
        Store.SetSetting(p.key, nil)
        return result(src, action, true, 'setting_saved')

    elseif action == 'settings_reset' then
        if not Security.Can(src, 'Admin') then return deny() end
        Store.ReplaceSettings({})
        return result(src, action, true, 'settings_reset_ok')

    elseif action == 'settings_import' then
        if not Security.Can(src, 'Admin') then return deny() end
        if type(p.data) ~= 'table' then return fail('invalid') end
        Store.ReplaceSettings(p.data)
        return result(src, action, true, 'settings_import_ok')

    elseif action == 'zone_delete' then
        if not Security.Can(src, 'Admin') then return deny() end
        if type(p.key) == 'string' and Store.DeleteZone(p.key) then
            return result(src, action, true, 'zone_deleted')
        end
        return fail('invalid')

    elseif action == 'mind_add' or action == 'mind_set' then
        if not Security.Can(src, 'Director') then return deny() end
        local t, v = tonumber(p.target), tonumber(p.value)
        if not t or not v or not Hall.IsOnline(t) then return fail('player_not_found') end
        if action == 'mind_add' then Mind.Add(t, v) else Mind.Set(t, v) end
        return TriggerClientEvent('universal_halluc:client:panelResult', src, action, true, Locale('mind_changed', tostring(GetPlayerName(t) or t), math.floor(Mind.Get(t) + 0.5)))

    -- ------------------------------------------------------------ scene editor
    elseif action == 'scene_save' then
        if not Security.Can(src, 'Admin') then return deny() end
        local ok, why = Store.SaveScene(p.key, p.scene)
        if not ok then return fail(why) end
        return result(src, action, true, 'scene_saved')

    elseif action == 'scene_delete' then
        if not Security.Can(src, 'Admin') then return deny() end
        if type(p.key) == 'string' and Store.DeleteScene(p.key) then
            return result(src, action, true, 'scene_deleted')
        end
        return fail('invalid')
    end

    Security.Strike(src, 'panel: unknown action ' .. action:sub(1, 20))
end)

-- the controller also sees replies in the panel console
AddEventHandler('universal_halluc:replied', function(src, sid, text)
    local s = Hall.Sessions[sid]
    if s and s.controller then
        TriggerClientEvent('universal_halluc:client:panelLog', s.controller, 'reply', src, text)
    end
end)

-- ----------------------------------------------------------------------
-- Exports
-- ----------------------------------------------------------------------
exports('Start', function(target, typeKey, opts) return Hall.Start(target, typeKey, opts) end)
exports('Stop', function(sid) return Hall.Stop(tonumber(sid) or -1, 'export') end)
exports('StopAll', function(target)
    target = tonumber(target)
    if not target then return 0 end
    Scenarios.StopFor(target, 'export')
    return Hall.StopFor(target, 'export')
end)
exports('RunScenario', function(target, name, opts) return Scenarios.Run(target, name, opts) end)
exports('StopScenario', function(target) return Scenarios.StopFor(tonumber(target) or -1, 'export') end)
exports('IsHallucinating', function(target) return Hall.IsHallucinating(tonumber(target) or -1) end)
exports('GetActive', function(target) return Hall.GetActive(tonumber(target) or -1) end)
exports('GetTypes', function() return panelTypes() end)
exports('SetTypeEnabled', function(key, value) return Registry.SetEnabled(key, value) end)
exports('IsTypeEnabled', function(key) return Registry.IsEnabled(key) end)
exports('GetScenarios', function() return Scenarios.List() end)
exports('SetOptOut', function(target, state) return Hall.SetOptOut(tonumber(target) or -1, state == true) end)
exports('DirectorStart', function(controller, target, typeKey, spec, opts) return Director.Start(controller, target, typeKey, spec, opts) end)
exports('DirectorSay', function(controller, text) return Director.Say(controller, text) end)
exports('Hide', function(viewer, subject, seconds) return Hall.Start(viewer, 'hide_player', { subject = subject, duration = seconds }) end)
exports('SoloVisible', function(subject, viewer, seconds) return Hall.Start(viewer, 'solo_visible', { subject = subject, duration = seconds }) end)
exports('GhostVision', function(target, alpha, seconds) return Hall.Start(target, 'ghost_vision', { duration = seconds, params = { alpha = alpha } }) end)
exports('SwapLooks', function(a, b, seconds, cb) return Swap.Looks(0, a, b, seconds, cb) end)
exports('RestoreLooks', function(src) return Swap.Restore(tonumber(src) or -1, 'export') end)
exports('StashItems', function(src) return Swap.Stash(tonumber(src) or -1) end)
exports('DeliverItems', function(src) return Swap.Deliver(tonumber(src) or -1) end)

exports('Appear', function(controller, target, seconds) return Possess.Appear(controller, target, seconds) end)
exports('Possess', function(controller, target, seconds, cb) return Possess.Start(controller, target, seconds, cb) end)
exports('VoiceLink', function(controller, target)
    controller, target = tonumber(controller), tonumber(target)
    if not controller or not target then return false end
    return Voice.Link('m' .. controller, controller, { target }) ~= nil
end)
exports('VoiceUnlink', function(controller) return Voice.Unlink('m' .. tostring(tonumber(controller) or '')) end)
exports('TakeoverTalk', function(controller, target, opts) return Takeover.Talk(controller, target, opts) end)       -- opts = { pressure = 'hard', ghostMove = false }
exports('TakeoverSeize', function(controller, opts) return Takeover.Seize(controller, opts) end)
exports('TakeoverBack', function(src) return Takeover.Back(tonumber(src) or -1) end)                              -- both players back where they stood before
exports('TakeoverRelease', function(src) return Takeover.Stop(tonumber(src) or -1, 'export') end)
exports('AddStress', function(src, amount) return Mind.Add(tonumber(src) or -1, amount) end)
exports('ReduceStress', function(src, amount) return Mind.Add(tonumber(src) or -1, -(tonumber(amount) or 0)) end)
exports('SetStress', function(src, value) return Mind.Set(tonumber(src) or -1, value) end)
exports('GetStress', function(src) return Mind.Get(src) end)
exports('Unpossess', function(src) return Possess.Stop(tonumber(src) or -1, 'export') end)
exports('Cue', function(target, cue, opts) return Cues.Fire(target, cue, opts) end)
exports('SetIntensity', function(sid, v) return Hall.SetIntensity(tonumber(sid) or -1, v) end)
exports('SetIntensityFor', function(src, v) return Hall.SetIntensityFor(tonumber(src) or -1, v) end)
