--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/takeover.lua - "take over by swapping" (see Config.Takeover).

    Phase 1  Talk     /htake   the controller appears to ONE player only and talks to him (Possess.Appear + voice link)
    Phase 2  Contest  /hseize  mini-game duel for the target
                       target wins   -> the controller is expelled (he vanishes before taking over)
                       target loses  -> Phase 3
    Phase 3  Swapped  the controller enters the target's character (his look, his place); the target is moved to the
                       controller's old place wearing the controller's look: nobody sees or hears him except the
                       controller, he sees and hears everybody, and he cannot move.
    End      /hrelease, timeout, death or leaving: looks restored, each one returns (controller to his old place, the
                       target to where his body ended).

    Options (panel or config): Pressure (difficulty of the duel), GhostMove (the bystander may walk or stays frozen),
    Controller rules (no inventory / weapons / melee / vehicles; the server also cancels every damage he causes),
    /hback returns both players to where they stood BEFORE the takeover (Config.Takeover.ReturnTo picks the default).

    The server decides everything. The target's client only runs the mini-game and reports the result (validated).
]]

Takeover = {}

local T = {}          -- controller -> state
local byTarget = {}   -- target -> state

local function C() return Config.Takeover end
local function now() return GetGameTimer() end
local function pname(src) return GetPlayerName(src) or tostring(src) end
local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end
local function notify(src, key, ntype, ...)
    if src and Hall.IsOnline(src) then TriggerClientEvent('universal_halluc:client:notify', src, key, ntype or 'inform', nil, ...) end
end

local function coordsOf(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    return { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped), inVeh = GetVehiclePedIsIn(ped, false) ~= 0 }
end

local function place(src, p)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 or not p then return end
    SetEntityCoords(ped, p.x, p.y, p.z, false, false, false, false)
    SetEntityHeading(ped, p.h or 0.0)
end

function Takeover.IsActive(src) return T[src] ~= nil or byTarget[src] ~= nil end

--- For the panel: the takeover this player leads (phase, target) or nil.
function Takeover.Status(src)
    local st = T[src]
    if not st then return nil end
    return { phase = st.phase, target = st.target, targetName = pname(st.target), pressure = st.pressure, ghostMove = st.ghostMove }
end

local function forget(st)
    if T[st.controller] == st then T[st.controller] = nil end
    if byTarget[st.target] == st then byTarget[st.target] = nil end
end

-- ----------------------------------------------------------------------
-- Phase 1
-- ----------------------------------------------------------------------
function Takeover.Talk(controller, target, opts)
    local K = C()
    if not K.Enabled then return false, 'system_disabled' end
    controller, target = tonumber(controller), tonumber(target)
    if not controller or controller <= 0 or not Hall.IsOnline(controller) then return false, 'invalid' end
    if not target or target == controller or not Hall.IsOnline(target) then return false, 'player_not_found' end
    if Takeover.IsActive(controller) or Takeover.IsActive(target) then return false, 'takeover_busy' end
    if World and (World.IsActive(controller) or World.IsActive(target)) then return false, 'world_busy' end
    if Possess.IsActive(controller) or Possess.IsActive(target) then return false, 'possess_busy' end
    if Swap.IsSwapped(controller) or Swap.IsSwapped(target) then return false, 'swap_already' end
    if K.RequireLooks and not (Config.Swap.Enabled and Config.Swap.Looks.Enabled) then return false, 'takeover_need_looks' end

    local a, b = coordsOf(controller), coordsOf(target)
    if not a or not b then return false, 'player_not_found' end
    if a.inVeh or b.inVeh then return false, 'takeover_vehicle' end
    local maxd = Utils.Num(K.MaxDistance, 30.0, 3.0, 200.0)
    if Utils.Dist3(a.x, a.y, a.z, b.x, b.y, b.z) > maxd then return false, 'takeover_far', math.floor(maxd) end

    local sid, why, extra = Possess.Appear(controller, target, Utils.Num(K.TalkSeconds, 300, 10, 1800))
    if not sid then return false, why, extra end
    opts = type(opts) == 'table' and opts or {}
    local G = K.Ghost or {}
    local pressure = tostring(opts.pressure or (K.Contest or {}).Pressure or 'hard')
    if not Config.Resist.Levels[pressure] then pressure = Config.Resist.Level end
    local move = opts.ghostMove
    if move == nil then move = G.Freeze == false end
    local st = { controller = controller, target = target, phase = 'talk', talkSid = sid, wins = 0, losses = 0,
                 pressure = pressure, ghostMove = move == true }
    T[controller], byTarget[target] = st, st
    notify(controller, 'takeover_talk', 'success', pname(target))
    Hall.Audit(('%s started a takeover talk with %s'):format(pname(controller), pname(target)))
    return true
end

-- ----------------------------------------------------------------------
-- Phase 2
-- ----------------------------------------------------------------------
function Takeover.Seize(controller, opts)
    local st = T[tonumber(controller)]
    if not st then return false, 'takeover_none' end
    if st.phase ~= 'talk' then return false, 'takeover_phase' end
    if not Hall.IsOnline(st.target) then return false, 'player_not_found' end
    local K = C()
    if type(opts) == 'table' and type(opts.pressure) == 'string' and Config.Resist.Levels[opts.pressure] then st.pressure = opts.pressure end
    if type(opts) == 'table' and opts.ghostMove ~= nil then st.ghostMove = opts.ghostMove == true end
    st.phase = 'contest'
    st.wins, st.losses = 0, 0
    local sid, why, extra = Hall.Start(st.target, 'takeover', {
        subject = st.controller,
        duration = Utils.Num(K.Contest.Seconds, 45, 10, 180), source = 'director', by = st.controller, force = true,
        params = { pressure = st.pressure },
    })
    if not sid then
        st.phase = 'talk'
        return false, why, extra
    end
    st.contestSid = sid
    notify(st.target, 'takeover_contest', 'warning')
    notify(st.controller, 'takeover_dueling', 'inform')
    return true
end

--- A round of the duel reported by the target (called from Resist.OnResult).
function Takeover.OnResist(src, s, success, ms)
    local st = byTarget[src]
    if not st or st.phase ~= 'contest' or st.contestSid ~= s.sid or st.resolving then return false end
    ms = Utils.Num(ms, 0, 0, 120000)
    if ms < Config.Resist.MinMs then
        Security.Strike(src, 'takeover: round too fast')
        return false
    end
    local t = now()
    if s.nextRound and t < s.nextRound then return false end
    s.nextRound = t + 1200
    if success then st.wins = st.wins + 1 else st.losses = st.losses + 1 end
    TriggerClientEvent('universal_halluc:client:resistDone', src, s.sid, success == true, false)
    local K = C().Contest
    if st.wins >= Utils.Num(K.WinsNeeded, 2, 1, 6) then
        Takeover.TargetWins(st)
    elseif st.losses >= Utils.Num(K.LossesToLose, 1, 1, 6) then
        Takeover.Execute(st)
    end
    return true
end

function Takeover.TargetWins(st)
    if st.resolving then return end
    st.resolving = true
    local csid, tsid = st.contestSid, st.talkSid
    st.contestSid, st.talkSid = nil, nil
    forget(st)
    if csid then Hall.Stop(csid, 'won') end
    if tsid then Hall.Stop(tsid, 'expelled') end      -- the controller vanishes before taking over
    notify(st.target, 'takeover_won', 'success')
    notify(st.controller, 'takeover_expelled', 'error')
    if Hall.IsOnline(st.controller) then Cues.Fire(st.controller, 'glitch', { force = true, by = st.controller }) end
    Hall.Audit(('%s beat %s in the takeover duel'):format(pname(st.target), pname(st.controller)))
    emit('takeoverResult', st.controller, st.target, 'target_won')
end

-- ----------------------------------------------------------------------
-- Phase 3
-- ----------------------------------------------------------------------
function Takeover.Execute(st)
    if st.phase == 'swapped' then return false end
    st.resolving = true
    local c, t, K = st.controller, st.target, C()
    if not (Hall.IsOnline(c) and Hall.IsOnline(t)) then
        Takeover.Abort(st, 'left')
        return false
    end
    local csid, tsid = st.contestSid, st.talkSid
    st.contestSid, st.talkSid = nil, nil
    if csid then Hall.Stop(csid, 'lost') end
    if tsid then Hall.Stop(tsid, 'handover') end

    local cp, tp = coordsOf(c), coordsOf(t)
    st.ctrlHome = cp
    st.targetHome = tp          -- where the player stood before: /hback and ReturnTo = 'origin' use it
    st.phase = 'swapped'
    local secs = Utils.Num(K.MaxSeconds, 300, 10, 3600)

    -- the target: invisible to everybody except the controller, frozen, wearing the controller's look
    st.soloSid = Hall.Start(c, 'solo_visible', { subject = t, duration = secs, source = 'director', by = c, force = true })
    local gsid, why = Hall.Start(t, 'takeover_ghost', { subject = c, duration = secs, source = 'director', by = c, force = true,
        params = { move = st.ghostMove and true or nil } })
    if not gsid then
        Utils.Warn('takeover could not start the ghost session: ' .. tostring(why))
        if st.soloSid then Hall.Stop(st.soloSid, 'takeover_failed') end
        st.resolving = nil
        st.phase = 'talk'
        return false
    end
    st.ghostSid = gsid

    if Config.Swap.Enabled and Config.Swap.Looks.Enabled then
        Swap.Looks(c, c, t, secs, function(ok, reason)
            if T[c] ~= st then
                if ok then Swap.Restore(c, 'takeover_end') end
                return
            end
            st.swapped = ok == true
            if not ok then notify(c, 'possess_noswap', 'warning', reason and Locale(reason) or '') end
        end)
    end
    if K.Teleport ~= false then
        place(c, tp)       -- the controller enters the target's place
        place(t, cp)       -- the target goes to the controller's old place
    end
    Voice.Isolate(t, c)
    Takeover.Lock(c, true, secs)
    TriggerClientEvent('universal_halluc:client:possessInfo', c, gsid, true, t, pname(t), secs)
    notify(c, 'takeover_you', 'success', pname(t))
    if K.Controller == nil or K.Controller.Notice ~= false then notify(c, 'takeover_rules', 'warning') end
    notify(t, 'takeover_lost', 'warning')
    Hall.Audit(('%s took over %s'):format(pname(c), pname(t)))
    emit('takeoverResult', c, t, 'controller_won')
    return true
end

-- ----------------------------------------------------------------------
-- End
-- ----------------------------------------------------------------------
function Takeover.Release(st, reason)
    if st.released then return end
    st.released = true
    Takeover.Lock(st.controller, false)
    local c, t = st.controller, st.target
    local cpNow = Hall.IsOnline(c) and coordsOf(c) or nil
    Voice.Unisolate(t)
    if st.soloSid then Hall.Stop(st.soloSid, 'takeover_end') end
    if st.swapped then Swap.Restore(c, 'takeover_end') end
    if C().Teleport ~= false then
        local origin = st.backToOrigin or C().ReturnTo == 'origin'
        if Hall.IsOnline(c) and st.ctrlHome then place(c, st.ctrlHome) end
        if Hall.IsOnline(t) then
            local spot = origin and st.targetHome or cpNow       -- 'origin': exactly where he stood; otherwise where his body ended
            if spot then place(t, spot) end
        end
    end
    if Hall.IsOnline(c) then TriggerClientEvent('universal_halluc:client:possessInfo', c, st.ghostSid or 0, false) end
    notify(c, 'takeover_ended', 'inform')
    notify(t, 'takeover_ended', 'inform')
    forget(st)
    emit('takeoverEnded', c, t, reason)
end

--- /hback: ends the takeover and puts BOTH players back where they stood before it began.
function Takeover.Back(src)
    local st = T[src] or byTarget[src]
    if not st then return false end
    if st.phase == 'swapped' and st.ghostSid then
        st.backToOrigin = true
        Hall.Stop(st.ghostSid, 'back')
    else
        Takeover.Abort(st, 'back')
    end
    return true
end

--- Tells the controller's client to lock the inventory, weapons, melee and vehicles (Config.Takeover.Controller).
function Takeover.Lock(controller, on, seconds)
    if not controller or not Hall.IsOnline(controller) then return end
    local R = C().Controller or {}
    TriggerClientEvent('universal_halluc:client:takeoverLock', controller, on == true, {
        inventory = R.BlockInventory ~= false, weapons = R.BlockWeapons ~= false, melee = R.BlockMelee ~= false,
        vehicles = R.BlockVehicles ~= false, seconds = Utils.Num(seconds, 300, 5, 3700),
    })
end

--- Is this player the controller of a takeover that is in its swapped phase?
function Takeover.IsControlling(src)
    local st = T[src]
    return st ~= nil and st.phase == 'swapped' and not st.released
end

-- damage he causes is cancelled on the server as well (client locks can be bypassed): no kills, no injuries
AddEventHandler('weaponDamageEvent', function(sender, data)
    local R = C().Controller or {}
    if R.BlockKill == false then return end
    if Takeover.IsControlling(tonumber(sender)) then CancelEvent() end
end)

--- Cancels phase 1 / 2 without a result.
function Takeover.Abort(st, reason)
    local csid, tsid = st.contestSid, st.talkSid
    st.contestSid, st.talkSid, st.resolving = nil, nil, true
    forget(st)
    if csid then Hall.Stop(csid, reason or 'stopped') end
    if tsid then Hall.Stop(tsid, reason or 'stopped') end
end

--- /hrelease, or either player leaving.
function Takeover.Stop(src, reason)
    local st = T[src] or byTarget[src]
    if not st then return false end
    if st.phase == 'swapped' and st.ghostSid then
        Hall.Stop(st.ghostSid, reason or 'released')
    else
        Takeover.Abort(st, reason or 'stopped')
    end
    return true
end

--- Hook of Hall.EndHooks: a session of the takeover has ended.
function Takeover.OnSessionEnd(s, reason)
    for _, st in pairs(T) do
        if st.ghostSid == s.sid then
            Takeover.Release(st, reason)
            return
        elseif st.contestSid == s.sid and st.phase == 'contest' and not st.resolving then
            -- the duel ran out of time: the target lost. Anything else (death, stop) cancels.
            st.contestSid = nil
            if reason == 'timeout' then Takeover.Execute(st) else Takeover.Abort(st, reason) end
            return
        elseif st.talkSid == s.sid and st.phase == 'talk' then
            st.talkSid = nil
            forget(st)
            return
        end
    end
end

CreateThread(function()
    while true do
        Wait(1000)
        for _, st in pairs(T) do
            if st.phase == 'swapped' and st.ghostSid and (Hall.IsDead(st.controller) or Hall.IsDead(st.target)) then
                Hall.Stop(st.ghostSid, 'death')
            end
        end
    end
end)
