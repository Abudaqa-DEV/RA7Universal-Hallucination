--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/health.lua - "why did it not work?": what the clients report about every hallucination, the full self-test,
    and the safety net that registers a player whose client never announced itself.

    The client watches each session (client/engine.lua). If nothing visible happened it reports the reason
    (in_vehicle / no_spot / no_model:<name> / error: ... / dead / no_effect). Everything lands here:
      * a line in the console + a message to the admin who started it,
      * per-type counters (runs / failures / last reason) in the Diagnostics tab,
      * the self-test results (a button runs every type on the admin and tells which ones did not work).
]]

Health = { log = {}, stats = {}, selftest = nil }

local function keep() return math.floor(Utils.Clamp(tonumber((Config.Health or {}).Keep) or 60, 10, 300)) end

local function stat(typeKey)
    local s = Health.stats[typeKey]
    if not s then s = { runs = 0, fails = 0 } Health.stats[typeKey] = s end
    return s
end

--- A hallucination started (called from Hall.Start).
function Health.OnStart(typeKey)
    stat(typeKey).runs = stat(typeKey).runs + 1
end

local function reasonText(reason)
    reason = tostring(reason or '')
    local base, extra = reason:match('^([%w_]+):?(.*)$')
    local key = 'why_' .. (base or 'no_effect')
    local t = Locale(key)
    if t == key then t = reason end            -- unknown reason: show it as it is
    if extra and extra ~= '' and base ~= 'error' then t = t .. ' (' .. extra .. ')' end
    if base == 'error' and extra ~= '' then t = t .. ': ' .. extra end
    return t
end

--- A client reported on one of its sessions.
function Health.Record(s, src, ok, reason, produced)
    local st = stat(s.type)
    local entry = { t = os.time(), type = s.type, src = src, name = GetPlayerName(src) or ('#' .. tostring(src)), ok = ok == true, reason = reason, produced = produced or 0 }
    if ok then
        st.ok = (st.ok or 0) + 1
    else
        st.fails = st.fails + 1
        st.last, st.lastAt = reason, entry.t
        local text = Locale('health_fail', Locale('tn_' .. s.type), entry.name, reasonText(reason))
        Hall.Audit(('[health] %s on %s: %s'):format(s.type, entry.name, reason))
        if s.by and s.by ~= 0 and s.by ~= src and Hall.IsOnline(s.by) then
            TriggerClientEvent('universal_halluc:client:panelLog', s.by, 'health', src, text)
        end
    end
    Health.log[#Health.log + 1] = entry
    while #Health.log > keep() do table.remove(Health.log, 1) end
    local run = Health.selftest
    if run and run.running and run.current and run.current.sid == s.sid then
        run.current.ok, run.current.reason = ok == true, reason
    end
end

RegisterNetEvent('universal_halluc:server:health', function(sid, ok, reason, produced)
    local src = source
    if not Security.Allow(src, 'health') then return end
    if type(sid) ~= 'number' then return end
    local s = Hall.Sessions[sid]
    if not s or not s.targets[src] then return end
    if type(reason) ~= 'string' then reason = 'no_effect' end
    Health.Record(s, src, ok == true, reason:sub(1, 90), math.floor(Utils.Num(produced, 0, 0, 100000)))
end)

-- ----------------------------------------------------------------------
-- Self-test: every type, 8 seconds each, on the admin who pressed the button
-- ----------------------------------------------------------------------
local SKIP = { scene = false }   -- (kept for custom servers: set a type to true to leave it out of the test)

local function testList()
    local list = {}
    for _, key in ipairs(Registry.Order) do
        local meta = Registry.Types[key]
        if meta and not meta.hidden and not meta.needsSubject and Registry.IsEnabled(key) and not SKIP[key] then list[#list + 1] = key end
    end
    return list
end

function Health.StartSelftest(src)
    if Health.selftest and Health.selftest.running then return false, 'selftest_busy' end
    if not Hall.IsOnline(src) then return false, 'player_not_found' end
    local list = testList()
    local run = { running = true, by = src, n = #list, i = 0, results = {}, startedAt = os.time() }
    Health.selftest = run
    CreateThread(function()
        for i, key in ipairs(list) do
            if not run.running or not Hall.IsOnline(src) then break end
            run.i = i
            run.current = { type = key }
            local sid, why = Hall.Start(src, key, { duration = 8, intensity = 0.6, force = true, source = 'selftest', by = src, params = { selftest = true } })
            if not sid then
                run.results[#run.results + 1] = { type = key, ok = false, reason = tostring(why or 'refused') }
            else
                run.current.sid = sid
                local waited = 0
                while run.running and run.current.ok == nil and waited < 9500 do Wait(250) waited = waited + 250 end
                local ok, reason = run.current.ok, run.current.reason
                if ok == nil then ok, reason = false, 'no_report' end
                run.results[#run.results + 1] = { type = key, ok = ok, reason = reason }
                Hall.Stop(sid, 'selftest')
            end
            run.current = nil
            Wait(900)
        end
        run.running, run.current, run.doneAt = false, nil, os.time()
    end)
    return true
end

function Health.StopSelftest()
    local run = Health.selftest
    if not run or not run.running then return false end
    run.running = false
    return true
end

function Health.Reset()
    Health.log, Health.stats = {}, {}
    if Health.selftest and not Health.selftest.running then Health.selftest = nil end
end

--- What the Diagnostics tab shows.
function Health.Panel()
    local stats = {}
    for _, key in ipairs(Registry.Order) do
        local s = Health.stats[key]
        if s and (s.runs > 0 or s.fails > 0) then
            stats[#stats + 1] = { type = key, label = Locale('tn_' .. key), runs = s.runs, fails = s.fails, last = s.last and reasonText(s.last) or nil }
        end
    end
    local log = {}
    for i = math.max(1, #Health.log - 11), #Health.log do
        local e = Health.log[i]
        if e and not e.ok then log[#log + 1] = { t = e.t, label = Locale('tn_' .. e.type), name = e.name, reason = reasonText(e.reason) } end
    end
    local run = Health.selftest
    local st
    if run then
        st = { running = run.running, i = run.i, n = run.n, results = {} }
        for _, r in ipairs(run.results) do
            st.results[#st.results + 1] = { type = r.type, label = Locale('tn_' .. r.type), ok = r.ok == true, reason = (r.ok and r.reason == 'no_signal') and Locale('why_no_signal') or (r.ok and '' or reasonText(r.reason)) }
        end
    end
    return { stats = stats, log = log, selftest = st }
end

-- ----------------------------------------------------------------------
-- Safety net: a player whose client never said "ready" is registered anyway
-- ----------------------------------------------------------------------
AddEventHandler('playerJoining', function()
    local src = source
    local after = Utils.Clamp(tonumber((Config.Health or {}).AutoRegisterAfter) or 45, 10, 300)
    SetTimeout(math.floor(after * 1000), function()
        if GetPlayerName(src) and not Hall.IsOnline(src) then
            Utils.Warn(('player %s (%s) never announced the client script: registered automatically. Check the client console (F8) for errors of %s.'):format(
                tostring(src), tostring(GetPlayerName(src)), GetCurrentResourceName()))
            Hall.OnReady(src, false)
        end
    end)
end)
