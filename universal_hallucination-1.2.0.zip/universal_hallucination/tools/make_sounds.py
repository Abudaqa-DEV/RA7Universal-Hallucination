#!/usr/bin/env python3
"""Synthesises the stronger horror sounds of v1.2 (numpy + scipy + ffmpeg). Original work, no samples, no copyright.
usage: python3 tools/make_sounds.py [out_dir]   (default html/assets/sounds)
Writes: jumpscare, sting, drone, shriek, scare_hit, heart_hard, eyelid, eye_open, eye_drone  (.ogg, stereo, 44.1 kHz)
"""
import os, subprocess, sys, tempfile
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'html', 'assets', 'sounds')
rng = np.random.default_rng(7)

def t_(sec): return np.arange(int(sec * SR)) / SR
def env_exp(t, k): return np.exp(-t * k)
def lp(x, f, o=4): return signal.sosfilt(signal.butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=4): return signal.sosfilt(signal.butter(o, f, 'high', fs=SR, output='sos'), x)
def bp(x, lo, hi, o=2): return signal.sosfilt(signal.butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def drive(x, g): return np.tanh(x * g) / np.tanh(g)
def noise(n): return rng.standard_normal(n)

def reverb(x, sec=1.8, wet=.35, decay=3.2):
    n = int(sec * SR); tt = np.arange(n) / SR
    out = []
    for _ in range(2):
        ir = noise(n) * np.exp(-tt * decay); ir = lp(ir, 5200, 2); ir[0] = 0
        y = np.pad(signal.fftconvolve(x, ir), (0, 1))[:len(x) + n]
        out.append(y)
    L = np.pad(x, (0, n)) * (1 - wet) + out[0] * wet * 4
    R = np.pad(x, (0, n)) * (1 - wet) + out[1] * wet * 4
    return np.stack([L, R], 1)

def finish(st, name, peak=.93, fade=.02):
    st = st / (np.max(np.abs(st)) + 1e-9) * peak
    n = int(fade * SR)
    if n:
        st[-n:] *= np.linspace(1, 0, n)[:, None]; st[:n] *= np.linspace(0, 1, n)[:, None]
    tmp = tempfile.mktemp(suffix='.wav'); wavfile.write(tmp, SR, (st * 32767).astype(np.int16))
    out = os.path.join(OUT, name + '.ogg'); os.makedirs(OUT, exist_ok=True)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-c:a', 'libvorbis', '-q:a', '4', out], check=True); os.remove(tmp)
    print(name, round(len(st) / SR, 2), 's', os.path.getsize(out) // 1024, 'KB')

def boom(sec=2.4):
    t = t_(sec)
    f = 28 + 60 * np.exp(-t * 9); ph = 2 * np.pi * np.cumsum(f) / SR
    sub = np.sin(ph) * env_exp(t, 1.7)
    thump = lp(noise(len(t)), 220) * env_exp(t, 14) * 3
    crack = hp(noise(len(t)), 2500) * env_exp(t, 38) * 1.2
    return sub * 1.4 + thump + crack

def shriek_core(sec=1.7, f0a=620, f0b=1500, seed_vib=6.5):
    t = t_(sec); n = len(t)
    glide = f0a + (f0b - f0a) * (1 - np.exp(-t * 2.2))
    vib = 1 + .035 * np.sin(2 * np.pi * seed_vib * t) + .02 * np.sin(2 * np.pi * 23 * t)
    f = glide * vib * (1 + .06 * noise(n).cumsum() / np.sqrt(np.arange(1, n + 1)))
    ph = 2 * np.pi * np.cumsum(f) / SR
    src = signal.sawtooth(ph) + .5 * signal.square(ph * 1.003) + .25 * noise(n)
    voice = bp(src, 700, 1300) * 1.2 + bp(src, 2300, 3400) * 1.0 + bp(src, 3600, 5200) * .5 + hp(noise(n), 6000) * .08
    a = np.minimum(t / .03, 1) * np.where(t < sec - .5, 1, np.exp(-(t - (sec - .5)) * 6))
    return drive(voice * a, 5)

def make_jumpscare():
    sec = 2.6; x = np.zeros(int(sec * SR))
    x += boom(sec) * .95
    sh = shriek_core(1.7); x[:len(sh)] += sh * .55
    # inharmonic metal ring
    t = t_(sec)
    for fr, a in ((187, .30), (311, .22), (569, .16), (1093, .1)):
        x += np.sin(2 * np.pi * fr * t) * env_exp(t, 2.2) * a
    x = drive(x, 2.2)
    finish(reverb(x, 1.6, .28, 3.0), 'jumpscare')

def make_scare_hit():
    sec = 1.5; x = boom(sec) * 1.1
    t = t_(sec); x += bp(noise(len(t)), 900, 2600) * env_exp(t, 12) * .9
    finish(reverb(drive(x, 2.4), 1.0, .22, 4.5), 'scare_hit')

def make_shriek():
    sh = shriek_core(1.9, 540, 1650, 7.2)
    sh = np.concatenate([sh, np.zeros(int(.3 * SR))])
    finish(reverb(sh, 1.8, .38, 2.6), 'shriek')

def make_sting():
    sec = 3.0; t = t_(sec); x = np.zeros(len(t))
    for i, f in enumerate((233.1, 246.9, 349.2, 370.0, 523.3, 554.4, 740.0)):   # tight semitone clusters = dread
        for d in (-.4, 0, .4):
            ph = 2 * np.pi * (f + d + 1.2 * i * .1) * t
            x += signal.sawtooth(ph) * (.18 / (1 + i * .25))
    swell = np.minimum(t / .06, 1) * (.35 + .65 * np.exp(-t * 1.5)) * np.where(t > sec - .8, np.clip((sec - t) / .8, 0, 1), 1)
    x = lp(x * swell, 3800, 3)
    x += boom(sec) * .5
    finish(reverb(drive(x, 2.0), 1.6, .3, 2.8), 'sting')

def make_drone(sec=14.0):
    t = t_(sec); n = len(t); x = np.zeros(n)
    for f, a, w in ((36.0, 1.0, .07), (36.0 * 1.0295, .8, .05), (54.5, .55, .11), (72.7, .35, .13), (97.3, .22, .17)):
        wob = 1 + .004 * np.sin(2 * np.pi * w * t + f)
        x += signal.sawtooth(2 * np.pi * np.cumsum(f * wob) / SR) * a
    x = lp(x, 260, 4)
    wind = bp(noise(n), 180, 900) * (.35 + .35 * np.sin(2 * np.pi * .13 * t + 1) ** 2) * .5
    metal = sum(np.sin(2 * np.pi * fr * t + k) * (.5 + .5 * np.sin(2 * np.pi * (.05 + .02 * k) * t + k)) * a
                for k, (fr, a) in enumerate(((412, .05), (667, .04), (1013, .03), (1531, .02))))
    x = x * .9 + wind * .35 + metal
    x = reverb(x, 2.2, .35, 1.8)[:n]
    # seamless loop: crossfade the tail into the head
    c = int(1.5 * SR); fo = np.linspace(1, 0, c)[:, None]
    x[:c] = x[:c] * (1 - fo) + x[-c:] * fo; x = x[:-c]
    finish(x, 'drone', .8, 0)

def make_heart_hard():
    beat = np.zeros(int(1.0 * SR)); t = t_(1.0)
    def thud(at, a):
        n = int(.3 * SR); tt = np.arange(n) / SR
        f = 46 + 70 * np.exp(-tt * 28); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 14) * a
        y += lp(noise(n), 160) * np.exp(-tt * 30) * a * .9
        i = int(at * SR); beat[i:i + n] += y[:len(beat) - i]
    thud(.00, 1.0); thud(.21, .75)
    two = np.tile(beat, 3)
    finish(reverb(drive(two, 1.6), .5, .12, 6), 'heart_hard', .9)

def make_eyelid():
    # a wet, soft lid closing: short filtered noise slap + low thump + a faint squelch glide
    sec = .55; t = t_(sec); n = len(t)
    slap = bp(noise(n), 300, 2400) * env_exp(t, 22) * np.minimum(t / .004, 1)
    thump = np.sin(2 * np.pi * np.cumsum(70 * np.exp(-t * 9) + 38) / SR) * env_exp(t, 12) * 1.1
    squelch = np.sin(2 * np.pi * np.cumsum(900 - 650 * np.minimum(t / .18, 1)) / SR) * env_exp(t, 18) * .12 * (.6 + .4 * np.sin(2 * np.pi * 48 * t))
    finish(reverb(drive(slap * .9 + thump + squelch, 1.8), .5, .18, 6), 'eyelid')

def make_eye_open():
    # slow breath in + rising tension swell, ending in a soft wet pop as the eye opens
    sec = 2.6; t = t_(sec); n = len(t)
    breath = bp(noise(n), 350, 3200) * np.sin(np.pi * np.minimum(t / 1.7, 1)) ** 2 * (t < 1.9) * .5
    swell = sum(signal.sawtooth(2 * np.pi * np.cumsum(f * (1 + .08 * t / sec)) / SR) for f in (55, 55.7, 110.4)) * (t / sec) ** 2.2 * .22
    swell = lp(swell, 900, 3)
    pop_t = t - 1.85; pop = np.where(pop_t > 0, np.sin(2 * np.pi * np.cumsum(120 * np.exp(-np.clip(pop_t, 0, None) * 12) + 50) / SR) * np.exp(-np.clip(pop_t, 0, None) * 14), 0) * 1.0
    lid = np.where(pop_t > 0, bp(noise(n), 400, 2600) * np.exp(-np.clip(pop_t, 0, None) * 25) * .6, 0)
    finish(reverb(drive(breath + swell + pop + lid, 1.6), 1.4, .3, 3.5), 'eye_open')

def make_eye_drone(sec=9.0):
    # a low, wet pulse with a very quiet whisper-like formant: something is looking at you
    t = t_(sec); n = len(t)
    pulse = (.55 + .45 * np.sin(2 * np.pi * .9 * t - 1.2)) ** 2
    low = lp(sum(signal.sawtooth(2 * np.pi * np.cumsum(f * (1 + .003 * np.sin(2 * np.pi * .2 * t))) / SR) for f in (41, 41.9, 61.5)), 220, 4) * pulse
    whisper = bp(noise(n), 1800, 4200) * (.5 + .5 * np.sin(2 * np.pi * .35 * t + 2)) ** 3 * .1
    x = reverb(low * .8 + whisper, 1.8, .35, 2.0)[:n]
    c = int(1.2 * SR); fo = np.linspace(1, 0, c)[:, None]; x[:c] = x[:c] * (1 - fo) + x[-c:] * fo; x = x[:-c]
    finish(x, 'eye_drone', .75, 0)

if __name__ == '__main__':
    for fn in (make_jumpscare, make_scare_hit, make_shriek, make_sting, make_drone, make_heart_hard, make_eyelid, make_eye_open, make_eye_drone): fn()
