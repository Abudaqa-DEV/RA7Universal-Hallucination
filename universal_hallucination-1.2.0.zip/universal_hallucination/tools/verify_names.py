#!/usr/bin/env python3
"""Checks every native, ped model, particle, clip set, animation dictionary and timecycle name used by the scripts
against the community reference data. No FiveM server needed.

  git clone --depth 1 https://github.com/citizenfx/natives            natives
  git clone --depth 1 https://github.com/DurtyFree/gta-v-data-dumps   dumps
  python3 tools/verify_names.py natives dumps

Exit code 1 when something is not found. Run it after you edit config.lua or add a type."""
import collections, glob, json, os, re, sys

if len(sys.argv) < 3:
    sys.exit(__doc__)
NAT, DUMP = sys.argv[1], sys.argv[2]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
bad = []

# ---- natives --------------------------------------------------------
pascal = lambda s: ''.join(w.capitalize() for w in s.lower().split('_'))
nat = {os.path.basename(f)[:-3] for f in glob.glob(NAT + '/*/*.md')}
for f in glob.glob(NAT + '/*/*.md'):
    for l in open(f, errors='ignore'):
        if l.startswith('## '): nat.add(pascal(l[3:].strip())); break
files = [f for f in glob.glob('**/*.lua', recursive=True) if not f.startswith(('tests/', 'locales/')) and f != 'fxmanifest.lua']
defined, calls = set(), collections.defaultdict(list)
for f in files:
    s = re.sub(r'--\[\[.*?\]\]', '', open(f, encoding='utf-8').read(), flags=re.S)
    defined |= set(re.findall(r'function\s+([A-Z]\w*)\s*\(', s)) | set(re.findall(r'\b([A-Z]\w*)\s*=\s*function', s)) | set(re.findall(r'^\s*local\s+([A-Z]\w*)\s*=', s, re.M))
    for i, l in enumerate(s.split('\n'), 1):
        for m in re.finditer(r'(?<![\w.:])([A-Z][A-Za-z0-9]+)\s*\(', re.sub(r'--.*$', '', l)): calls[m.group(1)].append(f'{f}:{i}')
RUNTIME = {'CancelEvent', 'CreateThread', 'Wait', 'SetTimeout', 'RegisterNetEvent', 'AddEventHandler', 'TriggerEvent', 'TriggerServerEvent', 'TriggerClientEvent',
           'RegisterCommand', 'RegisterNUICallback', 'RegisterKeyMapping', 'SendNUIMessage', 'LoadResourceFile', 'SaveResourceFile', 'IsDuplicityVersion',
           # FiveM runtime natives that are documented on docs.fivem.net but are not in the citizenfx/natives repository
           'DropPlayer', 'GetActivePlayers', 'GetConvar', 'GetCurrentResourceName', 'GetNumPlayerIdentifiers', 'GetPlayerFromServerId', 'GetPlayerIdentifier',
           'GetPlayerIdentifierByType', 'GetPlayerRoutingBucket', 'GetPlayerServerId', 'GetResourceState', 'IsPlayerAceAllowed', 'PerformHttpRequest', 'SetNuiFocus',
           'Player', 'DEV'}
for k, v in sorted(calls.items()):
    if k not in nat and k not in defined and k not in RUNTIME: bad.append(f'native not found: {k}  ({v[0]})')

# ---- data -----------------------------------------------------------
J = lambda n: json.load(open(f'{DUMP}/{n}'))
peds = {p['Name'].lower() for p in J('peds.json')}
pt = {d['DictionaryName'].lower(): {n.lower() for n in d['EffectNames']} for d in J('particleEffectsCompact.json')}
tcm = {x['Name'].lower() for x in J('timecycleModifiers.json')}
packs = {x.lower() for x in J('pedDamagePacks.json')}
src = open('config.lua', encoding='utf-8').read() + open('client/fx/realism.lua', encoding='utf-8').read()
for m in re.finditer(r"'((?:u|s|a|g|cs|mp|ig|csb)_[mf]?_?[a-z0-9_]+)'", src):
    n = m.group(1).lower()
    if re.match(r'^(u|s|a|g)_[mfc]_|^(cs|ig|csb)_', n) and n not in peds and n != 'cs_flush_anger' and n not in pt and not n.startswith(('u_m_y_zombie_01x',)):
        if '_' in n and n.split('_')[0] in ('cs', 'ig', 'csb', 'u', 's', 'a', 'g'): bad.append(f'ped model not found: {m.group(1)}')
for m in re.finditer(r"Asset\s*=\s*'(\w+)'\s*,\s*Name\s*=\s*'(\w+)'", src):
    if m.group(2).lower() not in pt.get(m.group(1).lower(), ()): bad.append(f'particle not found: {m.group(1)} / {m.group(2)}')
for m in re.finditer(r"(?:Packs|Wounds)\s*=\s*\{([^}]*)\}", src):
    for n in re.findall(r"'([^']+)'", m.group(1)):
        if n.lower() not in packs: bad.append(f'damage pack not found: {n}')
for m in re.finditer(r"(?:Timecycle|Modifier)\s*=\s*'(\w+)'", src):
    if m.group(1).lower() not in tcm: bad.append(f'timecycle modifier not found: {m.group(1)}')

if bad:
    print('NAMES NOT FOUND'); [print('  -', b) for b in sorted(set(bad))]; sys.exit(1)
print(f'ok: {len([c for c in calls if c in nat])} natives, models / particles / damage packs / timecycles all exist')
