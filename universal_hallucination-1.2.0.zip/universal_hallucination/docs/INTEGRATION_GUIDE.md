# Integration: exports and events (server side)

## Exports
`Start(target, type, opts)` `Stop(sid)` `StopAll(target)` `RunScenario(target, name, opts)` `StopScenario(target)`
`IsHallucinating(target)` `GetActive(target)` `GetTypes()` `GetScenarios()` `SetOptOut(target, state)`
`DirectorStart(controller, target, type, spec)` `DirectorSay(controller, text)`
`Hide(viewer, subject, seconds)` `SoloVisible(subject, viewer, seconds)` `GhostVision(target, alpha, seconds)`
`SwapLooks(a, b, seconds)` `RestoreLooks(src)` `StashItems(src)` `DeliverItems(src)`
`Appear(controller, target, seconds)` `Possess(controller, target, seconds, cb)` `Unpossess(src)`
`VoiceLink(controller, target)` `VoiceUnlink(controller)` `Cue(target, cue, opts)` `SetIntensity(sid, v)` `SetIntensityFor(src, v)`
`TakeoverTalk(controller, target, { pressure = 'hard', ghostMove = false })` `TakeoverSeize(controller, opts)` `TakeoverRelease(src)` `TakeoverBack(src)` (both players back where they stood before)
`SetTypeEnabled(type, true|false|nil)` `IsTypeEnabled(type)` (runtime on/off; `nil` = back to the config value)
`AddStress(src, n)` `ReduceStress(src, n)` `SetStress(src, n)` `GetStress(src)` (mind / stress, 0 to `Config.Mind.Max`)

```lua
exports.universal_hallucination:Start(12, 'gunfight', { duration = 40, intensity = 0.8, params = { mode = 'ambush' } })
exports.universal_hallucination:Start(12, 'scene',    { params = { scene = 'memory_family_table' } })
```
`opts`: `duration`, `intensity`, `subject`, `params` (`model`, `source`, `alpha`, `scene`, `mode`, `dialogue`, `count`, `speed`, `weapon`).
Everything passes through the same validation as commands.

## Events (when `Config.Integration.EmitEvents = true`)
`universal_halluc:started (src, sid, type)` · `ended (src, sid, type, reason)` · `scenarioStarted (target, name, total)` ·
`scenarioEnded (target, name, reason)` · `swapped (a, b, itemsDone)` · `swapRestored (src, reason)` ·
`resisted (src, sid, type, success, auto)` · `possessed (controller, target, sid)` · `possessEnded (controller, target, reason)` ·
`takeoverResult` · `takeoverEnded` · `worldStarted` · `worldEnded` · `replied` · `choice`.

State bags (`Config.Integration.StateBags`): `halluc_active`, `halluc_count` on the player.

## Custom bridges (`bridge/custom.lua`)
Framework, appearance, inventory and **voice** (`Custom.Voice.Link/Unlink` on the server, `Custom.Voice.SpeakAs` on the client) can all be replaced by your own functions.

## Examples
```lua
-- a drug script: stress up and a short trip
exports.universal_hallucination:AddStress(source, 20)
exports.universal_hallucination:Start(source, 'acid_trip', { duration = 60, intensity = 0.7 })

-- a medic / psychologist job: lower the patient's stress
exports.universal_hallucination:ReduceStress(patientId, 25)

-- turn a type off for the whole server until restart
exports.universal_hallucination:SetTypeEnabled('zombie_horde', false)
```
