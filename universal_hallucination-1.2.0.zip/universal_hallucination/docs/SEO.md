# SEO and launch kit (GitHub + community)

`gh` cannot change repository settings from here, so apply these by hand. Everything below is ready to paste.

## 1. GitHub repository settings (Settings -> General)
**Description** (max 350 characters):
> Free open-source FiveM hallucination script for roleplay and staff events: zombies, ghosts, a screen that becomes an eye, RESIST! mini-games, takeover duels, haunted zones, scene editor and admin panel. ESX, QBCore, Qbox, standalone. Arabic + English.

**Website:** `https://discord.gg/6EkqysEwD`

**Topics** (add all, max 20):
`fivem` `fivem-script` `fivem-resource` `fivem-roleplay` `fivem-lua` `fivem-nui` `fivem-admin` `fivem-horror` `gta5` `fxserver` `esx` `qbcore` `qbox` `qbx-core` `lua` `hallucination` `horror` `zombie` `roleplay` `ra7dev`

**Social preview:** Settings -> General -> Social preview -> upload `docs/images/social_preview.png` (1280 x 640).

**Features:** keep Issues on; turn on Discussions (Q&A) and add a pinned "Test reports" discussion.

## 2. Release (Releases -> Draft a new release)
Tag `v1.2.0`, title `Universal Hallucination 1.2.0 - eye hallucination, reliability, takeover 2.0`, attach `universal_hallucination-1.2.0.zip`. Body:

```
Free, open source (MIT). ESX / QBCore / Qbox / standalone. Arabic + English.

New
- Eye hallucination: the screen becomes an eye - you see through an eye-shaped opening that opens, blinks, closes completely, then opens again (+ optional giant watcher), cue and scene-editor event
- Takeover 2.0: choose the pressure, the watcher can walk or stay frozen, the controller cannot open the inventory / draw a weapon / fight / drive (server cancels his damage), /hback puts both players back exactly where they were
- Reliability: per-type failure reasons, full self-test, fallback scare, auto-registration
- RESIST! warning phase BEFORE the hallucination starts
- Map tab, Settings tab, stronger horror sounds, qbx / qb-core / es_extended names accepted
Checks: 419 server + 231 client tests, lint, names verified against citizenfx/natives and gta-v-data-dumps.
Not yet run on a real FiveM server by the author: test on a dev server and report in Issues.
Folder name must be universal_hallucination.
```

## 3. README checklist (done)
- H1 with the main keywords, one-paragraph description, badges, screenshots with alt text.
- "Why", install in 4 steps, one-line exports, "Works with", honest comparison table, FAQ, keywords footer.
- Arabic README with the same structure (`README.ar.md`), `CITATION.cff`, MIT licence, issue templates.

## 4. Backlinks and community posts
Post these, in this order, and link back to the repo. Answer every comment (replies are the real ranking signal).

### Cfx.re forum (Releases category)
Title: `[Free][ESX/QBCore/Qbox/Standalone] Universal Hallucination - zombies, ghosts, a screen that becomes an eye, RESIST! mini-games, takeover, admin panel (Arabic + English)`
```
Hi everyone, I am releasing a free hallucination system for roleplay and staff events.

What it does
- 51 hallucination types (zombies in 16 forms, ghosts, shadows, insects, a giant eye and eyelids that open and close, fake lag, phantom wounds, death feeling...), all local to the target
- RESIST! warning before the effect + 4 mini-games, 4 difficulty levels
- Admin panel (no commands): live map, scene editor, haunted zones, stress system, settings
- Takeover: you appear to a player, talk, duel him; if he loses you play his character (no inventory / weapons / fighting / vehicles) and he watches from your place. /hback puts everyone back
- Works with ESX, QBCore, Qbox, standalone, custom. One-line exports for drug / medical scripts
- Reliability tools: it tells you WHY an effect did not run, with a full self-test
- Arabic + English (RTL)

Honest status: 419 server + 231 client mock tests, names verified against citizenfx/natives. Not run on a real server by me yet, so please test on a dev server and report.

GitHub (MIT): https://github.com/Abudaqa-DEV/RA7Universal-Hallucination
Discord: https://discord.gg/6EkqysEwD
```

### Reddit r/FiveM (flair: Release / Free resource)
Title: `I made a free, open-source hallucination system for FiveM RP (zombies, giant eye, resist mini-games, takeover) - ESX / QBCore / Qbox`
Body: the Cfx post above, plus one screenshot (`docs/images/social_preview.png`). Do not post more than one subreddit per day.

### Dev.to
Title: `How I built a hallucination system for FiveM that works on ESX, QBCore and Qbox`
Outline: the problem (RP hallucinations are filters) -> server-authoritative sessions + client effect registry -> the resist warning phase -> the reliability watchdog (why did nothing happen?) -> testing Lua without a server (mock harness + names check against citizenfx/natives) -> link to the repo. Tags: `fivem` `lua` `gamedev` `opensource`.

### Discord announcement (short, <= 2000 characters)
```
🧿 RA7 UNIVERSAL HALLUCINATION 1.2.0
👁 Eye hallucination - the screen becomes an eye: it opens, blinks, shuts completely, then opens again
🔒 Takeover 2.0 - choose your pressure, take his character (no bag, no weapon, no fighting), /hback puts everyone back
🛡 Reliability - it tells you why an effect did not work + full self-test
⚠ RESIST! comes BEFORE the effect
🗺 Map tab · ⚙ Settings tab · 🔊 stronger sounds
Free & open source: https://github.com/Abudaqa-DEV/RA7Universal-Hallucination
Dev by: Abudaqa · RA7 DEV
```

### X / Twitter
`Free FiveM hallucination script: zombies, a screen that becomes an eye, RESIST! mini-games, takeover duels, admin panel. ESX / QBCore / Qbox. Arabic + English. MIT. https://github.com/Abudaqa-DEV/RA7Universal-Hallucination #FiveM #GTARP #FiveMScripts`

### Arabic post (Discord / Twitter / FiveM communities)
```
سكربت هلوسة FiveM مجاني ومفتوح المصدر 🧿
زومبي، عين عملاقة تفتح وتغلق، ألعاب مقاومة، سيطرة على شخصية لاعب (بلا حقيبة ولا سلاح)، لوحة تحكم بخريطة ومحرر مشاهد.
يعمل مع ESX / QBCore / Qbox / standalone. عربي + إنجليزي.
https://github.com/Abudaqa-DEV/RA7Universal-Hallucination
```

## 5. Keywords to keep in titles / descriptions
fivem hallucination script, fivem roleplay hallucination, fivem horror script, fivem zombie script, fivem admin panel, fivem esx qbcore qbox, سكربت هلوسة فايف ام.

## 6. After release
Pin the release in Discord, ask players for **Diagnostics** reports (Issues -> Test report), star the repo, answer every comment for the first week, and update the README "Honest status" once someone confirms it on a real server.
