# Troubleshooting

- **"Nothing happens" / most hallucinations do not work:** open `/hmenu` -> **Diagnostics**. The **Reliability** card lists, per type, the last reason it failed (`in_vehicle`, `no_spot`, `no_model:<name>`, `error`, `no_effect`). Press **Run full test** to try every type on yourself. Typical fixes: be on foot (entities are not spawned while driving), replace the missing model in `Config.Realism`, make sure `ensure universal_hallucination` is *after* your framework, and read the F8 console for `universal_hallucination` errors. A player whose client never said "ready" is registered automatically after `Config.Health.AutoRegisterAfter` seconds.
- **The effect starts before the player can resist:** the warning phase (`Config.Resist.Onset`) gives `Seconds` to fight it first; if you do not want it set `Config.Resist.Onset.Enabled = false`.
- **Takeover: the controller can still open the bag:** ox_inventory and qb-inventory are locked through their state bags; for another inventory implement `Custom.Takeover.Inventory(on)` in `bridge/custom.lua`. Set `Config.Takeover.Controller.BlockInventory = true`.
- **Takeover: something went wrong, put everyone back:** `/hback` (or **Restore places** in the Takeover tab) returns both players to where they stood before; `/hrelease` ends it normally.

- **A ped does not appear:** the model is not in your server. Missing models are skipped silently; set `Config.General.Debug = true` to see which. Edit `Config.Realism` lists.
- **No gun sound:** change `Config.Realism.Gunfire.Sound` (`game`, `sample`, `both`).
- **No muzzle flash / insect particles:** the particle names differ in your game build; edit `Config.Realism.Insects.Particles` or set `MuzzleFlash = false`.
- **Zombie crawler stands or floats:** change `Variants.crawler.Anim` to an animation that exists in your build.
- **Scene changes time/weather and a weather script fights it:** `Config.Types.scene.Environment = false`.
- **Voice does nothing:** `Config.Voice.Enabled = true`, correct `Provider`; for other voice resources use `custom` and fill `Custom.Voice`.
- **Panel does not open:** you need the `universal_hallucination.use` ACE (or a job from `Config.Permissions.Jobs`).
- **Look swap unavailable:** configure `Config.Appearance` with your clothing resource.
- **Target "too many"/"busy":** `Config.Safety.MaxConcurrentPerPlayer`, `BlockWhenBusy`.
- **Something is missing or looks wrong in game:** open `/hmenu` -> **Diagnostics** and run the check. It lists every model, clip set, animation, particle and weapon from your config that does not exist on your build, plus the latest failure reasons. Replace the listed names in `config.lua`.
- **Zones, scenes, places or stress are not saved:** the folder `data/` must exist inside the resource and be writable (the repository ships `data/.gitkeep`). Saved data goes to `data/user_data.json`.
- **A type is greyed out in the panel:** it is switched off in `Config.Switches` (or `Config.Types.<type>.Enabled = false`, or `SetTypeEnabled`).
- **Parallel world / takeover refuse to start:** they refuse each other, vehicles (`Config.World.RefuseInVehicle`) and players who are not online; the panel shows the reason.
- **Echo does not appear:** it needs the player to move away first (`Config.Types.echo.MinGap`) and he must be on foot.
- **Fake lag never happens:** it only triggers while the player is walking faster than `Config.Types.fake_lag.MinSpeed`, on foot, not ragdolled or swimming.
- **The panel feels slow or refreshes too often:** raise `Config.Panel.RefreshMs` (milliseconds, 1000 to 10000, default 2000). Refreshes only redraw the panel when the data actually changed.
