--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa | https://discord.gg/6EkqysEwD | MIT
    shared/settings.lua - the settings you can change from the panel (Settings tab), saved by the server.

    Only the entries below can be changed from the panel: everything else stays in config.lua.
    The saved value wins over config.lua until you press "Reset to config.lua" in the panel.
    Add your own line to Settings.Defs to expose another value (it must be read live by the code).
]]

Settings = { base = {}, applied = {} }

--  k = path in Config | t = bool / num / enum / color | min,max,step (num) | v = allowed values (enum) | g = group in the panel
Settings.Defs = {
    { k = 'Resist.Level',               t = 'enum',  v = { 'easy', 'normal', 'hard', 'nightmare' }, g = 'resist' },
    { k = 'Resist.Enabled',             t = 'bool',  g = 'resist' },
    { k = 'Resist.Cooldown',            t = 'num',   min = 5,  max = 300, step = 5, g = 'resist' },
    { k = 'Resist.Prompt.Enabled',      t = 'bool',  g = 'resist' },
    { k = 'Jumpscare.ImageChance',      t = 'num',   min = 0,  max = 1,   step = 0.05, g = 'scare' },
    { k = 'Cues.Enabled',               t = 'bool',  g = 'scare' },
    { k = 'Notifications.Enabled',      t = 'bool',  g = 'general' },
    { k = 'Zones.Enabled',              t = 'bool',  g = 'general' },
    { k = 'Map.Enabled',                t = 'bool',  g = 'general' },
    { k = 'Brand.Colors.Primary',       t = 'color', g = 'colors' },
    { k = 'Brand.Colors.Accent',        t = 'color', g = 'colors' },
    { k = 'Brand.Colors.Danger',        t = 'color', g = 'colors' },
}

local byKey = {}
for _, d in ipairs(Settings.Defs) do byKey[d.k] = d end

local function walk(path, create)
    local node, last = Config, nil
    local parts = {}
    for p in path:gmatch('[^%.]+') do parts[#parts + 1] = p end
    for i = 1, #parts - 1 do
        if type(node[parts[i]]) ~= 'table' then
            if not create then return nil end
            node[parts[i]] = {}
        end
        node = node[parts[i]]
    end
    return node, parts[#parts]
end

function Settings.Get(path)
    local node, last = walk(path, false)
    if not node then return nil end
    return node[last]
end

--- Validates a raw value for a definition: returns the clean value or nil.
function Settings.Clean(def, raw)
    if not def then return nil end
    if def.t == 'bool' then
        if type(raw) == 'boolean' then return raw end
        return nil
    elseif def.t == 'num' then
        local n = tonumber(raw)
        if not n or n ~= n then return nil end
        return math.min(def.max, math.max(def.min, n))
    elseif def.t == 'enum' then
        for _, v in ipairs(def.v) do if v == raw then return v end end
        return nil
    elseif def.t == 'color' then
        if type(raw) == 'string' and raw:match('^#%x%x%x%x%x%x$') then return raw:upper() end
        return nil
    end
    return nil
end

function Settings.Def(key) return byKey[key] end

--- Applies a table { ['Resist.Level'] = 'hard', ... } to Config (unknown or invalid entries are ignored).
function Settings.Apply(tbl)
    if type(tbl) ~= 'table' then return end
    -- keep what config.lua says, so "reset" can bring it back
    for _, d in ipairs(Settings.Defs) do
        if Settings.base[d.k] == nil then Settings.base[d.k] = Settings.Get(d.k) end
    end
    for _, d in ipairs(Settings.Defs) do
        local v = Settings.Clean(d, tbl[d.k])
        if v ~= nil then
            local node, last = walk(d.k, true)
            node[last] = v
            Settings.applied[d.k] = v
        elseif Settings.applied[d.k] ~= nil and tbl[d.k] == nil then
            -- no longer overridden: back to the value of config.lua
            local node, last = walk(d.k, true)
            node[last] = Settings.base[d.k]
            Settings.applied[d.k] = nil
        end
    end
end

--- The cleaned overrides of a raw table (used before saving).
function Settings.CleanAll(tbl)
    local out = {}
    if type(tbl) ~= 'table' then return out end
    for _, d in ipairs(Settings.Defs) do
        local v = Settings.Clean(d, tbl[d.k])
        if v ~= nil then out[d.k] = v end
    end
    return out
end

--- Everything the panel needs: the list, the current values and the values of config.lua.
function Settings.Panel(saved)
    local defs, cur, base = {}, {}, {}
    for _, d in ipairs(Settings.Defs) do
        defs[#defs + 1] = { k = d.k, t = d.t, v = d.v, min = d.min, max = d.max, step = d.step, g = d.g }
        cur[d.k] = Settings.Get(d.k)
        base[d.k] = Settings.base[d.k] ~= nil and Settings.base[d.k] or Settings.Get(d.k)
    end
    return { defs = defs, values = cur, base = base, saved = saved or {} }
end
