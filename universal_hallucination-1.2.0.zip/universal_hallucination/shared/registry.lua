--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    shared/registry.lua - the list of hallucination types and what each one needs.

      cat           'entity' | 'visual' | 'audio' | 'body' | 'people'
      scope         'targets' (default): the effect runs on the target client(s)
                    'all_except': solo_visible runs on everybody EXCEPT the viewers and the subject
      needsSubject  the type needs a `subject` (server id of another player)
      subjectOpt    the type may use a subject as its look (Source = 'subject')
      controllable  can be puppeted live with /hdirect (Director)
]]

Registry = {}

Registry.Types = {
    -- entities
    ghost        = { cat = 'entity', subjectOpt = true, controllable = true },
    shadow       = { cat = 'entity' },
    stalker      = { cat = 'entity', controllable = true },
    crowd        = { cat = 'entity' },
    zombie_horde = { cat = 'entity' },
    gunfight     = { cat = 'entity' },
    scene        = { cat = 'entity' },
    animals      = { cat = 'entity' },
    gunman       = { cat = 'entity', subjectOpt = true, controllable = true },
    double       = { cat = 'entity', subjectOpt = true, controllable = true },
    echo         = { cat = 'entity', subjectOpt = true },
    friend       = { cat = 'entity', subjectOpt = true, controllable = true },
    -- visual
    distortion = { cat = 'visual' }, acid_trip = { cat = 'visual' }, tunnel_vision = { cat = 'visual' },
    double_vision = { cat = 'visual' }, flicker = { cat = 'visual' }, eyes = { cat = 'visual' }, bugs = { cat = 'visual' },
    blood = { cat = 'visual' }, words = { cat = 'visual' }, tint = { cat = 'visual' },
    camera_sway = { cat = 'visual' }, time_slow = { cat = 'visual' }, fake_notify = { cat = 'visual' },
    -- audio
    heartbeat = { cat = 'audio' }, breathing = { cat = 'audio' }, whispers_audio = { cat = 'audio' },
    footsteps_behind = { cat = 'audio' }, knocking = { cat = 'audio' }, phone_ring = { cat = 'audio' },
    static_noise = { cat = 'audio' }, drone = { cat = 'audio' }, music_box = { cat = 'audio' },
    tinnitus = { cat = 'audio' }, distant_gunshots = { cat = 'audio' },
    -- body
    weapon_tremor = { cat = 'body' }, hand_tremor = { cat = 'body' }, dizzy = { cat = 'body' },
    death_feeling = { cat = 'body' }, self_zombie = { cat = 'body' }, collapse = { cat = 'body' }, drunk = { cat = 'body' },
    insects = { cat = 'visual' }, underwater = { cat = 'visual' },
    fake_lag = { cat = 'body' }, fake_wounds = { cat = 'body' },
    -- people visibility
    hide_player  = { cat = 'people', needsSubject = true },
    solo_visible = { cat = 'people', needsSubject = true, scope = 'all_except' },
    possess      = { cat = 'people', needsSubject = true },
    takeover       = { cat = 'people', needsSubject = true, hidden = true },
    takeover_ghost = { cat = 'people', needsSubject = true, hidden = true },
    world_frozen   = { cat = 'people', hidden = true },
    ghost_vision = { cat = 'people' },
}

-- display order for /hlist and docs
Registry.Order = {
    'ghost', 'shadow', 'stalker', 'crowd', 'zombie_horde', 'animals', 'gunman', 'gunfight', 'scene', 'double', 'echo', 'friend',
    'distortion', 'acid_trip', 'tunnel_vision', 'double_vision', 'flicker', 'bugs', 'blood', 'words', 'tint', 'eyes',
    'camera_sway', 'time_slow', 'fake_notify', 'insects', 'underwater',
    'heartbeat', 'breathing', 'whispers_audio', 'footsteps_behind', 'knocking', 'phone_ring', 'static_noise',
    'drone', 'music_box', 'tinnitus', 'distant_gunshots',
    'weapon_tremor', 'hand_tremor', 'dizzy', 'death_feeling', 'self_zombie', 'collapse', 'drunk', 'fake_lag', 'fake_wounds',
    'hide_player', 'solo_visible', 'possess', 'ghost_vision', 'takeover', 'takeover_ghost', 'world_frozen',
}

function Registry.Has(key)
    return type(key) == 'string' and Registry.Types[key] ~= nil
end

-- runtime overrides (exports SetTypeEnabled): they win over the config until the resource restarts
local Override = {}

--- Config.Switches.<group>[key]: anything other than `false` means on.
function Registry.SwitchOn(group, key)
    local sw = Config.Switches
    if type(sw) ~= 'table' or type(sw[group]) ~= 'table' then return true end
    return sw[group][key] ~= false
end

function Registry.CategoryOn(cat)
    return Registry.SwitchOn('Categories', cat)
end

function Registry.IsEnabled(key)
    if not Registry.Has(key) then return false end
    local c = Config.Types[key]
    if type(c) ~= 'table' then return false end
    if Override[key] ~= nil then return Override[key] end
    if c.Enabled == false then return false end
    if not Registry.SwitchOn('Types', key) then return false end
    local meta = Registry.Types[key]
    if not meta.hidden and not Registry.CategoryOn(meta.cat) then return false end
    return true
end

--- Turns a type on/off while the server runs (nil = back to the config value).
function Registry.SetEnabled(key, value)
    if not Registry.Has(key) then return false end
    if value == nil then Override[key] = nil else Override[key] = value == true end
    return true
end

function Registry.Count()
    local n = 0
    for _ in pairs(Registry.Types) do n = n + 1 end
    return n
end
