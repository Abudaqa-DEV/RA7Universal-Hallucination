<div align="center">

# Universal Hallucination

**A hallucination system for FiveM roleplay and staff events**

Ra7 DEV · Dev by: Abudaqa · [Discord](https://discord.gg/6EkqysEwD) · MIT license (free, open source)

[العربية](README.ar.md) · [Download](https://github.com/Abudaqa-DEV/RA7Universal-Hallucination/releases/latest) · [Install](#install) · [Config](#everything-is-in-configlua) · [Warnings](#warnings--read-before-you-install) · [Help us improve](#help-us-improve) · [Changelog](CHANGELOG.md)

<img src="docs/images/panel_start.png" width="760" alt="Admin panel">

</div>

50 hallucination types, 17 ready scenarios, 6 scenes from the past and the present, a scene editor, haunted zones,
a stress system, live puppeting of imaginary people, possession, a takeover duel, a parallel-world tool, resist
mini-games and a full admin panel. Arabic and English. Works standalone or with ESX, QBCore, Qbox or your own framework.

> **Honest status.** The code is tested with a mock FiveM environment (357 server checks and 115 client checks pass,
> including the bullet-safety and cleanup checks). It has **not** been run in a real FiveM server by the author.
> Native names, ped models, clip sets, particle names, damage packs and third-party voice exports were written from
> memory and documentation. A missing model or particle is skipped silently, and the **Diagnostics** tab in the panel
> lists every name that does not exist on your build. Test on a development server first.
> Sounds are original and synthesized (replace any file in `html/assets/sounds/`).

## Safety by design
- Everything is drawn **locally on the target's client** (peds are not networked). Other players do not see it.
- Nothing can hurt the player. Bullets have `damage = 0`, shooters have **0 ammo**, and every bullet line is checked
  before it is fired: it must pass at least `Config.Realism.Gunfire.MinMiss` (never below 1.0 m) from the head, chest and feet.
- "Near-death" never kills. It ends with a faint and a wake-up. Phantom wounds are visual only.
- The server is the only authority: permissions, enabled types, clamps, concurrency, opt-out and rate limits.
  Everything the panel sends is re-validated on the server.
- No telemetry, no remote code, no hidden commands.

## What is inside
| Group | Types |
|---|---|
| Entities | ghost, shadow, stalker, crowd, **zombie_horde**, animals, gunman, **gunfight**, **scene**, double, **echo**, friend |
| Visual | distortion, acid_trip, tunnel_vision, double_vision, flicker, bugs, **insects**, blood, words, tint, camera_sway, time_slow, fake_notify, **underwater** |
| Audio | heartbeat, breathing, whispers, footsteps_behind, knocking, phone_ring, static_noise, drone, music_box, tinnitus, distant_gunshots |
| Body | weapon_tremor, hand_tremor, dizzy, **death_feeling**, **self_zombie**, **collapse**, **drunk**, **fake_lag**, **fake_wounds** |
| People | hide_player, solo_visible, possess, ghost_vision |

### Highlights
- **Everything from the panel, no commands needed** (commands exist too and can be renamed or turned off).
- **Haunted zones** - stand somewhere, press "Create zone here"; everybody who enters gets the chosen hallucination (chance, rest time, radius, intensity).
- **Mind / stress** - a persistent stress counter per character. Death, injuries and hallucinations raise it, time calms it, and the higher it is the more automatic hallucinations start. Psychologists lower it from the panel; other scripts use `AddStress` / `ReduceStress`.
- **Scene editor** - add actors, drag them on a map, write their lines and moves, pick the filter/weather/hour, test on yourself and save. No code.
- **Takeover** - appear to one player, talk, start a duel mini-game; if he loses you take his place and he is frozen watching. Everything is restored at the end.
- **Parallel world** - send a player to another place (own routing bucket), frozen so he can only look, bring real staff next to him, return everybody with one button.
- **Real-feeling effects** - gunfights with bullets that miss, zombies with several behaviours, real insects, death feeling, an echo of yourself walking your old path, fake lag, mic-to-mic voice.
- **Diagnostics** - one button checks every model / clip set / animation / particle / weapon in your config inside the game.
- **Turn any hallucination on/off** from `Config.Switches`.

<div align="center">
<img src="docs/images/panel_zones.png" width="370" alt="Haunted zones"> <img src="docs/images/panel_editor.png" width="370" alt="Scene editor">
<img src="docs/images/panel_takeover.png" width="370" alt="Takeover"> <img src="docs/images/panel_world.png" width="370" alt="Parallel world">
</div>

## Install
1. Download `universal_hallucination-x.y.z.zip` from the [latest release](https://github.com/Abudaqa-DEV/RA7Universal-Hallucination/releases/latest) and put the folder `universal_hallucination` in `resources/`.
   **The folder must be named exactly `universal_hallucination`.** If you used "Code -> Download ZIP" or `git clone`, the folder is called `RA7Universal-Hallucination(-main)`: rename it (or clone with `git clone https://github.com/Abudaqa-DEV/RA7Universal-Hallucination.git universal_hallucination`), otherwise exports and `ensure` use the wrong name.
2. `server.cfg`:
```
ensure universal_hallucination
add_ace group.admin universal_hallucination.use allow
add_ace group.admin universal_hallucination.director allow
add_ace group.admin universal_hallucination.swap allow
add_ace group.admin universal_hallucination.admin allow
```
3. Open `config.lua` and set the language, brand, colors and framework. Restart.
4. In game open the panel with `/hmenu`, go to the **Diagnostics** tab and run the check once.

Requirements: OneSync, a recent FiveM server build (Lua 5.4). Optional: pma-voice / mumble / saltychat (voice features), illenium-appearance / fivem-appearance (look swap).

| Permission | Allows |
|---|---|
| `.use` | start / stop hallucinations, scenarios, cues, panel |
| `.director` | live puppeting, possession, takeover, parallel world, stress tools |
| `.swap` | look and item swap |
| `.admin` | zones, scene editor, diagnostics, places, opt-out bypass |

## Everything is in `config.lua`
Brand, colors, texts, language, commands, permissions, every type's duration / intensity / models / sounds, scenarios,
scenes, cues, zones, stress levels, places, voice, takeover and safety limits - each value has an Arabic + English
comment, a range and a default. See [docs/CONFIGURATION.md](docs/CONFIGURATION.md).

```lua
Config.Switches = {
    Categories = { audio = false },     -- turns every audio type off
    Types      = { ghost = false },     -- turns one type off
    Scenarios  = { paranoia = false },
}
```

## Commands (all optional)
| Command | What it does |
|---|---|
| `/hmenu` | Admin panel |
| `/halluc <id\|me> <type> [seconds] [intensity]` | Start one type |
| `/hscenario <id\|me> <name> [seconds]` | Timeline scenario |
| `/hscene <id\|me> <scene> [seconds]` | Scene from `Config.Scenes` |
| `/hstop [id\|all]`, `/hlist` | Stop, list |
| `/hhide`, `/hsolo`, `/hghost` | Hide a player from viewers / visible to one viewer only / translucent players |
| `/hdirect <id> [type] [model\|player:<id>]`, `/hsay`, `/hr` | Live puppeting, speech, the target's reply |
| `/happear <id>` | Appear with your own look to ONE player |
| `/hpossess <id>`, `/hunpossess` | The player watches through your eyes, frozen and silent; you speak for him |
| `/hvoice <id>` | Toggle mic-to-mic voice |
| `/htake <id>`, `/hseize`, `/hrelease [id]` | Takeover: talk, duel, end |
| `/hcue <id\|me> <cue>`, `/hadjust <id\|me> <0-1>` | Instant cue, live intensity |
| `/hswap`, `/hrestore`, `/hcarry` | Look swap (needs a clothing provider), restore, item carry |
| `/hoff` | A player opts out of command hallucinations |

Resist key: `G` (change in `Config.Resist`). Every command name can be changed in `Config.Commands`.
Exports and events for other scripts (drugs, medical, jobs): [docs/INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md).

## Warnings - read before you install
1. **Not tested on a real FiveM server yet** (only a mock environment). Install it on a development server first and make a backup before putting it on a live one.
2. **Flashing lights and jump scares.** `flicker`, the cues `jumpscare` / `blackout` / `glitch` / `blood_rain`, `tint` pulses and the zombie scare flash can be unpleasant or unsafe for people with photosensitive epilepsy. Turn them off in `Config.Switches` if your community needs it, and tell your players.
3. **Tell your players.** Hallucinations, takeover and the parallel world act on real players. Put the rules in your server rules; players can opt out of command hallucinations with `/hoff`.
4. **Permissions are powerful.** `.director` and `.admin` allow takeover, parallel world, zones and the scene editor. Never give them to normal players.
5. **Names from memory.** Models, clip sets, animations, particles and damage packs may not exist on your build. Run **Diagnostics** in the panel and fix the listed names in `config.lua`.
6. **Takeover is visual:** it swaps the look and position, not the framework identity (name, job, inventory).
7. Voice, look swap and weather features depend on other resources you run; see [Known limits](#known-limits).

## Help us improve
This is a free project and the biggest help right now is **testing on real servers**.
- **Run the Diagnostics tab** (`/hmenu` -> Diagnostics) and [send us the list](https://github.com/Abudaqa-DEV/RA7Universal-Hallucination/issues/new?template=test_report.md) of names that do not exist on your build. This is the most valuable report we can get.
- **Report bugs** with the [bug template](https://github.com/Abudaqa-DEV/RA7Universal-Hallucination/issues/new?template=bug_report.md): what happened, what you expected, framework, version, console output (server + F8).
- **Suggest ideas** with the [feature template](https://github.com/Abudaqa-DEV/RA7Universal-Hallucination/issues/new?template=feature_request.md) or in our [Discord](https://discord.gg/6EkqysEwD).
- **Share scenes, scenarios, zones and translations** (a new `locales/xx.lua`), or open a pull request. See [CONTRIBUTING.md](CONTRIBUTING.md).
- **Star the repository**, show it to other servers, and keep the credit line (MIT license requires the license file only; the credit is appreciated).

## Docs
[Installation](docs/INSTALLATION.md) · [Configuration](docs/CONFIGURATION.md) · [Integration](docs/INTEGRATION_GUIDE.md) · [Troubleshooting](docs/TROUBLESHOOTING.md) · [Architecture](docs/ARCHITECTURE.md)
Contributions: [CONTRIBUTING.md](CONTRIBUTING.md). Security: [SECURITY.md](SECURITY.md).

## Credits
Font: [Cairo](https://github.com/Gue3bara/Cairo) by The Cairo Project Authors, SIL Open Font License 1.1 (`html/assets/fonts/OFL.txt`).

## Known limits
- Hallucinations are client-side drawings; a modified client can ignore effects on itself.
- Resist results are reported by the client; the server checks session, minimum time, cooldown and rate only.
- Takeover swaps the look and the position, **not** the character identity inside your framework (name, job, inventory).
- Look swap and possession look need a clothing resource (illenium-appearance, fivem-appearance or custom); without it, possession is camera only.
- Voice isolation / mic-to-mic depends on your voice resource; if names differ use `Provider = 'custom'`.
- Local weather/time changes in scenes can conflict with weather-sync scripts (`Config.Types.scene.Environment = false` disables them).
- The example places in `Config.Places` have approximate coordinates; adjust them or save your own from the panel.
- Phantom-wound decals are drawn on the player's own ped; whether other players can see them depends on the game build.
