"""Shared mock data for the UI screenshots (not shipped logic)."""
import json, re

def load_locale(lang):
    src = open(f'locales/{lang}.lua', encoding='utf-8').read()
    out = {}
    for m in re.finditer(r"\['([^']+)'\] = '((?:[^'\\]|\\.)*)',", src):
        k, v = m.group(1), m.group(2).replace("\\'", "'").replace('\\n', '\n')
        if k.startswith(('ui_', 'type_', 'cat_', 'tn_')): out[k] = v
    return out

TYPES = [
 ('ghost','entity',0.5,90,True,False,True),('shadow','entity',0.5,75,False,False,False),('stalker','entity',0.5,120,False,False,True),
 ('crowd','entity',0.5,90,False,False,False),('zombie_horde','entity',0.6,60,False,False,False),('animals','entity',0.5,60,False,False,False),
 ('gunman','entity',0.6,45,False,True,True),('gunfight','entity',0.7,40,False,False,False),('scene','entity',0.7,60,False,False,False),('double','entity',0.5,90,False,True,True),('echo','entity',0.5,120,False,False,True),('friend','entity',0.5,600,False,True,True),
 ('distortion','visual',0.5,90,False,False,False),('acid_trip','visual',0.6,90,False,False,False),('tunnel_vision','visual',0.6,60,False,False,False),
 ('double_vision','visual',0.5,60,False,False,False),('flicker','visual',0.5,75,False,False,False),('bugs','visual',0.5,75,False,False,False),
 ('blood','visual',0.5,45,False,False,False),('words','visual',0.5,75,False,False,False),('tint','visual',0.5,75,False,False,False),
 ('camera_sway','visual',0.5,60,False,False,False),('time_slow','visual',0.4,45,False,False,False),('fake_notify','visual',0.5,120,False,False,False),
 ('heartbeat','audio',0.5,60,False,False,False),('breathing','audio',0.5,60,False,False,False),('whispers_audio','audio',0.5,75,False,False,False),
 ('footsteps_behind','audio',0.5,60,False,False,False),('knocking','audio',0.5,60,False,False,False),('phone_ring','audio',0.5,45,False,False,False),
 ('static_noise','audio',0.5,45,False,False,False),('drone','audio',0.5,75,False,False,False),('music_box','audio',0.5,60,False,False,False),
 ('tinnitus','audio',0.5,30,False,False,False),('distant_gunshots','audio',0.5,60,False,False,False),
 ('death_feeling','body',0.85,45,False,False,False),('self_zombie','body',0.7,90,False,False,False),('collapse','body',0.6,45,False,False,False),('drunk','body',0.6,90,False,False,False),('insects','visual',0.6,75,False,False,False),('underwater','visual',0.7,40,False,False,False),
 ('weapon_tremor','body',0.6,90,False,False,False),('hand_tremor','body',0.4,60,False,False,False),('dizzy','body',0.5,60,False,False,False),
 ('hide_player','people',1,120,True,False,False),('solo_visible','people',1,120,True,False,False),('ghost_vision','people',1,120,False,False,False),
]

def panel_data(lang):
    L = load_locale(lang)
    types = []
    for k,cat,i,d,ns,so,ctl in TYPES:
        types.append(dict(key=k,cat=cat,label=L.get('type_'+k,k),short=L.get('tn_'+k,k),enabled=(k!='time_slow'),duration=d,intensity=i,needsSubject=ns and k in('hide_player','solo_visible'),subjectOpt=so,controllable=ctl))
    cues = [dict(key=k,label=l,duration=d) for k,l,d in [('jumpscare','جمب سكير' if lang=='ar' else 'Jumpscare',1.4),('blackout','انقطاع الإضاءة' if lang=='ar' else 'Blackout',3),('heartbeat_rush','تسارع القلب' if lang=='ar' else 'Heartbeat rush',8),('glitch','تشويش الصورة' if lang=='ar' else 'Glitch',2.2),('quake','هزة أرضية' if lang=='ar' else 'Quake',4),('whispers','همسات' if lang=='ar' else 'Whispers',6),('blood_rain','مطر الدم' if lang=='ar' else 'Blood rain',5),('freeze','تجمّد وبرد' if lang=='ar' else 'Freeze',3)]]
    names = ['Abudaqa','Khalid_RP','Sara Mendez','Omar','Lina Park','Yusuf']
    players = [dict(id=i+1,name=n,active=(2 if i==1 else 1 if i==3 else 0),swapped=(i==4),stress=[8,62,85,34,12,47][i]) for i,n in enumerate(names)]
    active = [
      dict(sid=12,type='ghost',label=L['type_ghost'],target=2,targetName='Khalid_RP',intensity=.6,remaining=74,controlled=False),
      dict(sid=13,type='heartbeat',label=L['type_heartbeat'],target=2,targetName='Khalid_RP',intensity=.4,remaining=41,controlled=False),
      dict(sid=14,type='friend',label=L['type_friend'],target=4,targetName='Omar',intensity=.5,remaining=312,controlled=True),
    ]
    sc = [dict(key='drug_trip',label='رحلة مخدرات' if lang=='ar' else 'Drug trip',duration=150),dict(key='haunted',label='منزل مسكون' if lang=='ar' else 'Haunted',duration=180),dict(key='zombie_delusion',label='وهم الزومبي' if lang=='ar' else 'Zombie delusion',duration=120),dict(key='imaginary_friend',label='صديق وهمي' if lang=='ar' else 'Imaginary friend',duration=600)]
    scenes=[dict(key='memory_family_table',label='ذكرى: مائدة العائلة' if lang=='ar' else 'Memory: family table',mode='past',duration=36),dict(key='memory_shooting_night',label='ذكرى: ليلة إطلاق النار' if lang=='ar' else 'Memory: the shooting night',mode='past',duration=34),dict(key='present_ambush',label='الحاضر: كمين مسلح' if lang=='ar' else 'Present: armed ambush',mode='present',duration=30),dict(key='present_hospital_staff',label='الحاضر: طاقم المستشفى' if lang=='ar' else 'Present: hospital staff',mode='present',duration=32)]
    return dict(me=1,players=players,types=types,scenarios=sc,scenes=scenes,active=active,dialogues=[],cues=cues,
      perms=dict(use=True,director=True,swap=True,admin=True),resist=dict(enabled=True,key='G'),possess=True,swapEnabled=True,itemsSwap=False,
      places=[dict(key='hospital_room',label='غرفة مستشفى' if lang=='ar' else 'Hospital room',user=False),dict(key='empty_lot',label='أرض فارغة' if lang=='ar' else 'Empty lot',user=False),dict(key='u_my_base',label='مقر الإدارة' if lang=='ar' else 'Staff HQ',user=True)],
      worlds=[dict(target=2,targetName='Khalid_RP',place='غرفة مستشفى' if lang=='ar' else 'Hospital room',staff=['Abudaqa','Sara Mendez'],controller=1,remaining=212,bucket=7000)],
      worldCfg=dict(enabled=True,bucket=True,fade=True,max=1800,maxStaff=8),takeover=dict(phase='talk',target=3,targetName='Sara Mendez'),takeoverEnabled=True,
      zones=[dict(key='z_old_house',label=dict(ar='البيت المهجور',en='Abandoned house'),type='ghost',radius=30,intensity=.6,duration=60,chance=.35,cooldown=180,enabled=True),dict(key='z_cemetery',label=dict(ar='المقبرة',en='Cemetery'),type='whispers_audio',radius=60,intensity=.5,duration=45,chance=.5,cooldown=240,enabled=False)],
      zoneTypes=[t[0] for t in TYPES if t[0] not in ('hide_player','solo_visible','ghost_vision')],zoneCfg=dict(enabled=True,max=40,defaults=dict(Radius=25,Type='ghost',Intensity=.6,Duration=60,Chance=.35,Cooldown=180)),
      mindCfg=dict(enabled=True,max=100,levels=[dict(at=30,types=['heartbeat','whispers_audio','tinnitus']),dict(at=55,types=['ghost','shadow','flicker','bugs']),dict(at=80,types=['stalker','insects','zombie_horde','death_feeling'])]),
      userScenes=['my_scene'],sceneDefs=dict(my_scene=dict(User=True,Label=dict(ar='مشهد الاختبار',en='Test scene'),Mode='past',Duration=40,Look=dict(Timecycle='NG_filmic02',Tint='#8A6A3A',Grain=True,Clock=dict(h=19,m=0)),
        Actors=[dict(Id='mom',Name=dict(ar='أمي',en='Mom'),Model='a_f_m_business_02',At=dict(fwd=4.5,right=-2.5),Lines=[dict(t=3,text=dict(ar='تأخرت يا بني',en='You are late, son'))],Timeline=[dict(t=8,Do='walk',to=dict(fwd=2,right=-1))]),
                dict(Id='dad',Name=dict(ar='أبي',en='Dad'),Model='a_m_m_business_01',At=dict(fwd=5.5,right=2.5),Lines=[],Timeline=[]),
                dict(Id='kid',Name=dict(ar='الطفل',en='Kid'),Model='a_m_y_hipster_01',At=dict(fwd=8,right=0.5),Lines=[],Timeline=[]),
                dict(Id='guard',Name=dict(ar='حارس',en='Guard'),Model='s_m_m_security_01',At=dict(fwd=-4,right=-6),Lines=[],Timeline=[])],Events=[dict(t=10,Do='flash')])))

def config_msg(lang):
    L = load_locale(lang)
    return dict(brand=dict(name='Universal Hallucination',server='My Server',dev='Abudaqa',discord='https://discord.gg/6EkqysEwD',version='1.0.7',
        colors=dict(Primary='#5B7CFA',Accent='#8CA2FF',Danger='#E04458',Background='#0D1021',Border='#252B4D',Text='#E8EBFA',MutedText='#8A91B8')),
        lang=lang,rtl=(lang=='ar'),font='Cairo',fontSize=17,dialogue=dict(Position='bottom-center',OffsetY=110,Width=560,Radius=16,TypeSpeed=0,ShowSpeaker=True),
        bubble=True,talkHint=True,bloodColor='#7A0000',sounds=dict(enabled=True,master=.9),panelRefresh=2000,texts=L)
