--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    shared/locale.lua - translation helper.

    To add a new language: copy locales/en.lua to locales/xx.lua, translate the
    values, change the two language codes inside it, then set
    Config.General.Language = 'xx'. No other file needs to change.
]]

Locales = Locales or {}      -- Locales['en'] = { key = 'text' }
LocaleMeta = LocaleMeta or {} -- LocaleMeta['ar'] = { rtl = true, name = '...' }

local function activeSet()
    local lang = Config.General.Language
    if Locales[lang] then return Locales[lang], lang end
    return Locales['en'] or {}, 'en'
end

--- Translate a key. Extra arguments are applied with string.format.
---@param key string
---@return string
function Locale(key, ...)
    local set = activeSet()
    local str = set[key]
    if str == nil then str = (Locales['en'] or {})[key] end
    if str == nil then return tostring(key) end

    if select('#', ...) > 0 then
        local ok, res = pcall(string.format, str, ...)
        if ok then return res end
    end
    return str
end

--- Information about the active language (used by the NUI for RTL/LTR).
function LocaleInfo()
    local _, lang = activeSet()
    local meta = LocaleMeta[lang] or {}
    return { lang = lang, rtl = meta.rtl == true, name = meta.name or lang }
end
