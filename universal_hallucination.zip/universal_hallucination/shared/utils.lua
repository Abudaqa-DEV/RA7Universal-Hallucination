--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    shared/utils.lua - small helpers used on both client and server.
]]

Utils = {}
Utils.IsServer = IsDuplicityVersion()

local PREFIX = '^5[universal_hallucination]^7'

function Utils.Clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

function Utils.Round(v, decimals)
    local m = 10 ^ (decimals or 0)
    return math.floor(v * m + 0.5) / m
end

--- Safe number: returns `default` when `v` is not a finite number, then clamps to [lo, hi].
function Utils.Num(v, default, lo, hi)
    v = tonumber(v)
    if not v or v ~= v or v == math.huge or v == -math.huge then return default end
    if lo and v < lo then v = lo end
    if hi and v > hi then v = hi end
    return v
end

--- Random float between a and b (order independent).
function Utils.Rand(a, b)
    if a > b then a, b = b, a end
    if a == b then return a end
    return a + math.random() * (b - a)
end

--- Random value from a { min =, max = } range (or the number itself). `scale` multiplies the result.
function Utils.Range(r, default, scale)
    local v
    if type(r) == 'table' then
        local lo, hi = tonumber(r.min), tonumber(r.max)
        if lo and hi then v = Utils.Rand(lo, hi) elseif lo then v = lo elseif hi then v = hi end
    elseif tonumber(r) then
        v = tonumber(r)
    end
    if v == nil then v = default or 0 end
    return v * (scale or 1)
end

--- Random element of a list (nil when empty).
function Utils.Pick(list)
    if type(list) ~= 'table' or #list == 0 then return nil end
    return list[math.random(1, #list)]
end

function Utils.Log(...) print(PREFIX, ...) end

Utils.DebugLog = {}   -- the last messages, shown by the panel's Diagnostics tab even when Debug is off

function Utils.Debug(...)
    local parts = {}
    for i = 1, select('#', ...) do parts[#parts + 1] = tostring((select(i, ...))) end
    local log = Utils.DebugLog
    log[#log + 1] = table.concat(parts, ' '):sub(1, 200)
    if #log > 40 then table.remove(log, 1) end
    if Config and Config.General and Config.General.Debug then print(PREFIX .. '^3[debug]^7', ...) end
end

function Utils.Warn(...) print('^3[universal_hallucination] WARNING:^7', ...) end
function Utils.Error(...) print('^1[universal_hallucination] ERROR:^7', ...) end

function Utils.Contains(list, value)
    if type(list) ~= 'table' then return false end
    for i = 1, #list do
        if list[i] == value then return true end
    end
    return false
end

--- Converts vector3 / {x,y,z} into plain x, y, z numbers (or nil).
function Utils.XYZ(c)
    local t = type(c)
    if t ~= 'table' and t ~= 'vector3' and t ~= 'vector4' then return nil end
    local x, y, z = tonumber(c.x), tonumber(c.y), tonumber(c.z)
    if not x or not y or not z then return nil end
    return x, y, z
end

function Utils.Dist3(ax, ay, az, bx, by, bz)
    local dx, dy, dz = ax - bx, ay - by, az - bz
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

function Utils.Dist2(ax, ay, bx, by)
    local dx, dy = ax - bx, ay - by
    return math.sqrt(dx * dx + dy * dy)
end

--- Picks the text of the active language from { ar = '', en = '' } (or returns the string itself).
function Utils.Text(v)
    if type(v) == 'string' then return v end
    if type(v) ~= 'table' then return '' end
    local lang = Config.General.Language
    return v[lang] or v.en or v.ar or ''
end

--- Pool of texts in the active language: Config.Texts[name][lang]
function Utils.Pool(name)
    local pool = Config.Texts and Config.Texts[name]
    if type(pool) ~= 'table' then return {} end
    local lang = Config.General.Language
    local list = pool[lang] or pool.en or pool.ar
    return type(list) == 'table' and list or {}
end

--- A plain text safe for display/logs: strips control chars, trims, limits the length.
function Utils.CleanText(s, maxLen)
    if type(s) ~= 'string' then return nil end
    s = s:gsub('[%c]', ' '):gsub('%s+', ' ')
    s = s:match('^%s*(.-)%s*$')
    if s == '' then return nil end
    maxLen = maxLen or 160
    if #s > maxLen then s = s:sub(1, maxLen) end
    return s
end

local HEX = { 3, 4, 6, 8 }
function Utils.IsHexColor(v)
    if type(v) ~= 'string' then return false end
    local body = v:match('^#(%x+)$')
    if not body then return false end
    for _, n in ipairs(HEX) do if #body == n then return true end end
    return false
end

--- Light validation of the most important Config values. Never throws; it repairs bad values and warns.
function Utils.SanitizeConfig()
    local S = Config.Safety
    local function fix(tbl, key, default, lo, hi)
        local old = tbl[key]
        local new = Utils.Num(old, default, lo, hi)
        if old ~= new then
            Utils.Warn(('Config value "%s" was invalid (%s) and has been replaced with %s'):format(key, tostring(old), tostring(new)))
            tbl[key] = new
        end
    end

    fix(S, 'MaxConcurrentPerPlayer', 8, 1, 30)
    fix(S, 'MaxDuration', 1800, 5, 7200)
    fix(S, 'MinIntensity', 0.05, 0.0, 1.0)
    fix(S, 'TimeScaleMin', 0.6, 0.3, 1.0)
    fix(Config.Director, 'LineSeconds', 6.0, 2.0, 30.0)
    fix(Config.Director, 'MaxLineLength', 160, 20, 400)
    fix(Config.Director, 'ReplyMaxLength', 120, 10, 300)
    fix(Config.Sounds, 'Master', 0.9, 0.0, 1.0)
    fix(Config.Appearance, 'ResponseTimeoutMs', 4000, 1000, 15000)
    fix(Config.Swap.Looks, 'MaxSeconds', 900, 10, 7200)
    fix(Config.Resist, 'Key', 47, 0, 360)
    fix(Config.Resist, 'Difficulty', 0.5, 0.0, 1.0)
    fix(Config.Resist, 'GameSeconds', 7, 3, 20)
    fix(Config.Resist, 'Cooldown', 12, 2, 300)
    fix(Config.Resist, 'MinMs', 1200, 300, 10000)
    fix(Config.Resist.OnSuccess, 'Reduce', 0.35, 0.0, 1.0)
    fix(Config.Resist.OnSuccess, 'EndBelow', 0.18, 0.0, 1.0)
    fix(Config.Resist.OnFail, 'Increase', 0.12, 0.0, 1.0)
    fix(Config.Resist.OnFail, 'Max', 1.0, 0.1, 1.0)
    fix(Config.Possess, 'MaxSeconds', 300, 10, 3600)
    fix(Config.Possess, 'CamHz', 12, 4, 20)
    fix(Config.Panel, 'RefreshMs', 2000, 1000, 10000)
    fix(Config.Realism.Gunfire, 'MinMiss', 1.2, 1.0, 6.0)
    fix(Config.Voice, 'SpeakAsRange', 12.0, 3.0, 60.0)
    fix(Config.Voice, 'ChannelBase', 9000, 1, 60000)
    fix(Config.Takeover, 'MaxDistance', 30.0, 3.0, 200.0)
    fix(Config.Takeover, 'TalkSeconds', 300, 10, 1800)
    fix(Config.Takeover, 'MaxSeconds', 300, 10, 3600)
    fix(Config.Takeover.Contest, 'Seconds', 45, 10, 180)
    fix(Config.Takeover.Contest, 'WinsNeeded', 2, 1, 6)
    fix(Config.Takeover.Contest, 'LossesToLose', 1, 1, 6)
    for key, c in pairs(Config.Cues.Items) do
        if type(c) == 'table' then fix(c, 'Duration', 3, 0.5, 30) end
    end

    -- Config.Switches: warn about typos (a misspelled key would silently do nothing)
    if type(Config.Switches) ~= 'table' then Config.Switches = {} end
    local known = {
        Types = Registry and Registry.Types, Categories = { entity = 1, visual = 1, audio = 1, body = 1, people = 1 },
        Scenarios = Config.Scenarios, Cues = Config.Cues and Config.Cues.Items, Scenes = Config.Scenes,
    }
    for group, list in pairs(Config.Switches) do
        if type(list) == 'table' and known[group] then
            for k, v in pairs(list) do
                if known[group][k] == nil then Utils.Warn(('Config.Switches.%s.%s does not exist (typo?)'):format(group, tostring(k))) end
                if type(v) ~= 'boolean' then Utils.Warn(('Config.Switches.%s.%s must be true or false'):format(group, tostring(k))) end
            end
        elseif not known[group] then
            Utils.Warn(('Config.Switches.%s is not a known group'):format(tostring(group)))
        end
    end

    for key, t in pairs(Config.Types) do
        if type(t) == 'table' then
            fix(t, 'Duration', 60, 1, S.MaxDuration)
            fix(t, 'Intensity', 0.5, 0.0, 1.0)
        else
            Utils.Warn(('Config.Types.%s must be a table'):format(tostring(key)))
        end
    end

    local B = Config.Brand
    if type(B) ~= 'table' then
        Utils.Warn('Config.Brand is missing: using the defaults')
        Config.Brand = { ServerName = 'My Server', ScriptName = 'Universal Hallucination', Colors = {} }
        B = Config.Brand
    end
    if type(B.ServerName) ~= 'string' or B.ServerName == '' then B.ServerName = 'My Server' end
    if type(B.ScriptName) ~= 'string' or B.ScriptName == '' then B.ScriptName = 'Universal Hallucination' end
    for name, value in pairs(B.Colors or {}) do
        if not Utils.IsHexColor(value) then
            Utils.Warn(('Config.Brand.Colors.%s ("%s") is not a valid HEX color like #F5C518: the default is used'):format(tostring(name), tostring(value)))
        end
    end

    if Config.General.Language ~= 'ar' and Config.General.Language ~= 'en' and not Locales[Config.General.Language] then
        Utils.Warn(('Language "%s" not found in locales/, falling back to "en"'):format(tostring(Config.General.Language)))
    end
end
