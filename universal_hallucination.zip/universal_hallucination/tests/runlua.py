#!/usr/bin/env python3
"""Tiny Lua 5.4 runner built on ctypes + liblua5.4 (no interpreter binary on this box).

usage:
  runlua.py check  file1.lua file2.lua ...      -> syntax check only
  runlua.py run    file.lua [args...]           -> run a script (print/io work)
"""
import ctypes
import sys

lib = ctypes.CDLL("liblua5.4.so.0")

lib.luaL_newstate.restype = ctypes.c_void_p
lib.luaL_openlibs.argtypes = [ctypes.c_void_p]
lib.luaL_loadfilex.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]
lib.luaL_loadfilex.restype = ctypes.c_int
lib.lua_pcallk.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p]
lib.lua_pcallk.restype = ctypes.c_int
lib.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
lib.lua_tolstring.restype = ctypes.c_char_p
lib.lua_settop.argtypes = [ctypes.c_void_p, ctypes.c_int]
lib.lua_close.argtypes = [ctypes.c_void_p]
lib.lua_createtable.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
lib.lua_pushstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
lib.lua_rawseti.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_longlong]
lib.lua_setglobal.argtypes = [ctypes.c_void_p, ctypes.c_char_p]


def new_state():
    L = lib.luaL_newstate()
    lib.luaL_openlibs(L)
    return L


def err(L):
    s = lib.lua_tolstring(L, -1, None)
    return s.decode("utf-8", "replace") if s else "?"


def check(path):
    L = new_state()
    rc = lib.luaL_loadfilex(L, path.encode(), None)
    if rc != 0:
        print(f"FAIL {path}: {err(L)}")
        lib.lua_close(L)
        return False
    print(f"ok   {path}")
    lib.lua_close(L)
    return True


def run(path, args):
    L = new_state()
    lib.lua_createtable(L, len(args), 0)
    for i, a in enumerate(args, 1):
        lib.lua_pushstring(L, a.encode())
        lib.lua_rawseti(L, -2, i)
    lib.lua_setglobal(L, b"arg")
    rc = lib.luaL_loadfilex(L, path.encode(), None)
    if rc == 0:
        rc = lib.lua_pcallk(L, 0, 0, 0, None, None)
    if rc != 0:
        print(f"LUA ERROR: {err(L)}")
        lib.lua_close(L)
        return 1
    lib.lua_close(L)
    return 0


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "check":
        okall = all([check(p) for p in sys.argv[2:]])
        sys.exit(0 if okall else 1)
    elif mode == "run":
        sys.exit(run(sys.argv[2], sys.argv[3:]))
