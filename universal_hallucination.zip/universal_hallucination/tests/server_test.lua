-- Universal Hallucination - SERVER logic test (fake FiveM, virtual clock, strict globals).
-- run:  python3 tests/runlua.py run tests/server_test.lua      (UP_ROOT=<resource folder>/ when run from elsewhere)
local ROOT = os.getenv('UP_ROOT') or './'

local vnow, vms, threads = 1900000000, 0, {}
os.time = function() return vnow end
function GetGameTimer() return vms end
function GetCurrentResourceName() return 'universal_hallucination' end
function IsDuplicityVersion() return true end
function CreateThread(fn) threads[#threads + 1] = { co = coroutine.create(fn), wake = 0 } end
function Wait(ms) coroutine.yield(ms) end
function SetTimeout(ms, fn) CreateThread(function() Wait(ms) fn() end) end

local function advance(seconds)
    local target = vnow + seconds
    while vnow < target do
        local step = math.min(1, target - vnow)
        vnow = vnow + step; vms = vms + step * 1000
        for _, t in ipairs(threads) do
            if not t.dead and vms >= t.wake then
                local ok, res = coroutine.resume(t.co)
                if not ok then error('thread error: ' .. tostring(res)) end
                if coroutine.status(t.co) == 'dead' then t.dead = true else t.wake = vms + (res or 0) end
            end
        end
    end
end

local handlers, events, sent, exported, commands = {}, {}, {}, {}, {}
local bags, aces = {}, {}
local ped, online, names = {}, {}, {}
local chat = {}
function vec3(x, y, z) return { x = x, y = y, z = z } end
function GetHashKey(s) return #s end
function GetResourceState() return 'missing' end
function RegisterNetEvent(n, fn) if fn then handlers[n] = fn end end
function AddEventHandler(n, fn) events[n] = events[n] or {}; table.insert(events[n], fn) end
function TriggerEvent(n, ...) for _, f in ipairs(events[n] or {}) do f(...) end end
function TriggerClientEvent(n, src, ...) sent[#sent + 1] = { name = n, src = src, args = { ... } } end
function GetPlayers() local l = {} for s in pairs(online) do l[#l + 1] = tostring(s) end table.sort(l) return l end
function GetPlayerName(s) return names[tonumber(s)] end
function GetPlayerPed(s) return online[tonumber(s)] and tonumber(s) + 1000 or 0 end
function GetEntityCoords(p) local d = ped[p - 1000]; return vec3(d.x, d.y, d.z) end
function GetEntityMaxHealth() return 200 end
local bucket = {}
function GetPlayerRoutingBucket(p) return bucket[p] or 0 end
function SetPlayerRoutingBucket(p, b) bucket[p] = b end
local inVeh = {}
function GetEntityHeading() return 90.0 end
function GetVehiclePedIsIn(p) return inVeh[p - 1000] and 7 or 0 end
function SetEntityCoords(p, x, y, z) local d = ped[p - 1000]; d.x, d.y, d.z = x, y, z end
function SetEntityHeading() end
function GetEntityHealth(p) return ped[p - 1000].health end
function GetPlayerIdentifierByType(s) return 'license:test' .. s end
function GetNumPlayerIdentifiers() return 0 end
function GetPlayerIdentifier() return nil end
function DropPlayer() end
function Player(s) return { state = { set = function(_, k, v) bags[s] = bags[s] or {}; bags[s][k] = v end } } end
function RegisterCommand(n, fn) commands[n] = fn end
function LoadResourceFile() return nil end
function SaveResourceFile() return true end
function PerformHttpRequest() end
function IsPlayerAceAllowed(s, ace) return aces[tonumber(s)] and aces[tonumber(s)][ace] or false end
json = { encode = function() return '{}' end, decode = function() return {} end }
exports = setmetatable({}, { __call = function(_, n, fn) exported[n] = fn end, __index = function() return setmetatable({}, { __index = function() return function() end end }) end })
function GetInvokingResource() return nil end
rawset(_G, 'Locales', {}); rawset(_G, 'LocaleMeta', {}); rawset(_G, 'Custom', {})
setmetatable(_G, { __index = function(_, k) error('undefined global "' .. tostring(k) .. '"', 2) end })

dofile(ROOT .. 'config.lua')
Config.General.Framework = 'standalone'
Config.General.PrintBanner = false
Config.General.Language = 'en'
Config.Security.KickOnAbuse = false
Config.Safety.LogToConsole = false
Config.Swap.Looks.Enabled = false
for _, f in ipairs({ 'shared/utils.lua', 'shared/locale.lua', 'locales/ar.lua', 'locales/en.lua', 'shared/registry.lua',
    'bridge/custom.lua', 'bridge/framework.lua', 'bridge/appearance_server.lua', 'bridge/inventory.lua',
    'server/security.lua', 'server/sessions.lua', 'server/scenarios.lua', 'server/director.lua', 'server/swap.lua', 'server/voice.lua',
    'server/extras.lua', 'server/takeover.lua', 'server/store.lua', 'server/world.lua', 'server/zones.lua', 'server/mind.lua', 'server/main.lua' }) do dofile(ROOT .. f) end

local pass, fail = 0, 0
local function check(c, m) if c then pass = pass + 1; print('  PASS  ' .. m) else fail = fail + 1; print('  FAIL  ' .. m) end end
local function fire(name, src, ...) _G.source = src; handlers[name](...) end
local function cmd(name, src, ...) commands[name](src, { ... }, '') end
local function lastOf(name, src)
    for i = #sent, 1, -1 do if sent[i].name == name and (src == nil or sent[i].src == src) then return sent[i] end end
end
local function countOf(name, src)
    local n = 0
    for _, e in ipairs(sent) do if e.name == name and (src == nil or e.src == src) then n = n + 1 end end
    return n
end
local function join(src, nm, admin)
    names[src] = nm; ped[src] = { x = 0, y = 0, z = 30, health = 200 }; online[src] = true
    if admin then aces[src] = { ['universal_hallucination.admin'] = true } end
    fire('universal_halluc:server:ready', src, false)
end

advance(2)
print('\n[1] boot / config sanity')
check(Framework.name == 'standalone', 'framework standalone')
check(Registry.Count() == 53, 'registry has 53 types (50 visible + 3 hidden): ' .. Registry.Count())
local missingCfg, missingLoc = {}, {}
for key in pairs(Registry.Types) do
    if not Config.Types[key] then missingCfg[#missingCfg + 1] = key end
    if Locale('type_' .. key) == 'type_' .. key then missingLoc[#missingLoc + 1] = key end
end
check(#missingCfg == 0, 'every registry type has a Config.Types entry ' .. table.concat(missingCfg, ','))
check(#missingLoc == 0, 'every type has a locale label ' .. table.concat(missingLoc, ','))
for key in pairs(Config.Cues.Items) do check(Locale('cue_' .. key) ~= 'cue_' .. key, 'cue label: ' .. key) end
check(#Scenarios.List() == 17, '17 scenarios: ' .. #Scenarios.List())
for _, s in ipairs(Scenarios.List()) do
    local sc = Config.Scenarios[s.key]
    local okSteps = true
    for _, st in ipairs(sc.Steps) do if not Registry.Has(st.Type) then okSteps = false end end
    check(okSteps, 'scenario uses only known types: ' .. s.key)
end

join(1, 'Admin', true); join(2, 'Victim'); join(3, 'Viewer'); join(4, 'Other')

print('\n[2] Hall.Start validation')
check(select(2, Hall.Start(2, 'nope')) == 'unknown_type', 'unknown type refused')
local sid = Hall.Start(2, 'heartbeat', { duration = 99999, intensity = 5 })
check(type(sid) == 'number', 'heartbeat starts')
local st = lastOf('universal_halluc:client:start', 2)
check(st and st.args[2] == 'heartbeat' and st.args[3].duration <= Config.Safety.MaxDuration and st.args[3].intensity <= 1.0, 'duration/intensity clamped')
check(bags[2] and bags[2].halluc_active == true, 'state bag set')
check(select(2, Hall.Start(2, 'hide_player', {})) == 'need_subject', 'hide_player needs a subject')
check(select(2, Hall.Start(99, 'heartbeat')) == 'player_not_found', 'offline target refused')
check(select(2, Hall.Start(2, 'ghost', { params = { model = 'evil_model' } })) == 'bad_model', 'custom model refused (AllowCustomModels = false)')
local g = Hall.Start(2, 'gunman', { params = { weapon = 'weapon_x' } })
check(Hall.Sessions[g].params.weapon == nil, 'invalid weapon pattern dropped')
Config.Types.knocking.Enabled = false
check(select(2, Hall.Start(2, 'knocking')) == 'type_disabled', 'disabled type refused')
Config.Types.knocking.Enabled = true

-- Config.Switches: type, category, scenario, cue, scene, runtime override
Config.Switches.Types.knocking = false
check(select(2, Hall.Start(2, 'knocking')) == 'type_disabled', 'Switches.Types=false refused')
check(not Registry.IsEnabled('knocking'), 'IsEnabled false via switch')
Config.Switches.Types.knocking = true
check(type(Hall.Start(2, 'knocking')) == 'number', 'switch back on works')
Hall.StopFor(2, 'x')
Config.Switches.Categories.audio = false
check(select(2, Hall.Start(2, 'heartbeat')) == 'type_disabled', 'category off disables all audio types')
check(type(Hall.Start(2, 'dizzy')) == 'number', 'other categories unaffected')
Hall.StopFor(2, 'x')
Config.Switches.Categories.audio = true
Registry.SetEnabled('dizzy', false)
check(select(2, Hall.Start(2, 'dizzy')) == 'type_disabled', 'runtime override off')
Registry.SetEnabled('dizzy', nil)
check(type(Hall.Start(2, 'dizzy')) == 'number', 'runtime override cleared')
Hall.StopFor(2, 'x')
Config.Switches.Scenarios.paranoia = false
check(select(2, Scenarios.Run(2, 'paranoia')) == 'scenario_disabled', 'scenario switched off')
local listed = false
for _, sc in ipairs(Scenarios.List()) do if sc.key == 'paranoia' then listed = true end end
check(not listed, 'disabled scenario hidden from the list')
Config.Switches.Scenarios.paranoia = true
Config.Switches.Cues.jumpscare = false
check(select(2, Cues.Fire(2, 'jumpscare')) == 'cue_disabled', 'cue switched off')
Config.Switches.Cues.jumpscare = true
Config.Switches.Scenes.present_ambush = false
check(select(2, Hall.Start(2, 'scene', { params = { scene = 'present_ambush' } })) == 'scene_disabled', 'scene switched off')
Config.Switches.Scenes.present_ambush = true
-- every Switches key must exist (typo guard)
for group, list in pairs(Config.Switches) do
    local ref = ({ Types = Registry.Types, Scenarios = Config.Scenarios, Cues = Config.Cues.Items, Scenes = Config.Scenes, Categories = { entity = 1, visual = 1, audio = 1, body = 1, people = 1 } })[group]
    check(ref ~= nil, 'Switches group known: ' .. group)
    for k in pairs(list) do check(ref and ref[k] ~= nil, 'Switches.' .. group .. '.' .. k .. ' exists') end
end
local visible = 0
for k, m in pairs(Registry.Types) do if not m.hidden then visible = visible + 1; check(Config.Switches.Types[k] ~= nil, 'every visible type has a switch: ' .. k) end end

print('\n[3] concurrency limit')
Config.Safety.MaxConcurrentPerPlayer = 3
Hall.StopFor(4, 'x')
for _ = 1, 3 do Hall.Start(4, 'tinnitus') end
check(select(2, Hall.Start(4, 'tinnitus')) == 'too_many', 'too many at once refused')
Config.Safety.MaxConcurrentPerPlayer = 8
Hall.StopFor(4, 'x')

print('\n[4] hide / solo_visible scopes')
local h = Hall.Start(3, 'hide_player', { subject = 2 })
check(type(h) == 'number' and lastOf('universal_halluc:client:start', 3).args[3].subject == 2, 'hide_player runs on the VIEWER with the subject')
local before = countOf('universal_halluc:client:start')
local so = Hall.Start(3, 'solo_visible', { subject = 2 })
check(type(so) == 'number', 'solo_visible started')
check(countOf('universal_halluc:client:start', 1) >= 1 and countOf('universal_halluc:client:start', 4) >= 1, 'solo_visible runs on everyone else')
local ranOnViewer, ranOnSubject = false, false
for i = before + 1, #sent do
    local e = sent[i]
    if e.name == 'universal_halluc:client:start' and e.args[2] == 'solo_visible' then
        if e.src == 3 then ranOnViewer = true end
        if e.src == 2 then ranOnSubject = true end
    end
end
check(not ranOnViewer and not ranOnSubject, 'solo_visible NOT sent to the viewer nor the subject')
join(5, 'Late')
check(lastOf('universal_halluc:client:start', 5) and lastOf('universal_halluc:client:start', 5).args[2] == 'solo_visible', 'late joiner receives solo_visible')

print('\n[5] opt-out')
Hall.SetOptOut(4, true)
check(select(2, Hall.Start(4, 'heartbeat', { source = 'command' })) == 'blocked_optout', 'opted-out player refused for commands')
check(type(Hall.Start(4, 'heartbeat', { source = 'script' })) == 'number', 'scripts still allowed (OptOutBlocksScripts = false)')
Hall.StopFor(4, 'x'); Hall.SetOptOut(4, false)

print('\n[6] death + expiry')
local d = Hall.Start(4, 'breathing', { duration = 5 })
advance(7)
check(Hall.Sessions[d] == nil, 'expired session removed')
check(lastOf('universal_halluc:client:stop', 4) ~= nil, 'client told to stop')
local d2 = Hall.Start(4, 'breathing', { duration = 60 })
ped[4].health = 0; advance(2)
check(Hall.Sessions[d2] == nil, 'death ends sessions (StopOnDeath)')
ped[4].health = 200
check(type(Hall.Start(4, 'breathing')) == 'number', 'after revive a new hallucination can start')
Hall.StopFor(4, 'x')
ped[4].health = 0
check(select(2, Hall.Start(4, 'breathing')) == 'blocked_dead', 'dead players are refused')
ped[4].health = 200

print('\n[7] Director')
local ds = Director.Start(1, 2, 'friend', 'player:3')
check(type(ds) == 'number', 'director session started')
local sess = Hall.Sessions[ds]
check(sess.controller == 1 and sess.subject == 3 and sess.params.source == 'subject', 'controller / subject / source set')
check(lastOf('universal_halluc:client:start', 2).args[3].controlled == true, 'client told it is controlled')
local ok = Director.Say(1, 'hello there')
check(ok == true and lastOf('universal_halluc:client:say', 2).args[2] == 'hello there', '/hsay reaches the target')
check(Director.Say(1, '   ') == false, 'empty line refused')
fire('universal_halluc:server:reply', 2, ds, 'who is it?')
check(true, 'reply handled')
fire('universal_halluc:server:reply', 4, ds, 'intruder')
check(true, 'reply from someone else ignored (no error)')
check(select(2, Director.Start(1, 2, 'distortion')) == 'unknown_type', 'only controllable types can be directed')
Hall.Stop(ds, 'x')

print('\n[8] Resist')
local rs = Hall.Start(2, 'ghost', { intensity = 0.8, duration = 300 })
Hall.Sessions[rs].nextResist = nil
fire('universal_halluc:server:resist', 2, rs, true, 100)
check(Hall.Sessions[rs].intensity == 0.8, 'too-fast result rejected (MinMs)')
fire('universal_halluc:server:resist', 2, rs, true, 4000)
check(Hall.Sessions[rs] and Hall.Sessions[rs].intensity < 0.8, 'success lowers intensity: ' .. tostring(Hall.Sessions[rs] and Hall.Sessions[rs].intensity))
check(lastOf('universal_halluc:client:update', 2) ~= nil, 'client gets the new intensity')
local after = Hall.Sessions[rs].intensity
fire('universal_halluc:server:resist', 2, rs, false, 4000)
check(Hall.Sessions[rs].intensity == after, 'cooldown blocks a second attempt')
vms = vms + 20000
fire('universal_halluc:server:resist', 2, rs, false, 4000)
check(Hall.Sessions[rs].intensity > after, 'failure raises intensity')
fire('universal_halluc:server:resist', 3, rs, true, 4000)
check(true, 'result from a non-target ignored')
Hall.Sessions[rs].intensity = 0.2; vms = vms + 20000
fire('universal_halluc:server:resist', 2, rs, true, 4000)
check(Hall.Sessions[rs] == nil, 'enough successful resisting ends the hallucination')
local hp = Hall.Start(3, 'hide_player', { subject = 2 })
vms = vms + 20000
fire('universal_halluc:server:resist', 3, hp, true, 4000)
check(Hall.Sessions[hp] ~= nil, 'excluded types cannot be resisted away')
Hall.Stop(hp)

print('\n[9] Cues + live intensity')
local n = Cues.Fire(2, 'jumpscare', { by = 1 })
check(n == 1 and lastOf('universal_halluc:client:cue', 2).args[1] == 'jumpscare', 'jumpscare cue sent')
check(select(2, Cues.Fire(2, 'nonsense')) == 'unknown_cue', 'unknown cue refused')
local ls = Hall.Start(2, 'tint', { intensity = .3 })
check(Hall.SetIntensityFor(2, 0.9) >= 1 and Hall.Sessions[ls].intensity == 0.9, 'SetIntensityFor changes live sessions')
Hall.StopFor(2, 'x')

print('\n[10] Possess')
local psid
Possess.Start(1, 2, 60, function(s, why) psid = s; check(s ~= nil, 'possess started ' .. tostring(why)) end)
check(lastOf('universal_halluc:client:possessInfo', 1) ~= nil, 'controller told to stream his camera')
fire('universal_halluc:server:possessCam', 1, psid, 10.0, 20.0, 30.0, 0.0, 0.0, 90.0, 50.0)
check(lastOf('universal_halluc:client:possessCam', 2) ~= nil, 'camera relayed to the target')
local c1 = countOf('universal_halluc:client:possessCam')
fire('universal_halluc:server:possessCam', 3, psid, 1, 1, 1, 0, 0, 0, 50)
check(countOf('universal_halluc:client:possessCam') == c1, 'camera from a non-controller ignored')
fire('universal_halluc:server:possessCam', 1, psid, 1 / 0, 1, 1, 0, 0, 0, 50)
check(countOf('universal_halluc:client:possessCam') == c1, 'non-finite camera values rejected')
Possess.Start(1, 4, 60, function(s, why) check(s == false and why == 'possess_busy', 'second possession by the same controller refused') end)
check(Possess.Stop(1, 'stopped') == true and Hall.Sessions[psid] == nil, 'possession ends')
local ap = Possess.Appear(1, 2, 30)
check(type(ap) == 'number' and Hall.Sessions[ap].subject == 1, 'appear = solo_visible with the admin as subject')
Hall.Stop(ap)

print('\n[11] commands + permissions')
join(2, 'Victim')
Hall.StopFor(2, 'x')
cmd('halluc', 2, 'me', 'tint')
check(not Hall.IsHallucinating(2), 'player without permission cannot /halluc')
local ok1 = pcall(cmd, 'halluc', 1, '3', 'bugs')
check(ok1 and Hall.IsHallucinating(3), 'admin /halluc works')
Hall.StopFor(3, 'x')
local before2 = Hall.Count()
cmd('hpossess', 2, '3')
check(Hall.Count() == before2, 'player without permission cannot /hpossess')
cmd('hcue', 2, '3', 'glitch')
local cueBefore = countOf('universal_halluc:client:cue', 3)
cmd('hcue', 2, '3', 'glitch')
check(countOf('universal_halluc:client:cue', 3) == cueBefore, 'player without permission cannot /hcue')

print('\n[12] panel security')
local r0 = #sent
fire('universal_halluc:server:panel', 2, 'start', { target = 3, type = 'heartbeat' })
local res = lastOf('universal_halluc:client:panelResult', 2)
check(res and res.args[2] == false, 'panel action without permission is refused')
fire('universal_halluc:server:panel', 1, 'start', { target = 3, type = 'heartbeat', duration = 30, intensity = 0.5 })
res = lastOf('universal_halluc:client:panelResult', 1)
check(res and res.args[2] == true, 'panel start works for an admin')
fire('universal_halluc:server:panel', 1, 'start', { target = 3, type = 'heartbeat; DROP', params = { model = 'x' } })
res = lastOf('universal_halluc:client:panelResult', 1)
check(res.args[2] == false, 'panel start with garbage type refused')
fire('universal_halluc:server:panel', 1, 'definitely_not_an_action', {})
check(true, 'unknown panel action handled (strike)')
fire('universal_halluc:server:panelOpen', 1)
local pd = lastOf('universal_halluc:client:panelData', 1)
check(pd and #pd.args[1].types == 50 and #pd.args[1].cues == 8 and pd.args[1].perms.admin == true, 'panel data: 50 types, 8 cues, perms')
fire('universal_halluc:server:panelOpen', 2)
check(lastOf('universal_halluc:client:panelData', 2) == nil, 'panel data not sent to a player without permission')

print('\n[13] rate limits + bad payloads')
local strikes = 0
for i = 1, 40 do fire('universal_halluc:server:ended', 4, 'not a number') end
check(true, 'bad payload flood handled without error')
for i = 1, 100 do fire('universal_halluc:server:resist', 4, 1, true, 5000) end
check(true, 'resist flood handled')

print('\n[14] scenarios')
local scid = Scenarios.Run(3, 'haunted', { source = 'script' })
check(scid ~= false, 'scenario starts')
advance(40)
check(Hall.IsHallucinating(3), 'scenario steps started hallucinations')
Scenarios.StopFor(3, 'x'); Hall.StopFor(3, 'x')
check(not Hall.IsHallucinating(3), 'scenario stop clears everything')

print('\n[15] player leaves')
local lv = Hall.Start(2, 'drone')
local dir = Director.Start(1, 2, 'ghost')
_G.source = 2; for _, f in ipairs(events['playerDropped'] or {}) do f() end
online[2] = nil
check(Hall.Sessions[lv] == nil, 'sessions of a leaving target removed')

print('\n[14] Realism: scenes, voice, new types')
do
    Hall.StopAllSessions('test')
    join(1, 'Admin', true); join(2, 'Victim'); join(3, 'Viewer'); join(4, 'Other')
    -- scene param is validated against Config.Scenes
    local sid1, why1 = Hall.Start(2, 'scene', { duration = 20, params = { scene = 'does_not_exist' }, source = 'script', force = true })
    check(not sid1 and why1 == 'bad_scene', 'unknown scene refused (' .. tostring(why1) .. ')')
    local sid2 = Hall.Start(2, 'scene', { duration = 20, params = { scene = 'present_ambush' }, source = 'script', force = true })
    check(type(sid2) == 'number' and lastOf('universal_halluc:client:start', 2).args[3].params.scene == 'present_ambush', 'known scene reaches the client')
    Hall.Stop(sid2, 'test')
    local sid3 = Hall.Start(2, 'gunfight', { duration = 20, params = { mode = 'crossfire' }, source = 'script', force = true })
    check(type(sid3) == 'number' and lastOf('universal_halluc:client:start', 2).args[3].params.mode == 'crossfire', 'gunfight mode passes')
    Hall.Stop(sid3, 'test')
    local sid4 = Hall.Start(2, 'gunfight', { duration = 20, params = { mode = 'drop table' }, source = 'script', force = true })
    check(type(sid4) == 'number' and lastOf('universal_halluc:client:start', 2).args[3].params.mode == nil, 'invalid gunfight mode dropped')
    Hall.Stop(sid4, 'test')
    -- every scene in the config only uses what the client understands
    local okScenes = true
    local DO = { walk = 1, face = 1, anim = 1, scenario = 1, aim = 1, shoot = 1, fall = 1, rise = 1, vanish = 1, flash = 1, shake = 1, sound = 1, cue = 1, blood = 1 }
    for name, sc in pairs(Config.Scenes) do
        if sc.Mode ~= 'past' and sc.Mode ~= 'present' then okScenes = false end
        for _, a in ipairs(sc.Actors or {}) do
            for _, st in ipairs(a.Timeline or {}) do if not DO[st.Do] then okScenes = false end end
            if a.Weapon and not tostring(a.Weapon):match('^WEAPON_[%u%d_]+$') then okScenes = false end
        end
        for _, ev in ipairs(sc.Events or {}) do if not DO[ev.Do] then okScenes = false end end
    end
    check(okScenes, 'every scene in Config.Scenes is well formed')

    -- voice: private call, custom provider
    local linked, unlinked = {}, {}
    Custom.Voice = { Link = function(c, t, ch) linked[#linked + 1] = { c, t, ch } end, Unlink = function(c, t, ch) unlinked[#unlinked + 1] = { c, t, ch } end }
    Config.Voice.Enabled = false
    check(Voice.Link('k1', 1, { 2 }) == nil, 'voice disabled: nothing linked')
    Config.Voice.Enabled = true; Config.Voice.Provider = 'custom'
    local ch = Voice.Link('k1', 1, { 2, 1, 3 })
    check(ch ~= nil and #linked == 2 and linked[1][1] == 1, 'voice linked to every target except the controller')
    check(Voice.Unlink('k1') == true and #unlinked == 2, 'voice unlinked')
    check(Voice.Unlink('k1') == false, 'unlinking twice is harmless')
    -- director voice
    Config.Voice.Use.Director = true
    local dsid = Director.Start(1, 2, 'friend')
    check(type(dsid) == 'number' and Voice.IsLinked('s' .. dsid), 'director session links the voice')
    Hall.Stop(dsid, 'test')
    check(not Voice.IsLinked('s' .. dsid), 'voice released when the session ends')
    -- appear: private call with the admin
    local asid = Possess.Appear(1, 2, 30)
    check(type(asid) == 'number' and Voice.IsLinked('a' .. asid), 'appear links the voice')
    Hall.Stop(asid, 'test')
    check(not Voice.IsLinked('a' .. asid), 'appear voice released')
    -- possess: speak as
    Config.Voice.Use.Possess = 'speak_as'
    local psid2
    Possess.Start(1, 2, 60, function(s) psid2 = s end)
    local va = lastOf('universal_halluc:client:voiceAs', 1)
    check(va and va.args[1] == 2, 'possessing makes the controller heard around the target')
    Possess.Stop(1, 'stopped')
    local va2 = lastOf('universal_halluc:client:voiceAs', 1)
    check(va2 and va2.args[1] == nil, 'speak-as released at the end')
    Voice.Release(1)
    Config.Voice.Enabled = false
    cmd('hscene', 1, 'me', 'nope')
    check(true, 'bad /hscene does not crash')
end


print('\n[16] Takeover (swap by duel)')
do
    Hall.StopAllSessions('test')
    for _, n in ipairs({ 1, 2, 3, 4 }) do if not online[n] then join(n, 'P' .. n, n == 1) end end
    advance(30)
    ped[1].x, ped[1].y, ped[1].z = 0, 0, 30
    ped[2].x, ped[2].y, ped[2].z = 10, 0, 30
    Config.Takeover.RequireLooks = true
    local ok, why = Takeover.Talk(1, 2)
    check(ok == false and why == 'takeover_need_looks', 'refused without a clothing provider')
    Config.Takeover.RequireLooks = false
    ped[3].x = 500
    ok, why = Takeover.Talk(1, 3)
    check(ok == false and why == 'takeover_far', 'too far refused')
    inVeh[2] = true
    ok, why = Takeover.Talk(1, 2)
    check(ok == false and why == 'takeover_vehicle', 'vehicle refused')
    inVeh[2] = nil
    check(Takeover.Seize(1) == false, 'seize without talking first refused')

    -- target wins -> the controller is expelled
    check(Takeover.Talk(1, 2) == true, 'talk phase starts')
    check(Takeover.IsActive(1) and Takeover.IsActive(2), 'both marked busy')
    check(select(1, Takeover.Talk(1, 4)) == false, 'controller cannot start a second takeover')
    check(Takeover.Seize(1) == true, 'duel starts')
    local csid
    for sid, s in pairs(Hall.Sessions) do if s.type == 'takeover' then csid = sid end end
    check(csid ~= nil, 'duel session exists on the target')
    fire('universal_halluc:server:resist', 2, csid, true, 100)
    check(Hall.Sessions[csid] ~= nil, 'too-fast round ignored')
    advance(2)
    fire('universal_halluc:server:resist', 2, csid, true, 4000)
    check(Hall.Sessions[csid] ~= nil, 'one win is not enough')
    advance(2)
    fire('universal_halluc:server:resist', 2, csid, true, 4000)
    check(Hall.Sessions[csid] == nil, 'second win ends the duel')
    check(not Takeover.IsActive(1) and not Takeover.IsActive(2), 'state cleared after the target wins')
    local left = false
    for _, s in pairs(Hall.Sessions) do if s.type == 'solo_visible' then left = true end end
    check(not left, 'the controller vanished (appear session stopped)')

    -- target loses -> swap
    ped[1].x, ped[1].y = 0, 0; ped[2].x, ped[2].y = 10, 0
    advance(3)
    check(Takeover.Talk(1, 2) == true and Takeover.Seize(1) == true, 'second duel')
    for sid, s in pairs(Hall.Sessions) do if s.type == 'takeover' then csid = sid end end
    advance(2)
    fire('universal_halluc:server:resist', 2, csid, false, 4000)
    check(Hall.Sessions[csid] == nil, 'a lost round ends the duel')
    local ghost, solo
    for sid, s in pairs(Hall.Sessions) do
        if s.type == 'takeover_ghost' then ghost = sid end
        if s.type == 'solo_visible' then solo = sid end
    end
    check(ghost ~= nil and solo ~= nil, 'ghost + solo-visible sessions started')
    check(ped[1].x == 10 and ped[2].x == 0, 'places swapped')
    local iso = lastOf('universal_halluc:client:voiceIsolate', 2)
    check(iso and iso.args[1] == 1, 'target voice isolated to the controller')
    check(Hall.Sessions[ghost].targets[2] ~= nil, 'ghost session runs on the target')
    Takeover.Stop(1, 'released')
    check(Hall.Sessions[ghost] == nil and Hall.Sessions[solo] == nil, 'release stops both sessions')
    check(ped[1].x == 0, 'controller returned to his old place')
    iso = lastOf('universal_halluc:client:voiceIsolate', 2)
    check(iso and iso.args[1] == nil, 'voice isolation removed')
    check(not Takeover.IsActive(1), 'state cleared after release')

    -- duel timeout = loss ; disconnect during the swap
    advance(3)
    ped[1].x, ped[2].x = 0, 10
    check(Takeover.Talk(1, 2) == true and Takeover.Seize(1) == true, 'third duel')
    advance(Config.Takeover.Contest.Seconds + 3)
    ghost = nil
    for sid, s in pairs(Hall.Sessions) do if s.type == 'takeover_ghost' then ghost = sid end end
    check(ghost ~= nil, 'the duel timeout counts as a loss')
    _G.source = 1; events['playerDropped'][#events['playerDropped']](); online[1] = nil
    check(not Takeover.IsActive(2) and not next(Hall.Sessions), 'controller leaving ends everything')
    join(1, 'Admin', true)
    advance(2)
end


print('\n[17] Every scenario starts all of its steps')
do
    Hall.StopAllSessions('test')
    advance(60)
    local realStart = Hall.Start
    local fails = {}
    for _, sc in ipairs(Scenarios.List()) do
        local def = Config.Scenarios[sc.key]
        local started, wanted = 0, 0
        local current = sc.key
        Hall.Start = function(t, ty, o)
            local sid, why = realStart(t, ty, o)
            if o and o.scenario == current then
                if sid then started = started + 1 else fails[#fails + 1] = ('%s: %s -> %s'):format(current, ty, tostring(why)) end
            end
            return sid, why
        end
        for _, st in ipairs(def.Steps or {}) do
            if not st.Chance then
                local times = (type(st.Repeat) == 'table' and st.Repeat.Times or 0) + 1
                wanted = wanted + times
            end
        end
        Scenarios.Run(2, sc.key, { source = 'command', by = 1, force = true })
        advance((def.Duration or 60) + 5)
        Hall.StopAllSessions('test')
        Hall.Start = realStart
        check(started >= wanted, ('scenario %s started %d/%d steps'):format(sc.key, started, wanted))
    end
    for _, f in ipairs(fails) do print('   skipped: ' .. f) end
end


print('\n[18] Parallel world + saved places + user scenes')
do
    Hall.StopAllSessions('test')
    for _, n in ipairs({ 1, 2, 3, 4 }) do if not online[n] then join(n, 'P' .. n, n == 1) end end
    advance(60)
    Config.World.Fade = false
    ped[1].x, ped[1].y, ped[1].z = 0, 0, 30
    ped[2].x, ped[2].y, ped[2].z = 10, 0, 30
    ped[3].x, ped[3].y, ped[3].z = -20, 5, 30

    -- places saved from the panel are validated and persisted
    check(select(1, Store.SavePlace(1, '', 1, 2, 3, 0)) == false, 'empty place name refused')
    local ok, key = Store.SavePlace(1, 'My <b>base</b>', 111.0, 222.0, 33.0, 90.0)
    check(ok and Store.FindPlace(key) and Store.FindPlace(key).user, 'place saved and found')
    check(not Store.FindPlace(key).label:find('<'), 'place name is sanitised')
    check(Store.DeletePlace(key) and not Store.FindPlace(key), 'place deleted')

    check(select(2, World.Send(1, 2, 'nope')) == 'world_no_place', 'unknown place refused')
    check(select(2, World.Send(1, 1, 'cemetery')) == 'player_not_found', 'cannot send yourself')
    inVeh[2] = true
    check(select(2, World.Send(1, 2, 'cemetery')) == 'world_vehicle', 'target in a vehicle refused')
    inVeh[2] = nil

    local place = Store.FindPlace('cemetery')
    Config.World.StaffOnly = false
    local okSend, why = World.Send(1, 2, 'cemetery', { staff = { 3 }, seconds = 120, bucket = true, join = true })
    check(okSend == true, 'world started ' .. tostring(why))
    advance(3)
    check(math.abs(ped[2].x - place.x) < 0.01, 'target moved to the place')
    check(bucket[2] ~= nil and bucket[2] >= Config.World.BucketBase, 'target in his own bucket')
    check(bucket[1] == bucket[2], 'controller joined the same bucket')
    check(math.abs(ped[3].x - place.x) <= 2.01 and bucket[3] == bucket[2], 'staff placed next to him in the same bucket')
    check(bucket[4] == nil, 'a non-staff player (id 4) was not brought')
    local frozen
    for _, s2 in pairs(Hall.Sessions) do if s2.type == 'world_frozen' then frozen = s2.sid end end
    check(frozen ~= nil, 'target frozen session exists')
    check(World.IsActive(2) and World.IsActive(1) and not World.IsActive(4), 'busy flags')
    check(select(2, World.Send(1, 4, 'cemetery')) == 'world_busy', 'second world for the same controller refused')
    check(select(2, Takeover.Talk(4, 2)) == 'world_busy', 'takeover on a world target refused')
    check(#World.List() == 1 and World.List()[1].target == 2, 'world listed for the panel')

    Config.World.StaffOnly = true
    World.Return(1, 'returned')
    advance(3)
    check(ped[2].x == 10 and bucket[2] == 0, 'target back at his old place and bucket')
    check(ped[1].x == 0 and bucket[1] == 0, 'controller back at his old place')
    check(not World.IsActive(2) and not next(Hall.Sessions), 'everything cleaned after the return')

    -- timeout and disconnect
    ped[1].x, ped[2].x = 0, 10
    World.Send(1, 2, 'cemetery', { staff = {}, seconds = 12, bucket = false })
    advance(3)
    advance(14)
    check(not World.IsActive(2) and ped[2].x == 10, 'timeout returns everybody')
    World.Send(1, 2, 'cemetery', { staff = {}, seconds = 300, bucket = false })
    advance(3)
    _G.source = 2; events['playerDropped'][#events['playerDropped']](); online[2] = nil
    advance(3)
    check(not World.IsActive(1) and ped[1].x == 0, 'target leaving returns the staff')
    join(2, 'Victim'); advance(2)

    -- user scenes: sanitised, merged and refused when built-in
    local good = Store.SanitizeScene({ Label = 'x', Duration = 9999, Actors = { { Id = 'a b', Model = 'bad model!', At = { fwd = 999, right = -999 }, Timeline = { { t = 1, Do = 'rm -rf' }, { t = 2, Do = 'walk', to = { fwd = 3 } } }, Lines = { { t = 1, text = 'hi<script>' } } } }, Events = { { t = 1, Do = 'flash' }, { Do = 'evil' } } })
    check(good ~= nil and good.Duration <= 300, 'scene duration clamped')
    check(good.Actors[1].At.fwd == 60.0 and good.Actors[1].At.right == -60.0, 'actor offsets clamped')
    check(#good.Actors[1].Timeline == 1 and #good.Events == 1, 'unknown actions dropped')
    check(not good.Actors[1].Lines[1].text.ar:find('<'), 'text sanitised')
    check(select(1, Store.SanitizeScene({ Actors = {} })) == nil, 'scene without actors refused')
    check(Store.SaveScene('memory_family_table', good) == false, 'built-in scene cannot be overwritten')
    check(Store.SaveScene('my_test_scene', good) == true and Config.Scenes.my_test_scene ~= nil, 'user scene saved and merged')
    Hall.StopAllSessions('test'); advance(30)
    local sid = Hall.Start(2, 'scene', { duration = 20, params = { scene = 'my_test_scene' }, source = 'command', by = 1, force = true })
    check(sid ~= nil, 'user scene can be started')
    Hall.StopAllSessions('test')
    check(Store.DeleteScene('my_test_scene') and Config.Scenes.my_test_scene == nil, 'user scene deleted')
end


print('\n[19] Haunted zones + mind (stress)')
do
    Hall.StopAllSessions('test'); advance(60)
    for _, n in ipairs({ 1, 2, 3 }) do if not online[n] then join(n, 'P' .. n, n == 1) end end
    ped[2].x, ped[2].y, ped[2].z = 500, 500, 30
    ped[3].x, ped[3].y, ped[3].z = -900, -900, 30
    check(Store.SanitizeZone({ key = 'z', x = 1, y = 2, z = 3, type = 'takeover' }) == nil, 'hidden types cannot be used in a zone')
    check(Store.SanitizeZone({ key = 'z', x = 1, y = 2, z = 3, type = 'nope' }) == nil, 'unknown types refused')
    local z = Store.SanitizeZone({ key = 'z1', x = 500, y = 500, z = 30, type = 'ghost', radius = 99999, chance = 9, cooldown = 1, intensity = 5 })
    check(z and z.radius == 500.0 and z.chance == 1.0 and z.cooldown == 10.0 and z.intensity == 1.0, 'zone values clamped')
    check(Store.SaveZone({ key = 'z1', label = 'Old house', x = 500, y = 500, z = 30, type = 'ghost', radius = 20, chance = 1.0, cooldown = 60, duration = 30 }) == true, 'zone saved')
    check(#Zones.Inside(2) == 1 and #Zones.Inside(3) == 0, 'only the player inside is detected')
    Zones.Tick()
    local got = #Hall.GetActive(2)
    check(got >= 1 and #Hall.GetActive(3) == 0, 'entering the zone starts a hallucination')
    Hall.StopFor(2, 'test'); Zones.Tick()
    check(#Hall.GetActive(2) == 0, 'the cooldown prevents an immediate repeat')
    advance(70); Zones.Tick()
    check(#Hall.GetActive(2) >= 1, 'it fires again after the cooldown')
    Hall.StopAllSessions('test')
    Store.zones[1].enabled = false; advance(70); Zones.Tick()
    check(#Hall.GetActive(2) == 0, 'a disabled zone does nothing')
    check(Store.DeleteZone('z1') and #Store.zones == 0, 'zone deleted')

    -- mind
    advance(40)
    check(Mind.Get(2) == 0, 'new player starts calm')
    Mind.Add(2, 150)
    check(Mind.Get(2) == Config.Mind.Max, 'stress is capped')
    Mind.Set(2, 10); Mind.Add(2, -50)
    check(Mind.Get(2) == 0, 'stress never goes below zero')
    Mind.Set(2, 90)
    for _, lv in ipairs(Config.Mind.Levels) do lv.chance = 1.0 end
    Mind.Tick()
    check(#Hall.GetActive(2) >= 1, 'high stress starts an automatic hallucination')
    Hall.StopAllSessions('test')
    Mind.Set(3, 5)
    Mind.Tick()
    check(#Hall.GetActive(3) == 0, 'low stress stays calm')
    ped[3].health = 0
    Mind.Set(3, 0)
    Mind.Tick()
    check(Mind.Get(3) >= Config.Mind.Gain.Death - 0.01, 'dying raises stress')
    ped[3].health = 200
    Mind.Set(2, 42)
    Mind.OnDrop(2)
    local saved
    for _, v in pairs(Store.mind) do if math.abs(v.v - 42) < 0.5 then saved = true end end
    check(saved, 'stress persisted on leaving')
    join(2, 'Victim'); advance(2)
    check(Mind.Get(2) > 30, 'stress restored when the character returns')
    for _, lv in ipairs(Config.Mind.Levels) do lv.chance = 0.05 end
end

print(('\n==== %d passed, %d failed ===='):format(pass, fail))
if fail > 0 then error('tests failed') end
