--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/director.lua - live puppeting of an imaginary person (SERVER).

    A "controller" (a player with the Director permission, a psychologist, an event host...) starts a controlled
    session on a target. What the controller writes with /hsay is shown to the target as the person speaking
    (subtitle + bubble over the phantom). The target answers with /hr <text> and the controller reads it.
    Optionally the two can also talk by voice (Config.Director.Voice).
]]

Director = {}

local function tell(src, key, ...)
    if src == 0 then
        print(('[universal_hallucination] %s'):format(Locale(key, ...)))
    else
        TriggerClientEvent('universal_halluc:client:notify', src, key, 'inform', nil, ...)
    end
end

local function chat(src, text)
    if src == 0 then
        print(('[universal_hallucination] %s'):format(text))
    else
        TriggerClientEvent('chat:addMessage', src, { args = { Config.Brand.ScriptName, text } })
    end
end
Director.Chat = chat

-- ----------------------------------------------------------------------
-- Voice link (optional)
-- ----------------------------------------------------------------------
local function voiceLink(s)
    if not (Config.Voice and Config.Voice.Use and Config.Voice.Use.Director and s.controller) then return end
    local targets = {}
    for t in pairs(s.targets) do targets[#targets + 1] = t end
    s.voiceChannel = Voice.Link('s' .. s.sid, s.controller, targets)
end

local function voiceUnlink(s)
    if s.voiceChannel then Voice.Unlink('s' .. s.sid) end
    s.voiceChannel = nil
end

-- ----------------------------------------------------------------------
-- API
-- ----------------------------------------------------------------------
--- /hdirect: the controller takes control of a new imaginary person on the target.
---@param spec? string  nil | 'player:<id>' | '<model>'
---@return number|false sid, string? reason, string? extra
function Director.Start(controller, target, typeKey, spec, opts)
    opts = opts or {}
    if not Config.Director.Enabled then return false, 'director_disabled' end
    typeKey = typeKey or 'friend'
    local meta = Registry.Types[typeKey]
    if not meta or not meta.controllable then return false, 'unknown_type', tostring(typeKey) end

    -- one controlled session per controller
    local old = Hall.FindByController(controller)
    if old then Hall.Stop(old.sid, 'replaced') end

    local params, subject = {}, nil
    if type(spec) == 'string' and spec ~= '' then
        local pid = spec:match('^player:(%d+)$')
        if pid then
            subject = tonumber(pid)
            params.source = 'subject'
        else
            params.model = spec
            params.source = 'model'
        end
    end

    local sid, reason, extra = Hall.Start(target, typeKey, {
        controller = controller, subject = subject, params = params,
        duration = opts.duration, intensity = opts.intensity,
        source = 'director', by = controller,
    })
    if not sid then return false, reason, extra end

    local s = Hall.Sessions[sid]
    voiceLink(s)
    return sid
end

--- /hsay: the controller speaks through the phantom.
function Director.Say(controller, text)
    local s = Hall.FindByController(controller)
    if not s then return false, 'director_none' end
    text = Utils.CleanText(text, Config.Director.MaxLineLength)
    if not text then return false, 'invalid' end
    for t in pairs(s.targets) do
        TriggerClientEvent('universal_halluc:client:say', t, s.sid, text, Config.Director.LineSeconds)
    end
    return true, text
end

--- Target answered with /hr <text> (or the client reports a free reply).
function Director.OnReply(src, sid, text)
    local s = Hall.Sessions[sid]
    if not s or not s.targets[src] then return false end
    text = Utils.CleanText(text, Config.Director.ReplyMaxLength)
    if not text then return false end
    if s.controller and Hall.IsOnline(s.controller) then
        chat(s.controller, Locale('reply_from', src, text))
    end
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:replied', src, sid, text) end
    return true, text
end

--- A choice made in a scripted dialogue (reported by the client; validated against the config).
function Director.OnChoice(src, sid, dialogueId, nodeId, index)
    local s = Hall.Sessions[sid]
    if not s or not s.targets[src] then return false end
    local d = Config.Dialogues[dialogueId]
    local node = d and d.Nodes and d.Nodes[nodeId]
    if not node or type(node.Choices) ~= 'table' or not node.Choices[index] then return false end
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:choice', src, sid, dialogueId, nodeId, index) end
    return true
end

--- Called by Hall when a session ends.
function Director.OnSessionEnd(s, reason)
    if not s.controller then return end
    voiceUnlink(s)
    if Hall.IsOnline(s.controller) then
        TriggerClientEvent('universal_halluc:client:notify', s.controller, 'director_ended', 'inform')
    end
end
