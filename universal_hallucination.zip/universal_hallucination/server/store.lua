--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/store.lua - data created from the panel (places and scenes), saved in data/user_data.json.

    Everything a client sends is sanitised here: lengths, characters, numbers and the allowed actions.
    User scenes are merged into Config.Scenes (flagged `User = true`) and broadcast to every client.
]]

Store = { places = {}, scenes = {}, zones = {}, mind = {} }

local FILE = 'data/user_data.json'
local loaded = false

local DO_ACTOR = { walk = true, face = true, anim = true, scenario = true, aim = true, shoot = true, fall = true, rise = true, vanish = true }
local DO_EVENT = { flash = true, shake = true, sound = true, cue = true, blood = true }

local function num(v, def, lo, hi) return Utils.Num(v, def, lo, hi) end
local function word(v, max) -- identifiers: letters, digits, _ . @ - only
    if type(v) ~= 'string' then return nil end
    v = v:sub(1, max or 64)
    if v == '' or v:find('[^%w_%.@%-]') then return nil end
    return v
end
local function text(v, max)
    local function one(s) s = tostring(s or ''):gsub('[%c<>]', ' '):sub(1, max or 120) return s end
    if type(v) == 'table' then return { ar = one(v.ar or v.en), en = one(v.en or v.ar) } end
    local s = one(v)
    return { ar = s, en = s }
end
local function color(v, def)
    if type(v) == 'string' and v:match('^#%x%x%x%x%x%x$') then return v end
    return def
end

local function at(t)
    t = type(t) == 'table' and t or {}
    return { fwd = num(t.fwd, 0.0, -60.0, 60.0), right = num(t.right, 0.0, -60.0, 60.0), up = num(t.up, 0.0, -5.0, 10.0) }
end

local function step(st, isEvent)
    if type(st) ~= 'table' then return nil end
    local d = st.Do
    if isEvent then if not DO_EVENT[d] then return nil end
    elseif not DO_ACTOR[d] then return nil end
    local o = { t = num(st.t, 0.0, 0.0, 600.0), Do = d }
    if st.to then o.to = at(st.to) end
    o.speed = st.speed and num(st.speed, 1.0, 0.2, 3.0) or nil
    o.shots = st.shots and math.floor(num(st.shots, 3, 1, 12)) or nil
    o.gap = st.gap and num(st.gap, 300, 60, 2000) or nil
    if st.at ~= nil then o.at = (st.at == 'me') and 'me' or word(st.at, 16) end
    o.dict = word(st.dict, 64); o.name = word(st.name, 64); o.flag = st.flag and math.floor(num(st.flag, 1, 0, 1000)) or nil
    o.color = color(st.color); o.amount = st.amount and num(st.amount, 0.3, 0.0, 1.0) or nil
    o.volume = st.volume and num(st.volume, 0.8, 0.0, 1.0) or nil
    o.seconds = st.seconds and num(st.seconds, 4.0, 1.0, 30.0) or nil
    return o
end

--- Returns a clean scene or nil + reason.
function Store.SanitizeScene(def)
    if type(def) ~= 'table' then return nil, 'invalid' end
    local out = { Label = text(def.Label, 60), Mode = (def.Mode == 'present') and 'present' or 'past',
                  Duration = num(def.Duration, 30.0, 5.0, 300.0), User = true, Actors = {}, Events = {} }
    local L = type(def.Look) == 'table' and def.Look or {}
    out.Look = {
        Timecycle = word(L.Timecycle, 48), Strength = num(L.Strength, 0.6, 0.0, 1.0),
        Tint = color(L.Tint), TintStrength = num(L.TintStrength, 0.2, 0.0, 1.0), Grain = L.Grain == true,
        Weather = word(L.Weather, 24), Sound = word(L.Sound, 32), SoundVolume = num(L.SoundVolume, 0.4, 0.0, 1.0),
    }
    if type(L.Clock) == 'table' and tonumber(L.Clock.h) then out.Look.Clock = { h = math.floor(num(L.Clock.h, 12, 0, 23)), m = math.floor(num(L.Clock.m, 0, 0, 59)) } end
    local used = {}
    for i, a in ipairs(type(def.Actors) == 'table' and def.Actors or {}) do
        if i > 12 then break end
        if type(a) == 'table' then
            local id = word(a.Id, 16) or ('a' .. i)
            if used[id] then id = id .. i end
            used[id] = true
            local actor = { Id = id, Name = a.Name and text(a.Name, 40) or nil, At = at(a.At),
                Heading = (a.Heading == nil or a.Heading == 'face') and 'face' or num(a.Heading, 0.0, -360.0, 360.0),
                Model = (a.Model == 'self' or a.Model == 'subject') and a.Model or (word(a.Model, 48) or 'a_m_y_hipster_01'),
                Scenario = word(a.Scenario, 64), Weapon = word(a.Weapon, 40), LookAtMe = a.LookAtMe ~= false,
                Alpha = a.Alpha and num(a.Alpha, 255, 0, 255) or nil, Lines = {}, Timeline = {} }
            if type(a.Anim) == 'table' and word(a.Anim.dict, 64) and word(a.Anim.name, 64) then
                actor.Anim = { dict = a.Anim.dict, name = a.Anim.name, flag = math.floor(num(a.Anim.flag, 1, 0, 1000)) }
            end
            for j, ln in ipairs(type(a.Lines) == 'table' and a.Lines or {}) do
                if j > 20 then break end
                if type(ln) == 'table' then actor.Lines[#actor.Lines + 1] = { t = num(ln.t, 0.0, 0.0, 600.0), text = text(ln.text, 160) } end
            end
            for j, st in ipairs(type(a.Timeline) == 'table' and a.Timeline or {}) do
                if j > 40 then break end
                local s = step(st, false)
                if s then actor.Timeline[#actor.Timeline + 1] = s end
            end
            out.Actors[#out.Actors + 1] = actor
        end
    end
    if #out.Actors == 0 then return nil, 'scene_no_actors' end
    for j, ev in ipairs(type(def.Events) == 'table' and def.Events or {}) do
        if j > 20 then break end
        local s = step(ev, true)
        if s then out.Events[#out.Events + 1] = s end
    end
    return out
end

local function readJson()
    local raw = LoadResourceFile(GetCurrentResourceName(), FILE)
    if not raw or raw == '' then return {} end
    local ok, data = pcall(json.decode, raw)
    return (ok and type(data) == 'table') and data or {}
end

local function persist()
    local scenes = {}
    for k, v in pairs(Store.scenes) do scenes[k] = v end
    local ok, enc = pcall(json.encode, { places = Store.places, scenes = scenes, zones = Store.zones, mind = Store.mind })
    if ok then SaveResourceFile(GetCurrentResourceName(), FILE, enc, -1) else Utils.Warn('Could not write ' .. FILE) end
end

local function mergeScenes()
    for k, v in pairs(Config.Scenes) do if type(v) == 'table' and v.User then Config.Scenes[k] = nil end end
    for k, v in pairs(Store.scenes) do Config.Scenes[k] = v end
end

function Store.Load()
    local d = readJson()
    Store.places, Store.scenes = {}, {}
    for _, p in ipairs(type(d.places) == 'table' and d.places or {}) do
        local key = word(p.key, 32)
        if key and tonumber(p.x) and tonumber(p.y) and tonumber(p.z) then
            Store.places[#Store.places + 1] = { key = key, label = text(p.label, 40), x = p.x + 0.0, y = p.y + 0.0, z = p.z + 0.0, h = num(p.h, 0.0, -360.0, 360.0), user = true }
        end
    end
    for k, v in pairs(type(d.scenes) == 'table' and d.scenes or {}) do
        local key = word(k, 32)
        local clean = key and Store.SanitizeScene(v)
        if clean then Store.scenes[key] = clean end
    end
    Store.zones, Store.mind = {}, {}
    for _, z in ipairs(type(d.zones) == 'table' and d.zones or {}) do
        local clean = Store.SanitizeZone(z)
        if clean then Store.zones[#Store.zones + 1] = clean end
    end
    for k, v in pairs(type(d.mind) == 'table' and d.mind or {}) do
        if type(k) == 'string' and #k <= 80 and type(v) == 'table' then Store.mind[k] = { v = num(v.v, 0.0, 0.0, 1000.0), t = tonumber(v.t) or 0 } end
    end
    mergeScenes()
    loaded = true
end

function Store.IsLoaded() return loaded end

-- ---------------------------------------------------------------- places
function Store.Places()
    local list = {}
    for _, p in ipairs(Config.Places or {}) do
        list[#list + 1] = { key = p.key, label = Utils.Text(p.label) ~= '' and Utils.Text(p.label) or p.key, x = p.x, y = p.y, z = p.z, h = p.h or 0.0, user = false }
    end
    for _, p in ipairs(Store.places) do
        list[#list + 1] = { key = p.key, label = Utils.Text(p.label) ~= '' and Utils.Text(p.label) or p.key, x = p.x, y = p.y, z = p.z, h = p.h, user = true }
    end
    return list
end

function Store.FindPlace(key)
    for _, p in ipairs(Store.Places()) do if p.key == key then return p end end
    return nil
end

--- Saves the position of a player as a named place.
function Store.SavePlace(src, name, x, y, z, h)
    name = tostring(name or ''):gsub('[%c<>]', ' '):sub(1, 40)
    if name == '' then return false, 'invalid' end
    if #Store.places >= 60 then return false, 'store_full' end
    local base = name:lower():gsub('[^%w]+', '_'):sub(1, 20)
    if base == '' or base == '_' then base = 'place' end
    local key, n = 'u_' .. base, 1
    while Store.FindPlace(key) do n = n + 1 key = ('u_%s_%d'):format(base, n) end
    Store.places[#Store.places + 1] = { key = key, label = { ar = name, en = name }, x = x + 0.0, y = y + 0.0, z = z + 0.0, h = h or 0.0, user = true }
    persist()
    return true, key
end

function Store.DeletePlace(key)
    for i, p in ipairs(Store.places) do
        if p.key == key then table.remove(Store.places, i) persist() return true end
    end
    return false
end

-- ---------------------------------------------------------------- scenes
function Store.SaveScene(key, def)
    key = word(key, 32)
    if not key then return false, 'invalid' end
    if Config.Scenes[key] and not Config.Scenes[key].User then return false, 'scene_builtin' end
    local clean, why = Store.SanitizeScene(def)
    if not clean then return false, why end
    local n = 0
    for _ in pairs(Store.scenes) do n = n + 1 end
    if not Store.scenes[key] and n >= 60 then return false, 'store_full' end
    Store.scenes[key] = clean
    Config.Scenes[key] = clean
    persist()
    Store.Broadcast()
    return true, key
end

function Store.DeleteScene(key)
    if not Store.scenes[key] then return false end
    Store.scenes[key] = nil
    Config.Scenes[key] = nil
    persist()
    Store.Broadcast()
    return true
end

function Store.Broadcast(src)
    TriggerClientEvent('universal_halluc:client:userScenes', src or -1, Store.scenes)
end

-- ---------------------------------------------------------------- zones
function Store.SanitizeZone(z)
    if type(z) ~= 'table' then return nil end
    local key = word(z.key, 32)
    if not key or not tonumber(z.x) or not tonumber(z.y) or not tonumber(z.z) then return nil end
    local ty = type(z.type) == 'string' and z.type or ''
    if not Registry.Has(ty) or (Registry.Types[ty] or {}).hidden or (Registry.Types[ty] or {}).needsSubject then return nil end
    return { key = key, label = text(z.label, 40), x = z.x + 0.0, y = z.y + 0.0, z = z.z + 0.0,
        radius = num(z.radius, 25.0, 3.0, 500.0), type = ty, intensity = num(z.intensity, 0.6, 0.05, 1.0),
        duration = num(z.duration, 60.0, 5.0, 600.0), chance = num(z.chance, 0.35, 0.0, 1.0), cooldown = num(z.cooldown, 180.0, 10.0, 7200.0),
        enabled = z.enabled ~= false }
end

function Store.SaveZone(def)
    local clean = Store.SanitizeZone(def)
    if not clean then return false, 'invalid' end
    for i, z in ipairs(Store.zones) do
        if z.key == clean.key then Store.zones[i] = clean persist() return true, clean.key end
    end
    if #Store.zones >= math.floor(num(Config.Zones.MaxZones, 40, 1, 100)) then return false, 'store_full' end
    Store.zones[#Store.zones + 1] = clean
    persist()
    return true, clean.key
end

function Store.NewZoneKey(name)
    local base = tostring(name or ''):lower():gsub('[^%w]+', '_'):sub(1, 20)
    if base == '' or base == '_' then base = 'zone' end
    local key, n = 'z_' .. base, 1
    local function used(k) for _, z in ipairs(Store.zones) do if z.key == k then return true end end return false end
    while used(key) do n = n + 1 key = ('z_%s_%d'):format(base, n) end
    return key
end

function Store.DeleteZone(key)
    for i, z in ipairs(Store.zones) do
        if z.key == key then table.remove(Store.zones, i) persist() return true end
    end
    return false
end

function Store.Save() persist() end
