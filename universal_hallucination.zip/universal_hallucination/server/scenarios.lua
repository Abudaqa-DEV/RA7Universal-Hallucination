--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/scenarios.lua - roleplay scenarios: a timeline of hallucinations (SERVER).

    The timeline lives on the server: every step is a normal Hall.Start (so every safety rule applies) and
    stopping the scenario cancels the pending steps and stops the sessions it started.
]]

Scenarios = {}

local Runs = {}        -- [runId] = { id, target, name, sids = {}, cancelled, endsAt }
local byTarget = {}    -- [src] = runId
local nextRun = 0

local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end

function Scenarios.Exists(name)
    return type(name) == 'string' and type(Config.Scenarios[name]) == 'table'
end

--- exists AND is not switched off in Config.Switches.Scenarios
function Scenarios.Enabled(name)
    return Scenarios.Exists(name) and Registry.SwitchOn('Scenarios', name)
end

function Scenarios.List()
    local l = {}
    for k, v in pairs(Config.Scenarios) do
        if type(v) == 'table' and Registry.SwitchOn('Scenarios', k) then l[#l + 1] = { key = k, label = Utils.Text(v.Label), duration = v.Duration } end
    end
    table.sort(l, function(a, b) return a.key < b.key end)
    return l
end

local function finish(run, reason)
    if not Runs[run.id] then return end
    Runs[run.id] = nil
    if byTarget[run.target] == run.id then byTarget[run.target] = nil end
    emit('scenarioEnded', run.target, run.name, reason)
end

--- Runs a scenario for ONE player. seconds (optional) shortens the timeline.
---@return number|false runId, string? reason
function Scenarios.Run(target, name, opts)
    opts = opts or {}
    if not Config.General.Enabled then return false, 'system_disabled' end
    if not Scenarios.Exists(name) then return false, 'unknown_scenario', tostring(name) end
    if not Scenarios.Enabled(name) then return false, 'scenario_disabled', tostring(name) end

    target = tonumber(target)
    if not target or not Hall.IsOnline(target) then return false, 'player_not_found' end

    -- one scenario per player: a new one replaces the old one
    if byTarget[target] then Scenarios.StopFor(target, 'replaced') end

    local def = Config.Scenarios[name]
    local total = Utils.Num(opts.seconds, def.Duration or 60, 1, Config.Safety.MaxDuration)

    nextRun = nextRun + 1
    local run = { id = nextRun, target = target, name = name, sids = {}, cancelled = false, endsAt = GetGameTimer() + math.floor(total * 1000) }
    Runs[run.id] = run
    byTarget[target] = run.id

    local count = 0
    for _, step in ipairs(def.Steps or {}) do
        local every = type(step.Repeat) == 'table' and tonumber(step.Repeat.Every) or nil
        local times = type(step.Repeat) == 'table' and math.floor(tonumber(step.Repeat.Times) or 0) or 0
        if not every or every <= 0 then times = 0 end

        for k = 0, times do
            local at = (tonumber(step.At) or 0) + (every or 0) * k
            if at < total then
                count = count + 1
                local dur = math.min(tonumber(step.Duration) or 30, total - at)
                SetTimeout(math.floor(at * 1000), function()
                    if run.cancelled or not Runs[run.id] then return end
                    if step.Chance and math.random() > (tonumber(step.Chance) or 1) then return end
                    local sid, why = Hall.Start(target, step.Type, {
                        duration = dur, intensity = step.Intensity, params = step.Params,
                        source = opts.source or 'script', by = opts.by, scenario = name, force = opts.force,
                    })
                    if sid then run.sids[#run.sids + 1] = sid
                    else Utils.Debug(('scenario %s step %s skipped: %s'):format(name, tostring(step.Type), tostring(why))) end
                end)
            end
        end
    end

    SetTimeout(math.floor(total * 1000) + 250, function()
        if Runs[run.id] then finish(run, 'completed') end
    end)

    emit('scenarioStarted', target, name, total)
    Hall.Audit(('scenario %s started on %s (%.0fs, %d steps)'):format(name, tostring(GetPlayerName(target) or target), total, count))
    return run.id
end

--- Cancels the running scenario of a player and stops the sessions it started.
function Scenarios.StopFor(target, reason)
    local id = byTarget[target]
    local run = id and Runs[id]
    if not run then return false end
    run.cancelled = true
    for _, sid in ipairs(run.sids) do Hall.Stop(sid, reason or 'scenario_stopped') end
    finish(run, reason or 'stopped')
    return true
end

function Scenarios.StopAll(reason)
    local n = 0
    for _, run in pairs(Runs) do
        if Scenarios.StopFor(run.target, reason) then n = n + 1 end
    end
    return n
end

function Scenarios.Active(target)
    local id = byTarget[target]
    local run = id and Runs[id]
    return run and run.name or nil
end

function Scenarios.OnDrop(src)
    Scenarios.StopFor(src, 'left')
end
