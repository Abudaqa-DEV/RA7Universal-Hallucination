--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/zones.lua - haunted zones: whoever enters one gets a hallucination (created from the panel).
]]

Zones = {}

local cooldown = {}   -- [src][key] = game time when it may fire again

local function now() return GetGameTimer() end

function Zones.Inside(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    local out = {}
    for _, z in ipairs(Store.zones) do
        if z.enabled and Utils.Dist3(c.x, c.y, c.z, z.x, z.y, z.z) <= z.radius then out[#out + 1] = z end
    end
    return out
end

function Zones.Tick()
    if not Config.Zones.Enabled or #Store.zones == 0 then return end
    local t = now()
    for _, src in ipairs(Hall.OnlineList()) do
        if not Hall.IsDead(src) then
            local inside = Zones.Inside(src)
            for _, z in ipairs(inside or {}) do
                local cd = cooldown[src] or {}
                cooldown[src] = cd
                if (cd[z.key] or 0) <= t and math.random() < z.chance then
                    local sid = Hall.Start(src, z.type, { duration = z.duration, intensity = z.intensity, source = 'zone' })
                    cd[z.key] = t + math.floor(z.cooldown * 1000)
                    if sid then break end    -- one zone effect per check is enough
                end
            end
        end
    end
end

function Zones.OnDrop(src) cooldown[src] = nil end

CreateThread(function()
    while true do
        Wait(math.floor(Utils.Num(Config.Zones.CheckMs, 3000, 1000, 30000)))
        local ok, err = pcall(Zones.Tick)
        if not ok then Utils.Error('zones: ' .. tostring(err)) end
    end
end)
