--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/security.lua - rate limiting, validation, permissions (SERVER).

    Nothing in this resource trusts a value that comes from a client. Clients may only:
    report that an effect ended, send a reply text, toggle their own opt-out and answer appearance requests.
]]

Security = {}

local limits = {}    -- [src][key] = { start = ms, count = n }
local strikes = {}   -- [src] = { count = n }

local function log(src, reason, count)
    if not Config.Security.LogSuspicious then return end
    if count == 1 or count % 10 == 0 then
        Utils.Warn(('[security] player %s: %s (strike #%d)'):format(tostring(src), reason, count))
    end
end

function Security.Strike(src, reason)
    local s = strikes[src]
    if not s then
        s = { count = 0 }
        strikes[src] = s
    end
    s.count = s.count + 1
    log(src, reason, s.count)

    if Custom and type(Custom.OnSuspicious) == 'function' then pcall(Custom.OnSuspicious, src, reason) end

    if s.count >= Config.Security.MaxStrikes then
        s.count = 0
        if Config.Security.KickOnAbuse then
            DropPlayer(src, (Config.Brand.ScriptName or 'Universal Hallucination') .. ': abnormal activity detected.')
        end
    end
end

--- Rate limit for an event key defined in Config.Security.RateLimits.
function Security.Allow(src, key)
    local cfg = Config.Security.RateLimits[key]
    if not cfg then return true end

    local now = GetGameTimer()
    local bySrc = limits[src]
    if not bySrc then
        bySrc = {}
        limits[src] = bySrc
    end

    local window = (tonumber(cfg.window) or 10) * 1000
    local b = bySrc[key]
    if not b or now - b.start > window then
        b = { start = now, count = 0 }
        bySrc[key] = b
    end

    b.count = b.count + 1
    if b.count > (tonumber(cfg.max) or 5) then
        Security.Strike(src, 'rate limit exceeded: ' .. key)
        return false
    end
    return true
end

function Security.IsString(v, maxLen)
    return type(v) == 'string' and #v > 0 and #v <= (maxLen or 64)
end

function Security.IsNumber(v)
    return type(v) == 'number' and v == v and v ~= math.huge and v ~= -math.huge
end

--- Permission check. perm = 'Use' | 'Director' | 'Swap' | 'Admin'. The console (0) is always allowed.
function Security.Can(src, perm)
    if src == 0 then return true end
    local ace = Config.Permissions[perm]
    if type(ace) == 'string' and ace ~= '' and IsPlayerAceAllowed(src, ace) then return true end
    -- Admin always implies everything else
    local adminAce = Config.Permissions.Admin
    if perm ~= 'Admin' and type(adminAce) == 'string' and adminAce ~= '' and IsPlayerAceAllowed(src, adminAce) then return true end

    local jobs = Config.Permissions.Jobs and Config.Permissions.Jobs[perm]
    if type(jobs) == 'table' and #jobs > 0 and Framework and Framework.GetJob then
        local job = Framework.GetJob(src)
        if job and Utils.Contains(jobs, job) then return true end
    end
    return false
end

--- Stable license identifier (never changes between characters).
function Security.License(src)
    if GetPlayerIdentifierByType then
        local id = GetPlayerIdentifierByType(src, 'license')
        if id then return id end
    end
    for i = 0, (GetNumPlayerIdentifiers(src) or 0) - 1 do
        local v = GetPlayerIdentifier(src, i)
        if v and v:sub(1, 8) == 'license:' then return v end
    end
    return nil
end

function Security.Cleanup(src)
    limits[src] = nil
    strikes[src] = nil
end
