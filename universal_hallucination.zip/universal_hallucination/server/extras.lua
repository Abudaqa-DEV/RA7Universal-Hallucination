--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/extras.lua - resist mini-game results, live cues, appearing to one player, and possession.

    Everything the client reports here is validated: the client can only affect ITS OWN hallucinations.
]]

Resist = {}
Cues = {}
Possess = {}

local function now() return GetGameTimer() end
local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end
local function pname(src) return GetPlayerName(src) or tostring(src) end

-- ----------------------------------------------------------------------
-- Resist
-- ----------------------------------------------------------------------
function Resist.Allowed(typeKey)
    local R = Config.Resist
    if not R.Enabled then return false end
    if Utils.Contains(R.Exclude, typeKey) then return false end
    local c = Config.Types[typeKey]
    if c and c.Resist == false then return false end
    return true
end

--- The client finished a resist mini-game. `ms` = how long it took.
function Resist.OnResult(src, sid, success, ms)
    local s = Hall.Sessions[sid]
    if not s or not s.targets[src] then return false end
    if s.type == 'takeover' then return Takeover.OnResist(src, s, success == true, ms) end
    if not Resist.Allowed(s.type) then return false end
    local R = Config.Resist
    ms = Utils.Num(ms, 0, 0, 120000)
    if ms < R.MinMs then
        Security.Strike(src, 'resist: result too fast')
        return false
    end
    local t = now()
    if s.nextResist and t < s.nextResist then return false end
    s.nextResist = t + math.floor(R.Cooldown * 1000)

    if success then
        local v = s.intensity * (1.0 - Utils.Clamp(R.OnSuccess.Reduce, 0, 1))
        if v < R.OnSuccess.EndBelow then
            emit('resisted', src, sid, s.type, true, true)
            Hall.Audit(('%s resisted %s (ended)'):format(pname(src), s.type))
            Hall.Stop(sid, 'resisted')
            TriggerClientEvent('universal_halluc:client:resistDone', src, sid, true, true)
            return true
        end
        Hall.SetIntensity(sid, v)
    else
        Hall.SetIntensity(sid, math.min(R.OnFail.Max, s.intensity + R.OnFail.Increase))
    end
    emit('resisted', src, sid, s.type, success == true, false)
    TriggerClientEvent('universal_halluc:client:resistDone', src, sid, success == true, false)
    return true
end

-- ----------------------------------------------------------------------
-- Cues (instant "show" effects)
-- ----------------------------------------------------------------------
function Cues.List()
    local list = {}
    for key, c in pairs(Config.Cues.Items) do
        if type(c) == 'table' and c.Enabled ~= false and Registry.SwitchOn('Cues', key) then
            list[#list + 1] = { key = key, label = Locale('cue_' .. key), duration = c.Duration }
        end
    end
    table.sort(list, function(a, b) return a.key < b.key end)
    return list
end

--- Fires a cue on one or more players. Returns number of players reached, or false, reason.
function Cues.Fire(target, cueKey, opts)
    opts = opts or {}
    if not Config.Cues.Enabled then return false, 'system_disabled' end
    local c = type(cueKey) == 'string' and Config.Cues.Items[cueKey]
    if type(c) ~= 'table' then return false, 'unknown_cue', tostring(cueKey) end
    if c.Enabled == false or not Registry.SwitchOn('Cues', cueKey) then return false, 'cue_disabled', tostring(cueKey) end
    local list = Hall.ResolveTargets(target)
    local n = 0
    for _, src in ipairs(list) do
        if Hall.CanReceive(src, { force = opts.force, source = opts.source or 'command' }) == true then
            TriggerClientEvent('universal_halluc:client:cue', src, cueKey, Utils.Num(opts.seconds, c.Duration, 0.5, 30), Utils.Num(opts.intensity, 0.8, 0.1, 1))
            n = n + 1
        end
    end
    if n == 0 then return false, 'player_not_found' end
    Hall.Audit(('%s -> cue %s on %d player(s)'):format(pname(opts.by or 0), cueKey, n))
    return n
end

-- ----------------------------------------------------------------------
-- Appear: the admin shows up (with his own look) to ONE player only
-- ----------------------------------------------------------------------
function Possess.Appear(controller, target, seconds)
    controller, target = tonumber(controller), tonumber(target)
    if not controller or controller <= 0 then return false, 'invalid' end
    if not target or target == controller then return false, 'swap_same' end
    local sid, why, extra = Hall.Start(target, 'solo_visible', {
        subject = controller, duration = seconds, source = 'command', by = controller, force = true,
    })
    if sid and Config.Voice and Config.Voice.Use and Config.Voice.Use.Appear then
        Voice.Link('a' .. sid, controller, { target })
    end
    return sid, why, extra
end

-- ----------------------------------------------------------------------
-- Possess: the target watches through the controller's eyes (frozen, silent); the controller wears his look
-- ----------------------------------------------------------------------
local Active = {}   -- sid -> { controller, target, swapped }

function Possess.IsActive(src)
    for _, a in pairs(Active) do
        if a.controller == src or a.target == src then return true end
    end
    return false
end

function Possess.Start(controller, target, seconds, cb)
    cb = cb or function() end
    local P = Config.Possess
    if not P.Enabled then return cb(false, 'system_disabled') end
    controller, target = tonumber(controller), tonumber(target)
    if not controller or controller <= 0 or not Hall.IsOnline(controller) then return cb(false, 'invalid') end
    if not target or target == controller or not Hall.IsOnline(target) then return cb(false, 'player_not_found') end
    if Possess.IsActive(controller) or Possess.IsActive(target) then return cb(false, 'possess_busy') end

    seconds = Utils.Num(seconds, 120, 10, P.MaxSeconds)
    local sid, why, extra = Hall.Start(target, 'possess', {
        subject = controller, controller = controller, duration = seconds,
        source = 'director', by = controller, force = true,
    })
    if not sid then return cb(false, why, extra) end

    Active[sid] = { controller = controller, target = target, swapped = false }
    local mode = Config.Voice and Config.Voice.Use and Config.Voice.Use.Possess
    if mode == 'speak_as' then
        local s = Hall.Sessions[sid]
        if s and Voice.SpeakAs(controller, target) then s.voiceSpeakAs = controller end
    elseif mode == 'call' then
        Voice.Link('a' .. sid, controller, { target })
    end
    TriggerClientEvent('universal_halluc:client:possessInfo', controller, sid, true, target, pname(target), seconds)

    if P.SwapLooks and Config.Swap.Enabled and Config.Swap.Looks.Enabled then
        Swap.Looks(controller, controller, target, seconds, function(ok, reason)
            local a = Active[sid]
            if not a then
                if ok then Swap.Restore(controller, 'possess_ended') end
                return
            end
            a.swapped = ok == true
            if not ok then TriggerClientEvent('universal_halluc:client:notify', controller, 'possess_noswap', 'warning', nil, reason and Locale(reason) or '') end
        end)
    end
    emit('possessed', controller, target, sid)
    cb(sid)
end

function Possess.Stop(src, reason)
    for sid, a in pairs(Active) do
        if a.controller == src or a.target == src then
            Hall.Stop(sid, reason or 'stopped')
            return true
        end
    end
    return false
end

function Possess.OnSessionEnd(s, reason)
    local a = Active[s.sid]
    if not a then return end
    Active[s.sid] = nil
    if Hall.IsOnline(a.controller) then
        TriggerClientEvent('universal_halluc:client:possessInfo', a.controller, s.sid, false)
        TriggerClientEvent('universal_halluc:client:notify', a.controller, 'possess_ended', 'inform')
    end
    if a.swapped then
        Swap.Restore(a.controller, 'possess_ended')
    end
    emit('possessEnded', a.controller, a.target, reason)
end

--- Death handling
function Possess.Tick()
    if not Config.Possess.BlockRespawnDeath then return end
    for sid, a in pairs(Active) do
        if Hall.IsDead(a.controller) or Hall.IsDead(a.target) then Hall.Stop(sid, 'death') end
    end
end

local function finite(v, lim) return type(v) == 'number' and v == v and v > -lim and v < lim end

--- The controller streams his camera; the server relays it to the target (only for his own session).
RegisterNetEvent('universal_halluc:server:possessCam', function(sid, x, y, z, rx, ry, rz, fov)
    local src = source
    if not Security.Allow(src, 'cam') then return end
    local a = type(sid) == 'number' and Active[sid]
    if not a or a.controller ~= src then return end
    if not (finite(x, 20000) and finite(y, 20000) and finite(z, 3000) and finite(rx, 400) and finite(ry, 400) and finite(rz, 400)) then
        Security.Strike(src, 'possessCam: bad numbers')
        return
    end
    fov = finite(fov, 200) and fov or 60.0
    TriggerClientEvent('universal_halluc:client:possessCam', a.target, sid, x, y, z, rx, ry, rz, fov)
end)

RegisterNetEvent('universal_halluc:server:resist', function(sid, success, ms)
    local src = source
    if not Security.Allow(src, 'resist') then return end
    if type(sid) ~= 'number' or type(success) ~= 'boolean' or type(ms) ~= 'number' then
        Security.Strike(src, 'resist: bad payload')
        return
    end
    Resist.OnResult(src, sid, success, ms)
end)
