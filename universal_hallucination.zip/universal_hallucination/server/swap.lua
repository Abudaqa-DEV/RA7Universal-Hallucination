--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/swap.lua - look swap between two players + items swap + the character "carry pouch" (SERVER).

    SAFETY RULES
      * Items only move if their name is in a whitelist (Config.Swap.Items.Whitelist / Config.Swap.Carry.Whitelist).
      * Every move removes first and verifies, adds second, and rolls back on failure (no duplication).
      * Only the item name and the amount move (no metadata).
      * Original looks are backed up (memory + data/swap_backup.json) and restored on timer, death, drop+return.
]]

Swap = {}

local Active = {}       -- [src] = { partner, token, orig, movedOut = {name=n}, movedIn = {name=n}, license }
local Backup = {}       -- [license] = { data = <appearance>, at = os.time() }
local Pouch = {}        -- [license] = { items = {name=n}, at = os.time() }
local tokenCounter = 0

local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end

local function pname(src) return (GetPlayerName(src) or tostring(src)) end

-- ----------------------------------------------------------------------
-- JSON persistence
-- ----------------------------------------------------------------------
local BACKUP_FILE = 'data/swap_backup.json'

local function readJson(path)
    local raw = LoadResourceFile(GetCurrentResourceName(), path)
    if not raw or raw == '' then return {} end
    local ok, data = pcall(json.decode, raw)
    return (ok and type(data) == 'table') and data or {}
end

local function writeJson(path, tbl)
    local ok, enc = pcall(json.encode, tbl)
    if ok then SaveResourceFile(GetCurrentResourceName(), path, enc, -1) else Utils.Warn('Could not write ' .. path) end
end

function Swap.Load()
    if Config.Swap.Looks.PersistBackup then Backup = readJson(BACKUP_FILE) end
    if Config.Swap.Carry.Enabled then Pouch = readJson(Config.Swap.Carry.File) end

    -- drop expired pouches
    local expire = math.floor(Utils.Num(Config.Swap.Carry.ExpireHours, 72, 1, 720)) * 3600
    local t = os.time()
    for lic, p in pairs(Pouch) do
        if type(p) ~= 'table' or (tonumber(p.at) or 0) + expire < t then Pouch[lic] = nil end
    end
end

local function saveBackup()
    if Config.Swap.Looks.PersistBackup then writeJson(BACKUP_FILE, Backup) end
end

local function savePouch()
    if Config.Swap.Carry.Enabled then writeJson(Config.Swap.Carry.File, Pouch) end
end

-- ----------------------------------------------------------------------
-- Items
-- ----------------------------------------------------------------------
local function whitelisted(list)
    local set = {}
    for _, n in ipairs(list or {}) do
        if type(n) == 'string' and n ~= '' then set[n] = true end
    end
    return set
end

--- { name = count } of the whitelisted items the player holds (capped).
local function snapshot(src, whitelist)
    local I = Config.Swap.Items
    local maxStacks = math.floor(Utils.Num(I.MaxStacks, 12, 1, 100))
    local maxPer = math.floor(Utils.Num(I.MaxPerItem, 50, 1, 1000))
    local out, n = {}, 0
    for _, name in ipairs(whitelist) do
        if n >= maxStacks then break end
        local c = math.min(Inventory.Count(src, name), maxPer)
        if c > 0 then out[name] = c n = n + 1 end
    end
    return out, n
end

local function removeAll(src, items)
    local done = {}
    for name, c in pairs(items) do
        if Inventory.Remove(src, name, c) then done[name] = c
        else
            for rn, rc in pairs(done) do Inventory.Add(src, rn, rc) end   -- rollback
            return false
        end
    end
    return true
end

--- Gives items; whatever cannot be added is returned to `fallbackSrc`. Returns the table of what really landed.
local function giveAll(src, items, fallbackSrc)
    local landed = {}
    for name, c in pairs(items) do
        if Inventory.Add(src, name, c) then landed[name] = c
        elseif fallbackSrc then Inventory.Add(fallbackSrc, name, c) end
    end
    return landed
end

local function swapItems(a, b)
    local I = Config.Swap.Items
    if not I.Enabled then return true, {}, {} end
    if Inventory.Provider() == 'none' then return false end
    local wl = {}
    for n in pairs(whitelisted(I.Whitelist)) do wl[#wl + 1] = n end
    table.sort(wl)
    if #wl == 0 then return true, {}, {} end

    local ia = snapshot(a, wl)
    local ib = snapshot(b, wl)
    if next(ia) == nil and next(ib) == nil then return true, {}, {} end

    if not removeAll(a, ia) then return false end
    if not removeAll(b, ib) then
        for n, c in pairs(ia) do Inventory.Add(a, n, c) end
        return false
    end
    local toB = giveAll(b, ia, a)    -- what A gave and B really got
    local toA = giveAll(a, ib, b)
    return true, toB, toA            -- movedOut(a) = toB ; movedIn(a) = toA
end

--- Gives back what moved (best effort: only what the holder still has).
local function revertItems(src, partner, movedOut, movedIn)
    local function back(holder, owner, items)
        for name, c in pairs(items or {}) do
            local take = math.min(Inventory.Count(holder, name), c)
            if take > 0 and Inventory.Remove(holder, name, take) then
                if not Inventory.Add(owner, name, take) then Inventory.Add(holder, name, take) end
            end
        end
    end
    back(partner, src, movedOut)   -- things src gave: partner returns them
    back(src, partner, movedIn)    -- things src got: src returns them
end

-- ----------------------------------------------------------------------
-- Looks swap
-- ----------------------------------------------------------------------
local function both(cbA, cbB, done)
    local res, n = {}, 0
    local function one(key, ok, data, extra)
        res[key] = { ok = ok, data = data, extra = extra }
        n = n + 1
        if n == 2 then done(res.a, res.b) end
    end
    return function(ok, data, extra) one('a', ok, data, extra) end, function(ok, data, extra) one('b', ok, data, extra) end
end

local function restorePlayer(src, reason)
    local st = Active[src]
    if not st then return false end
    Active[src] = nil
    local lic = st.license
    if Hall.IsOnline(src) and st.orig then
        AppearanceServer.Apply(src, st.orig, function(ok)
            if ok and lic and Backup[lic] then Backup[lic] = nil saveBackup() end
        end)
    end
    emit('swapRestored', src, reason)
    return true
end

--- Restores a player (and his swap partner).
function Swap.Restore(src, reason)
    local st = Active[src]
    if not st then return false end
    local partner = st.partner
    local pst = Active[partner]
    if Config.Swap.Items.Enabled and Config.Swap.Items.Revert ~= false and pst and Hall.IsOnline(src) and Hall.IsOnline(partner) then
        revertItems(src, partner, st.movedOut, st.movedIn)
    end
    restorePlayer(src, reason or 'restore')
    if pst then restorePlayer(partner, reason or 'restore') end
    return true
end

function Swap.IsSwapped(src) return Active[src] ~= nil end

--- Swaps the look (and optionally the whitelisted items) of two players. cb(ok, reason)
function Swap.Looks(by, a, b, seconds, cb)
    cb = cb or function() end
    local S = Config.Swap
    if not (S.Enabled and S.Looks.Enabled) then return cb(false, 'swap_disabled') end
    a, b = tonumber(a), tonumber(b)
    if not a or not b or a == b then return cb(false, 'swap_same') end
    if not Hall.IsOnline(a) or not Hall.IsOnline(b) then return cb(false, 'player_not_found') end
    if Active[a] or Active[b] then return cb(false, 'swap_already') end

    seconds = Utils.Num(seconds, S.Looks.MaxSeconds, 10, S.Looks.MaxSeconds)

    tokenCounter = tokenCounter + 1
    local token = tokenCounter
    Active[a] = { partner = b, token = token, pending = true }
    Active[b] = { partner = a, token = token, pending = true }

    local function abort(reason)
        if Active[a] and Active[a].token == token then Active[a] = nil end
        if Active[b] and Active[b].token == token then Active[b] = nil end
        cb(false, reason)
    end

    local ga, gb = both(nil, nil, function(ra, rb)
        if not (ra.ok and rb.ok and ra.data and rb.data) then return abort('swap_no_data') end
        if not Config.Appearance.AllowModelChange and ra.extra ~= rb.extra then return abort('swap_model_mismatch') end

        local licA, licB = Security.License(a), Security.License(b)
        Active[a] = { partner = b, token = token, orig = ra.data, license = licA, movedOut = {}, movedIn = {} }
        Active[b] = { partner = a, token = token, orig = rb.data, license = licB, movedOut = {}, movedIn = {} }
        if licA then Backup[licA] = { data = ra.data, at = os.time() } end
        if licB then Backup[licB] = { data = rb.data, at = os.time() } end
        saveBackup()

        local pa, pb = both(nil, nil, function(xa, xb)
            if not (xa.ok and xb.ok) then
                Swap.Restore(a, 'apply_failed')
                return cb(false, 'swap_no_data')
            end
            local itemsDone = false
            if S.Items.Enabled then
                local ok, movedOutA, movedInA = swapItems(a, b)
                if ok then
                    Active[a].movedOut, Active[a].movedIn = movedOutA, movedInA
                    Active[b].movedOut, Active[b].movedIn = movedInA, movedOutA
                    itemsDone = next(movedOutA) ~= nil or next(movedInA) ~= nil
                end
            end

            SetTimeout(math.floor(seconds * 1000), function()
                if Active[a] and Active[a].token == token then Swap.Restore(a, 'timeout') end
            end)

            emit('swapped', a, b, itemsDone)
            Hall.Audit(('%s swapped looks %s <-> %s (%.0fs%s)'):format(pname(by or 0), pname(a), pname(b), seconds, itemsDone and ', items' or ''))
            cb(true, nil, itemsDone)
        end)
        AppearanceServer.Apply(a, rb.data, pa)
        AppearanceServer.Apply(b, ra.data, pb)
    end)
    AppearanceServer.Get(a, ga)
    AppearanceServer.Get(b, gb)
end

--- Death / drop / return handling
function Swap.Tick()
    if not Config.Swap.Looks.RestoreOnDeath then return end
    for src, st in pairs(Active) do
        if not st.pending then
            local ped = GetPlayerPed(src)
            if ped ~= 0 and GetEntityHealth(ped) <= 0 then
                Swap.Restore(src, 'death')
                return
            end
        end
    end
end

function Swap.OnDrop(src)
    local st = Active[src]
    if not st then return end
    local partner = st.partner
    Active[src] = nil                       -- the backup file keeps the original look for his return
    if Active[partner] and Hall.IsOnline(partner) then restorePlayer(partner, 'partner_left') end
end

--- A player with a pending backup (he left during a swap) gets his original look back.
function Swap.OnReady(src)
    local lic = Security.License(src)
    local b = lic and Backup[lic]
    if not b or Active[src] then return end
    SetTimeout(4000, function()
        if not Hall.IsOnline(src) then return end
        AppearanceServer.Apply(src, b.data, function(ok)
            if ok then Backup[lic] = nil saveBackup() emit('swapRestored', src, 'rejoin') end
        end)
    end)
end

-- ----------------------------------------------------------------------
-- Carry pouch (items follow the player between characters)
-- ----------------------------------------------------------------------
function Swap.Stash(src)
    local C = Config.Swap.Carry
    if not (Config.Swap.Enabled and C.Enabled) then return false, 'carry_disabled' end
    if Inventory.Provider() == 'none' then return false, 'swap_no_provider' end
    local lic = Security.License(src)
    if not lic then return false end

    local wl = {}
    for n in pairs(whitelisted(C.Whitelist)) do wl[#wl + 1] = n end
    table.sort(wl)
    if #wl == 0 then return false, 'carry_none' end

    local items = snapshot(src, wl)
    if next(items) == nil then return false, 'carry_none' end
    if not removeAll(src, items) then return false end

    local pouch = Pouch[lic] or { items = {}, at = os.time() }
    for n, c in pairs(items) do pouch.items[n] = (pouch.items[n] or 0) + c end
    pouch.at = os.time()
    Pouch[lic] = pouch
    savePouch()
    local kinds = 0
    for _ in pairs(items) do kinds = kinds + 1 end
    Hall.Audit(('carry stash: %s kept %d kinds of items'):format(pname(src), kinds))
    return true, kinds
end

function Swap.Deliver(src)
    local C = Config.Swap.Carry
    if not (Config.Swap.Enabled and C.Enabled) then return false, 'carry_disabled' end
    if Inventory.Provider() == 'none' then return false, 'swap_no_provider' end
    local lic = Security.License(src)
    local pouch = lic and Pouch[lic]
    if not pouch or next(pouch.items) == nil then return false, 'carry_none' end

    local kinds = 0
    for name, c in pairs(pouch.items) do
        if Inventory.Add(src, name, c) then
            pouch.items[name] = nil
            kinds = kinds + 1
        end
    end
    if next(pouch.items) == nil then Pouch[lic] = nil end   -- whatever failed (e.g. no space) stays in the pouch
    savePouch()
    Hall.Audit(('carry deliver: %s received %d kinds of items'):format(pname(src), kinds))
    return true, kinds
end

local function resolveSrc(a)
    if type(a) == 'number' then return a end
    if type(a) == 'string' and tonumber(a) then return tonumber(a) end
    if type(a) == 'table' then
        return tonumber(a.source) or (a.PlayerData and tonumber(a.PlayerData.source)) or nil
    end
    local s = rawget(_G, 'source')
    return type(s) == 'number' and s or nil
end

function Swap.RegisterEvents()
    local C = Config.Swap.Carry
    if not (Config.Swap.Enabled and C.Enabled) then return end
    for _, ev in ipairs(C.LeaveEvents or {}) do
        if type(ev) == 'string' and ev ~= '' then
            AddEventHandler(ev, function(a)
                local src = resolveSrc(a)
                if src then Swap.Stash(src) end
            end)
        end
    end
    for _, ev in ipairs(C.JoinEvents or {}) do
        if type(ev) == 'string' and ev ~= '' then
            AddEventHandler(ev, function(a)
                local src = resolveSrc(a)
                if src then SetTimeout(2000, function() Swap.Deliver(src) end) end
            end)
        end
    end
end
