--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/mind.lua - persistent stress ("mental state") per character. The higher it is, the more often
    automatic hallucinations start (Config.Mind.Levels). Medication / therapy lower it (panel or exports).
]]

Mind = {}

local M = {}          -- [src] = { v, key, dead, lastGain }
local dirty = false

local function K() return Config.Mind end
local function max() return Utils.Num(K().Max, 100, 10, 1000) end
local function realNow() return (os and os.time) and os.time() or 0 end

local function keyOf(src)
    local k = Security.License(src)
    if type(k) ~= 'string' or k == '' then return nil end
    if Framework and Framework.GetCharId then
        local ok, c = pcall(Framework.GetCharId, src)
        if ok and c then k = k .. ':' .. tostring(c) end
    end
    return k
end

function Mind.OnReady(src)
    if not K().Enabled then return end
    local key = keyOf(src)
    local v = 0.0
    if key and K().Persist ~= false and Store.mind[key] then
        v = Store.mind[key].v
        -- time spent offline also calms him down
        local away = math.max(0, realNow() - (Store.mind[key].t or 0))
        v = math.max(0.0, v - (away / 60.0) * Utils.Num(K().Decay.PerMinute, 1.0, 0.0, 100.0) * 0.5)
    end
    M[src] = { v = Utils.Clamp(v, 0.0, max()), key = key, dead = false }
end

local function save(src)
    local st = M[src]
    if st and st.key and K().Persist ~= false then Store.mind[st.key] = { v = st.v, t = realNow() } dirty = true end
end

function Mind.OnDrop(src)
    save(src)
    M[src] = nil
    if dirty then Store.Save() dirty = false end
end

function Mind.Get(src) local st = M[tonumber(src) or -1] return st and st.v or 0.0 end

function Mind.Set(src, v)
    local st = M[tonumber(src) or -1]
    if not st then return false end
    st.v = Utils.Clamp(Utils.Num(v, st.v, 0.0, max()), 0.0, max())
    save(src)
    return true, st.v
end

function Mind.Add(src, amount)
    local st = M[tonumber(src) or -1]
    if not st then return false end
    return Mind.Set(src, st.v + (tonumber(amount) or 0.0))
end

--- Level table that matches the current value (the highest `at` reached).
local function levelFor(v)
    local best
    for _, lv in ipairs(K().Levels or {}) do
        if v >= (lv.at or 0) and (not best or lv.at > best.at) then best = lv end
    end
    return best
end

function Mind.Tick()
    if not K().Enabled then return end
    local secs = Utils.Num(K().CheckSeconds, 30, 5, 300)
    for src, st in pairs(M) do
        if Hall.IsOnline(src) then
            local dead = Hall.IsDead(src)
            local gained = false
            if dead and not st.dead then Mind.Add(src, Utils.Num(K().Gain.Death, 15, 0, 100)) gained = true end
            st.dead = dead
            if not dead then
                local lh = K().Gain.LowHealth
                if type(lh) == 'table' then
                    local ped = GetPlayerPed(src)
                    if ped and ped ~= 0 then
                        local hp, mx = GetEntityHealth(ped), GetEntityMaxHealth(ped)
                        if mx and mx > 100 and hp and hp > 100 and (hp - 100) / (mx - 100) < Utils.Num(lh.Below, 0.3, 0.0, 1.0) then
                            Mind.Add(src, Utils.Num(lh.PerCheck, 2, 0, 50)) gained = true
                        end
                    end
                end
                local busy = #Hall.GetActive(src) > 0
                if not gained and not (K().Decay.OnlyWhenCalm ~= false and busy) then
                    Mind.Add(src, -Utils.Num(K().Decay.PerMinute, 1.0, 0.0, 100.0) * (secs / 60.0))
                end
                -- automatic hallucination
                local lv = levelFor(st.v)
                if lv and not busy and math.random() < Utils.Num(lv.chance, 0.05, 0.0, 1.0) then
                    local ty = Utils.Pick(lv.types or {})
                    if ty then
                        local I, D = lv.intensity or {}, lv.duration or {}
                        local intensity = Utils.Rand(Utils.Num(I.min, 0.3, 0.05, 1.0), Utils.Num(I.max, 0.6, 0.05, 1.0))
                        local duration = Utils.Rand(Utils.Num(D.min, 20, 5, 600), Utils.Num(D.max, 50, 5, 600))
                        local sid = Hall.Start(src, ty, { duration = duration, intensity = intensity, source = 'mind' })
                        if sid and K().Gain.Hallucination and K().Gain.Hallucination > 0 then Mind.Add(src, K().Gain.Hallucination * 0.5) end
                    end
                end
            end
            save(src)
        end
    end
    if dirty then Store.Save() dirty = false end
end

CreateThread(function()
    while true do
        Wait(math.floor(Utils.Num(K().CheckSeconds, 30, 5, 300) * 1000))
        local ok, err = pcall(Mind.Tick)
        if not ok then Utils.Error('mind: ' .. tostring(err)) end
    end
end)
