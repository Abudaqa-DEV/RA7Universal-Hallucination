--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/world.lua - "parallel world": a player is moved to another place (optionally in his own routing bucket),
    frozen so he can only look, REAL staff players are brought next to him, and everybody is returned afterwards.
    Everything is driven from the panel (see Config.World).
]]

World = {}

local W = {}         -- target -> state
local memberOf = {}  -- member -> target

local function C() return Config.World end
local function now() return GetGameTimer() end
local function pname(src) return GetPlayerName(src) or tostring(src) end
local function emit(name, ...)
    if Config.Integration.EmitEvents then TriggerEvent('universal_halluc:' .. name, ...) end
end
local function notify(src, key, ntype, ...)
    if src and Hall.IsOnline(src) then TriggerClientEvent('universal_halluc:client:notify', src, key, ntype or 'inform', nil, ...) end
end

local function coordsOf(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    local c = GetEntityCoords(ped)
    return { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped), inVeh = GetVehiclePedIsIn(ped, false) ~= 0 }
end

local function moveTo(src, p, bucket)
    if not Hall.IsOnline(src) then return end
    if bucket ~= nil and SetPlayerRoutingBucket then pcall(SetPlayerRoutingBucket, src, bucket) end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return end
    SetEntityCoords(ped, p.x, p.y, p.z, false, false, false, false)
    SetEntityHeading(ped, p.h or 0.0)
end

local function fade(list, dir, ms)
    for _, id in ipairs(list) do
        if Hall.IsOnline(id) then TriggerClientEvent('universal_halluc:client:fade', id, dir, ms) end
    end
end

--- Runs `fn` while the screens of `list` are black (when Config.World.Fade is on).
local function withFade(list, fn)
    if C().Fade == false then fn() return end
    local ms = Utils.Num(C().FadeMs, 700, 100, 3000)
    fade(list, 'out', ms)
    SetTimeout(ms + 120, function()
        fn()
        SetTimeout(350, function() fade(list, 'in', ms) end)
    end)
end

function World.IsActive(src) return W[src] ~= nil or memberOf[src] ~= nil end

local function allInvolved(st)
    local list = { st.target }
    for id in pairs(st.members) do list[#list + 1] = id end
    return list
end

local function pickBucket()
    local base = Utils.Num(C().BucketBase, 7000, 100, 60000)
    local used = {}
    for _, st in pairs(W) do if st.bucket then used[st.bucket] = true end end
    local b = base
    while used[b] do b = b + 1 end
    return b
end

--- Places the staff around the target (a ring of 2 m, facing him).
local function staffSpot(st, i, n)
    local ang = (2 * math.pi) * ((i - 1) / math.max(n, 1)) + math.pi / 4
    local p = st.place
    local x, y = p.x + math.cos(ang) * 2.0, p.y + math.sin(ang) * 2.0
    local h = (math.deg(math.atan(p.y - y, p.x - x)) - 90.0) % 360.0
    return { x = x, y = y, z = p.z, h = h }
end

function World.List()
    local out = {}
    for t, st in pairs(W) do
        local names = {}
        for id in pairs(st.members) do names[#names + 1] = pname(id) end
        table.sort(names)
        out[#out + 1] = { target = t, targetName = pname(t), place = st.placeLabel, staff = names, controller = st.controller,
            remaining = math.max(0, math.floor((st.endsAt - now()) / 1000)), bucket = st.bucket }
    end
    table.sort(out, function(a, b) return a.target < b.target end)
    return out
end

---@param opts table { staff = {ids}, seconds, bucket = bool, join = bool }
function World.Send(controller, target, placeKey, opts)
    opts = opts or {}
    local K = C()
    if not K.Enabled then return false, 'system_disabled' end
    controller, target = tonumber(controller), tonumber(target)
    if not controller or not Hall.IsOnline(controller) then return false, 'invalid' end
    if not target or target == controller or not Hall.IsOnline(target) then return false, 'player_not_found' end
    if World.IsActive(target) or World.IsActive(controller) then return false, 'world_busy' end
    if Takeover.IsActive(target) or Possess.IsActive(target) then return false, 'world_busy' end
    local place = Store.FindPlace(placeKey)
    if not place then return false, 'world_no_place' end

    local home = coordsOf(target)
    if not home then return false, 'player_not_found' end
    if home.inVeh and K.RefuseInVehicle ~= false then return false, 'world_vehicle' end

    local staff, seen = {}, { [target] = true }
    local function addStaff(id)
        id = tonumber(id)
        if not id or seen[id] or not Hall.IsOnline(id) then return end
        if World.IsActive(id) then return end
        if K.StaffOnly ~= false and not Security.Can(id, 'Use') then return end
        seen[id] = true
        staff[#staff + 1] = id
    end
    if opts.join ~= false then addStaff(controller) end
    for _, id in ipairs(type(opts.staff) == 'table' and opts.staff or {}) do addStaff(id) end
    local maxStaff = math.floor(Utils.Num(K.MaxStaff, 8, 0, 30))
    while #staff > maxStaff do table.remove(staff) end

    local secs = Utils.Num(opts.seconds, 300, 10, Utils.Num(K.MaxSeconds, 1800, 10, 7200))
    local st = {
        target = target, controller = controller, place = place, placeLabel = place.label, members = {}, homes = {},
        endsAt = now() + math.floor(secs * 1000), ended = false,
    }
    local useBucket = (opts.bucket == nil) and (K.UseBucket ~= false) or (opts.bucket == true)
    if useBucket and GetPlayerRoutingBucket then st.bucket = pickBucket() end

    local function remember(id)
        local c = coordsOf(id)
        local b = GetPlayerRoutingBucket and GetPlayerRoutingBucket(id) or 0
        st.homes[id] = { x = c and c.x or 0.0, y = c and c.y or 0.0, z = c and c.z or 0.0, h = c and c.h or 0.0, bucket = b, inVeh = c and c.inVeh }
    end
    remember(target)
    for _, id in ipairs(staff) do
        local c = coordsOf(id)
        if c and not (c.inVeh and K.RefuseInVehicle ~= false) then remember(id) st.members[id] = true memberOf[id] = target end
    end

    local sid, why = Hall.Start(target, 'world_frozen', { duration = secs, source = 'director', by = controller, force = true })
    if not sid then
        for id in pairs(st.members) do memberOf[id] = nil end
        return false, why or 'invalid'
    end
    st.sid = sid
    W[target] = st

    local list = allInvolved(st)
    local order = {}
    for id in pairs(st.members) do order[#order + 1] = id end
    table.sort(order)
    withFade(list, function()
        if st.ended then return end
        moveTo(target, place, st.bucket)
        for i, id in ipairs(order) do moveTo(id, staffSpot(st, i, #order), st.bucket) end
    end)

    notify(target, 'world_you', 'warning')
    for _, id in ipairs(order) do notify(id, 'world_staff', 'inform', pname(target)) end
    Hall.Audit(('%s sent %s to %s (%d staff%s)'):format(pname(controller), pname(target), tostring(place.key), #order, st.bucket and (', bucket ' .. st.bucket) or ''))
    emit('worldStarted', target, controller, place.key)
    return true
end

--- Adds one more staff player to a running world.
function World.Join(controller, target, id)
    local st = W[tonumber(target)]
    if not st then return false, 'world_none' end
    id = tonumber(id)
    if not id or not Hall.IsOnline(id) or id == st.target then return false, 'player_not_found' end
    if World.IsActive(id) then return false, 'world_busy' end
    if C().StaffOnly ~= false and not Security.Can(id, 'Use') then return false, 'world_not_staff' end
    local n = 0
    for _ in pairs(st.members) do n = n + 1 end
    if n >= math.floor(Utils.Num(C().MaxStaff, 8, 0, 30)) then return false, 'world_full' end
    local c = coordsOf(id)
    if not c or (c.inVeh and C().RefuseInVehicle ~= false) then return false, 'world_vehicle' end
    st.homes[id] = { x = c.x, y = c.y, z = c.z, h = c.h, bucket = GetPlayerRoutingBucket and GetPlayerRoutingBucket(id) or 0 }
    st.members[id] = true
    memberOf[id] = st.target
    withFade({ id }, function() if not st.ended then moveTo(id, staffSpot(st, n + 1, n + 1), st.bucket) end end)
    notify(id, 'world_staff', 'inform', pname(st.target))
    return true
end

--- Returns everybody to where he was (target, staff).
function World.Finish(st, reason)
    if st.ended then return end
    st.ended = true
    W[st.target] = nil
    local list = allInvolved(st)
    for id in pairs(st.members) do memberOf[id] = nil end
    if st.sid then local sid = st.sid st.sid = nil Hall.Stop(sid, reason or 'world_end') end
    local function back()
        for _, id in ipairs(list) do
            local h = st.homes[id]
            if h then moveTo(id, h, h.bucket) end
            if Hall.IsOnline(id) then notify(id, 'world_back', 'success') end
        end
    end
    local online = {}
    for _, id in ipairs(list) do if Hall.IsOnline(id) then online[#online + 1] = id end end
    withFade(online, back)
    emit('worldEnded', st.target, reason)
end

--- Panel / export: ends the world of `target` (or the world that `src` belongs to).
function World.Return(src, reason)
    src = tonumber(src)
    local st = src and (W[src] or W[memberOf[src] or -1])
    if not st then return false end
    World.Finish(st, reason or 'returned')
    return true
end

function World.OnSessionEnd(s, reason)
    for _, st in pairs(W) do
        if st.sid == s.sid and not st.ended then
            st.sid = nil
            World.Finish(st, reason or 'stopped')
            return
        end
    end
end

function World.OnDrop(src)
    local st = W[src]
    if st then
        st.homes[src] = nil          -- he left: nothing to restore for him
        World.Finish(st, 'left')
        return
    end
    local t = memberOf[src]
    if t and W[t] then W[t].members[src] = nil W[t].homes[src] = nil end
    memberOf[src] = nil
end

CreateThread(function()
    while true do
        Wait(1000)
        for _, st in pairs(W) do
            if not st.ended and now() >= st.endsAt then World.Finish(st, 'timeout') end
        end
    end
end)
