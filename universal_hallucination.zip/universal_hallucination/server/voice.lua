--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    server/voice.lua - real voice from microphone to microphone (optional, Config.Voice).

    Two ways to be heard:
      Voice.Link(key, controller, { targets })   a private call channel: the controller and the targets hear each other
      Voice.SpeakAs(controller, target)          everybody near the TARGET hears the controller (as if the target spoke)

    Providers: 'pma-voice' (setPlayerCall) | 'mumble-voip' (SetCallChannel) | 'custom' (Custom.Voice.* in bridge/custom.lua).
    Export names of third party voice resources are written from their public documentation and are not verified live
    here: if your voice resource differs, use the 'custom' provider.
]]

Voice = {}

local links = {}      -- key -> { controller, targets = { src }, channel }
local speakAs = {}    -- controller -> target
local nextChannel = 0

local function V() return Config.Voice or {} end

function Voice.Enabled() return V().Enabled == true end

local function setCall(provider, src, channel)
    if provider == 'pma-voice' then
        exports['pma-voice']:setPlayerCall(src, channel)
    elseif provider == 'mumble-voip' then
        exports['mumble-voip']:SetCallChannel(src, channel)
    end
end

--- Links the controller with the targets in a private call. Returns the channel number or nil.
function Voice.Link(key, controller, targets)
    if not Voice.Enabled() or type(key) ~= 'string' then return nil end
    controller = tonumber(controller)
    if not controller or controller <= 0 or type(targets) ~= 'table' or #targets == 0 then return nil end
    if links[key] then Voice.Unlink(key) end
    nextChannel = nextChannel + 1
    local base = math.floor(Utils.Num(V().ChannelBase, 9000, 1, 60000))
    local channel = base + nextChannel
    local list = {}
    for _, t in ipairs(targets) do
        t = tonumber(t)
        if t and t ~= controller then list[#list + 1] = t end
    end
    if #list == 0 then return nil end
    local provider = V().Provider
    local ok, err = pcall(function()
        if provider == 'custom' then
            if not (Custom and Custom.Voice and Custom.Voice.Link) then error('Custom.Voice.Link is missing in bridge/custom.lua') end
            for _, t in ipairs(list) do Custom.Voice.Link(controller, t, channel) end
        else
            setCall(provider, controller, channel)
            for _, t in ipairs(list) do setCall(provider, t, channel) end
        end
    end)
    if not ok then
        Utils.Warn(('Voice link (%s) failed: %s'):format(tostring(provider), tostring(err)))
        return nil
    end
    links[key] = { controller = controller, targets = list, channel = channel }
    return channel
end

function Voice.Unlink(key)
    local l = links[key]
    if not l then return false end
    links[key] = nil
    local provider = V().Provider
    pcall(function()
        if provider == 'custom' then
            if Custom and Custom.Voice and Custom.Voice.Unlink then
                for _, t in ipairs(l.targets) do Custom.Voice.Unlink(l.controller, t, l.channel) end
            end
        else
            setCall(provider, l.controller, 0)
            for _, t in ipairs(l.targets) do setCall(provider, t, 0) end
        end
    end)
    return true
end

function Voice.IsLinked(key) return links[key] ~= nil end

--- The controller's microphone is heard around the target (the client does the audio part).
function Voice.SpeakAs(controller, target)
    if not Voice.Enabled() then return false end
    controller, target = tonumber(controller), tonumber(target)
    if not controller or not target then return false end
    speakAs[controller] = target
    TriggerClientEvent('universal_halluc:client:voiceAs', controller, target)
    return true
end

function Voice.StopSpeakAs(controller)
    controller = tonumber(controller)
    if not controller or not speakAs[controller] then return false end
    speakAs[controller] = nil
    TriggerClientEvent('universal_halluc:client:voiceAs', controller, nil)
    return true
end

--- Called when a session ends: everything the session linked is released.
function Voice.OnSessionEnd(s)
    Voice.Unlink('s' .. s.sid)
    Voice.Unlink('a' .. s.sid)
    if s.voiceSpeakAs then
        Voice.StopSpeakAs(s.voiceSpeakAs)
        s.voiceSpeakAs = nil
    end
end

--- Manual toggle for /hvoice
function Voice.Toggle(controller, target)
    local key = 'm' .. tostring(controller)
    if links[key] then
        Voice.Unlink(key)
        return false
    end
    return Voice.Link(key, controller, { target }) ~= nil
end

function Voice.Release(src)
    for key, l in pairs(links) do
        if l.controller == src then
            Voice.Unlink(key)
        else
            for _, t in ipairs(l.targets) do
                if t == src then Voice.Unlink(key) break end
            end
        end
    end
    Voice.StopSpeakAs(src)
    for c, t in pairs(speakAs) do
        if t == src then Voice.StopSpeakAs(c) end
    end
end

--- The target's microphone is heard ONLY by the controller (the client does the audio part).
function Voice.Isolate(target, controller)
    target, controller = tonumber(target), tonumber(controller)
    if not target or not controller then return false end
    TriggerClientEvent('universal_halluc:client:voiceIsolate', target, controller)
    return true
end

function Voice.Unisolate(target)
    target = tonumber(target)
    if not target then return false end
    TriggerClientEvent('universal_halluc:client:voiceIsolate', target, nil)
    return true
end
