# Installation

1. Copy `universal_hallucination` to `resources/`.
2. `server.cfg`: `ensure universal_hallucination` and the four ACE lines from the README (`use`, `director`, `swap`, `admin`).
   Jobs can also grant permissions: `Config.Permissions.Jobs` (needs ESX / QBCore / Qbox).
3. Edit `config.lua`: `Config.Brand` (server name, colors), `Config.General.Language` (`ar` / `en`), `Config.General.Framework` (`auto` finds it).
4. Optional: clothing provider (`Config.Appearance`) for `/hswap` and possession look; voice (`Config.Voice`) for mic-to-mic.
5. Restart the resource, join, type `/hmenu`.

Requirements: OneSync enabled, Lua 5.4 (set in the manifest). No database. No other resource is required.
