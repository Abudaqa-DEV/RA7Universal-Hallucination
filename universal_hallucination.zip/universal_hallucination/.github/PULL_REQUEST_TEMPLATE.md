## What changed

## Checklist
- [ ] `python3 tests/runlua.py run tests/server_test.lua` passes
- [ ] `python3 tests/runlua.py run tests/client_test.lua` passes
- [ ] New config values are documented in config.lua (Arabic comment, allowed range, default)
- [ ] New texts exist in both locales/ar.lua and locales/en.lua
- [ ] The effect is harmless by design (no damage, no network entities) and cleans up when the session ends
