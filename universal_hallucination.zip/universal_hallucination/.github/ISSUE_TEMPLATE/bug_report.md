---
name: Bug report
about: Something does not work
labels: bug
---

**What happened**

**What you expected**

**Steps to reproduce** (command / panel action / export used)

**Environment**
- Framework (standalone / ESX / QBCore / Qbox / custom):
- Clothing resource (if /hswap or /hpossess look swap):
- Server build / OneSync:
- Resource version:

**Console output (server and F8 client)**
