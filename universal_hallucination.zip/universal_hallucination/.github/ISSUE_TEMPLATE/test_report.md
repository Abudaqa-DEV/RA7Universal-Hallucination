---
name: Test report (Diagnostics)
about: You ran it on a real server - tell us what works and which names do not exist
labels: testing
---

**Server**
- FiveM build / OneSync:
- Framework (standalone / ESX / QBCore / Qbox / custom):
- Resource version:

**Diagnostics tab result** (`/hmenu` -> Diagnostics -> run). Paste the list of missing models / clip sets / animations / particles / weapons:

```
```

**What worked well**

**What did not work or looked wrong** (type / scenario / tab, and what you saw)

**Screenshots or short video** (optional)
