---
name: Feature request
about: Suggest a hallucination type, scenario, cue or integration
labels: enhancement
---

**The idea**

**Who would use it (roleplay situation)**

**How it should be configured** (what would a beginner change in config.lua?)
