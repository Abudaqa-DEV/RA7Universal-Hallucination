--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/inventory.lua - inventory adapter (SERVER). Used only by Config.Swap.Items and Config.Swap.Carry.

    API:  Inventory.Provider()  Inventory.Count(src, name)  Inventory.Remove(src, name, n) -> bool  Inventory.Add(src, name, n) -> bool
    Providers: auto | ox_inventory | qbcore (qb-core/qbx_core inventories) | esx | custom | none
    NOTE: only the item name and the amount are moved. Metadata (serials, durability, ...) is NOT preserved.
]]

Inventory = {}

local provider
local warned = {}

local function warnOnce(key, msg)
    if warned[key] then return end
    warned[key] = true
    Utils.Warn(msg)
end

local function started(res) return GetResourceState(res) == 'started' end

local function resolve()
    local want = Config.Swap.Items.Provider
    if want == 'none' then return 'none' end
    if want == 'auto' then
        if started('ox_inventory') then return 'ox_inventory' end
        if started('qbx_core') or started('qb-core') then return 'qbcore' end
        if started('es_extended') then return 'esx' end
        return 'none'
    end
    if want == 'ox_inventory' then
        if started('ox_inventory') then return 'ox_inventory' end
    elseif want == 'qbcore' then
        if started('qbx_core') or started('qb-core') then return 'qbcore' end
    elseif want == 'esx' then
        if started('es_extended') then return 'esx' end
    elseif want == 'custom' then
        local c = Custom and Custom.Inventory
        if type(c) == 'table' and type(c.Count) == 'function' and type(c.Remove) == 'function' and type(c.Add) == 'function' then return 'custom' end
        warnOnce('custom', 'Swap.Items.Provider = "custom" but Custom.Inventory.Count / Remove / Add are not defined (bridge/custom.lua). Item moves are disabled.')
        return 'none'
    end
    warnOnce('prov', ('Swap.Items.Provider "%s" is not available. Item moves are disabled.'):format(tostring(want)))
    return 'none'
end

function Inventory.Provider()
    provider = provider or resolve()
    return provider
end

local function qbPlayer(src)
    if started('qbx_core') then return exports.qbx_core:GetPlayer(src) end
    return exports['qb-core']:GetCoreObject().Functions.GetPlayer(src)
end

local function esxPlayer(src)
    return exports['es_extended']:getSharedObject().GetPlayerFromId(src)
end

local function safe(fn, ...)
    local ok, res = pcall(fn, ...)
    if not ok then
        warnOnce('err', 'Inventory call failed: ' .. tostring(res))
        return nil
    end
    return res
end

function Inventory.Count(src, name)
    local p = Inventory.Provider()
    local n
    if p == 'ox_inventory' then
        n = safe(function() return exports.ox_inventory:GetItemCount(src, name) end)
    elseif p == 'qbcore' then
        n = safe(function()
            local pl = qbPlayer(src)
            local it = pl and pl.Functions.GetItemByName(name)
            return it and it.amount or 0
        end)
    elseif p == 'esx' then
        n = safe(function()
            local x = esxPlayer(src)
            local it = x and x.getInventoryItem(name)
            return it and it.count or 0
        end)
    elseif p == 'custom' then
        n = safe(Custom.Inventory.Count, src, name)
    end
    return math.floor(tonumber(n) or 0)
end

function Inventory.Remove(src, name, count)
    count = math.floor(tonumber(count) or 0)
    if count <= 0 then return false end
    local p = Inventory.Provider()
    if p == 'ox_inventory' then
        return safe(function() return exports.ox_inventory:RemoveItem(src, name, count) end) == true
    elseif p == 'qbcore' then
        return safe(function() local pl = qbPlayer(src) return pl and pl.Functions.RemoveItem(name, count) end) == true
    elseif p == 'esx' then
        return safe(function()
            local x = esxPlayer(src)
            if not x then return false end
            x.removeInventoryItem(name, count)
            return true
        end) == true
    elseif p == 'custom' then
        return safe(Custom.Inventory.Remove, src, name, count) == true
    end
    return false
end

function Inventory.Add(src, name, count)
    count = math.floor(tonumber(count) or 0)
    if count <= 0 then return false end
    local p = Inventory.Provider()
    if p == 'ox_inventory' then
        local ok = safe(function() return (exports.ox_inventory:AddItem(src, name, count)) end)
        return ok == true or (type(ok) == 'table')
    elseif p == 'qbcore' then
        return safe(function() local pl = qbPlayer(src) return pl and pl.Functions.AddItem(name, count) end) == true
    elseif p == 'esx' then
        return safe(function()
            local x = esxPlayer(src)
            if not x then return false end
            if x.canCarryItem and not x.canCarryItem(name, count) then return false end
            x.addInventoryItem(name, count)
            return true
        end) == true
    elseif p == 'custom' then
        return safe(Custom.Inventory.Add, src, name, count) == true
    end
    return false
end
