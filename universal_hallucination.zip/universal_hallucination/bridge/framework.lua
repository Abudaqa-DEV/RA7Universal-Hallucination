--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/framework.lua - Framework adapter (Standalone / ESX / QBCore / Qbox / Custom).

    The hallucination engine never depends on a framework to work. The framework is only used for:
    a stable character id, job permissions, "busy" checks (dead/cuffed/jail) and "player loaded" events.
    If nothing is detected we run Standalone. Use Config.General.Framework = 'custom' + bridge/custom.lua
    for any other framework.
]]

Framework = {
    name  = 'standalone',
    ready = false,
}

local isServer = IsDuplicityVersion()

local function started(res)
    return GetResourceState(res) == 'started'
end

local function noop() end

-- ----------------------------------------------------------------------
-- Default (Standalone) implementation
-- ----------------------------------------------------------------------
local base = {}

if isServer then
    function base.GetIdentifier(src)
        local id = GetPlayerIdentifierByType and GetPlayerIdentifierByType(src, 'license') or nil
        if id then return id end
        for i = 0, GetNumPlayerIdentifiers(src) - 1 do
            local v = GetPlayerIdentifier(src, i)
            if v and v:sub(1, 8) == 'license:' then return v end
        end
        return nil
    end

    function base.GetJob() return nil, false end

    function base.IsBusy(src)
        local ped = GetPlayerPed(src)
        if not ped or ped == 0 then return false end
        return GetEntityHealth(ped) <= 0
    end

    base.RegisterLoadEvents = noop     -- standalone relies on the client "playerReady" signal
else
    function base.IsPlayerLoaded()
        return NetworkIsPlayerActive(PlayerId())
    end

    function base.IsBusy()
        return IsEntityDead(PlayerPedId())
    end

    function base.GetGender()
        return IsPedMale(PlayerPedId()) and 0 or 1
    end

    base.RegisterLoadEvents = noop
end

-- ----------------------------------------------------------------------
-- QBCore / Qbox (same PlayerData structure)
-- ----------------------------------------------------------------------
local function qbLike(name)
    local api = {}
    local core

    local function getCore()
        if not core then
            if name == 'qbox' then
                core = true
            else
                core = exports['qb-core']:GetCoreObject()
            end
        end
        return core
    end

    if isServer then
        local function getPlayer(src)
            if name == 'qbox' then return exports.qbx_core:GetPlayer(src) end
            return getCore().Functions.GetPlayer(src)
        end

        function api.GetIdentifier(src)
            local p = getPlayer(src)
            return p and p.PlayerData and p.PlayerData.citizenid or nil
        end

        function api.GetJob(src)
            local p = getPlayer(src)
            local j = p and p.PlayerData and p.PlayerData.job
            if j then return j.name, j.onduty ~= false end
            return nil, false
        end

        function api.IsBusy(src)
            local p = getPlayer(src)
            local m = p and p.PlayerData and p.PlayerData.metadata or {}
            if m.isdead or m.inlaststand or m.ishandcuffed then return true end
            if (tonumber(m.injail) or 0) > 0 then return true end
            return base.IsBusy(src)
        end


        function api.RegisterLoadEvents(onLoaded, onUnload)
            AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
                if Player and Player.PlayerData then onLoaded(Player.PlayerData.source) end
            end)
            AddEventHandler('QBCore:Server:OnPlayerUnload', function(src) onUnload(src) end)
        end
    else
        local function playerData()
            if name == 'qbox' then return exports.qbx_core:GetPlayerData() or {} end
            return getCore().Functions.GetPlayerData() or {}
        end

        function api.IsPlayerLoaded()
            return LocalPlayer.state.isLoggedIn == true
        end

        function api.IsBusy()
            local m = playerData().metadata or {}
            if m.isdead or m.inlaststand or m.ishandcuffed then return true end
            if (tonumber(m.injail) or 0) > 0 then return true end
            return IsEntityDead(PlayerPedId())
        end

        function api.GetGender()
            local info = playerData().charinfo or {}
            return tonumber(info.gender) or 0
        end

        function api.RegisterLoadEvents(onLoaded, onUnload)
            RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function() onLoaded() end)
            RegisterNetEvent('QBCore:Client:OnPlayerUnload', function() onUnload() end)
        end
    end

    return api
end

-- ----------------------------------------------------------------------
-- ESX
-- ----------------------------------------------------------------------
local function esx()
    local api = {}
    local ESX = exports['es_extended']:getSharedObject()

    if isServer then
        function api.GetIdentifier(src)
            local x = ESX.GetPlayerFromId(src)
            return x and x.identifier or nil
        end

        function api.GetJob(src)
            local x = ESX.GetPlayerFromId(src)
            if not x then return nil, false end
            local j = x.getJob and x.getJob() or x.job
            return j and j.name or nil, true
        end

        function api.IsBusy(src)
            return base.IsBusy(src)
        end


        function api.RegisterLoadEvents(onLoaded, onUnload)
            AddEventHandler('esx:playerLoaded', function(playerId) onLoaded(playerId) end)
            AddEventHandler('esx:playerDropped', function(playerId) onUnload(playerId) end)
        end
    else
        function api.IsPlayerLoaded()
            return ESX.IsPlayerLoaded()
        end

        function api.IsBusy()
            return IsEntityDead(PlayerPedId()) or LocalPlayer.state.dead == true
        end

        function api.GetGender()
            local data = ESX.GetPlayerData() or {}
            if data.sex == 'f' then return 1 end
            return 0
        end

        function api.RegisterLoadEvents(onLoaded, onUnload)
            RegisterNetEvent('esx:playerLoaded', function() onLoaded() end)
            RegisterNetEvent('esx:onPlayerLogout', function() onUnload() end)
        end
    end

    return api
end

-- ----------------------------------------------------------------------
-- Detection & initialisation
-- ----------------------------------------------------------------------
local RESOURCES = {
    qbox   = 'qbx_core',
    esx    = 'es_extended',
    qbcore = 'qb-core',
}

local AUTO_ORDER = { 'qbox', 'esx', 'qbcore' }

local function detect(want)
    if want == 'standalone' then return 'standalone' end
    if want == 'custom' then return 'custom' end

    if want == 'auto' then
        for _, n in ipairs(AUTO_ORDER) do
            if started(RESOURCES[n]) then return n end
        end
        return nil
    end

    local res = RESOURCES[want]
    if res and started(res) then return want end
    return nil
end

local function apply(adapter)
    for k, v in pairs(base) do Framework[k] = v end
    for k, v in pairs(adapter or {}) do Framework[k] = v end
end

local function customAdapter()
    local c = Custom and Custom.Framework or {}
    if isServer then
        return {
            GetIdentifier       = c.GetIdentifier,
            GetJob              = c.GetJob,
            IsBusy              = c.IsBusyServer,
            RegisterLoadEvents  = c.RegisterLoadEventsServer,
        }
    end
    return {
        IsPlayerLoaded      = c.IsPlayerLoaded,
        IsBusy              = c.IsBusy,
        GetGender           = c.GetGender,
        RegisterLoadEvents  = c.RegisterLoadEventsClient,
    }
end

--- Blocking (must run inside a thread). Detects and loads the adapter.
function Framework.Init()
    if Framework.ready then return Framework.name end

    local want = Config.General.Framework
    local name
    local waited = 0.0
    local limit = (want == 'auto') and 5.0 or 20.0

    while true do
        name = detect(want)
        if name or waited >= limit then break end
        Wait(500)
        waited = waited + 0.5
    end

    if not name then
        name = 'standalone'
        if want == 'auto' then
            Utils.Warn('No supported framework was detected (qbx_core / es_extended / qb-core). Running in STANDALONE mode.')
        else
            Utils.Warn(('Config.General.Framework = "%s" but that framework is not started. Running in STANDALONE mode.'):format(tostring(want)))
        end
    end

    local adapter
    if name == 'qbcore' or name == 'qbox' then
        local ok, res = pcall(qbLike, name)
        if ok then adapter = res else Utils.Warn('Failed to load the ' .. name .. ' adapter: ' .. tostring(res)); name = 'standalone' end
    elseif name == 'esx' then
        local ok, res = pcall(esx)
        if ok then adapter = res else Utils.Warn('Failed to load the ESX adapter: ' .. tostring(res)); name = 'standalone' end
    elseif name == 'custom' then
        adapter = customAdapter()
        -- remove nil entries so defaults stay in place
        for k, v in pairs(adapter) do if v == nil then adapter[k] = nil end end
    end

    Framework.name = name
    apply(adapter)
    Framework.ready = true
    return name
end

-- Make the table usable even before Init() (defaults)
apply(nil)
