--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/appearance.lua - clothing / appearance adapter (CLIENT).

    Needed ONLY for /hswap (the real look swap between two players). Copies of people (double / friend /
    ghost / gunman with Source = 'self' or 'subject') use ClonePed and need no clothing system at all.

    Providers (Config.Appearance.Provider): auto | illenium-appearance | fivem-appearance | custom_exports | custom | none
]]

Appearance = {}

local provider
local warned = {}

local function warnOnce(key, msg)
    if warned[key] then return end
    warned[key] = true
    Utils.Warn(msg)
end

local function started(res) return GetResourceState(res) == 'started' end

local function callExport(res, fn, ...)
    local ex = exports[res]
    return ex[fn](ex, ...)
end

local function resolve()
    local A = Config.Appearance
    local want = A.Provider

    if want == 'none' then return 'none' end

    if want == 'auto' then
        if started('illenium-appearance') then return 'illenium-appearance' end
        if started('fivem-appearance') then return 'fivem-appearance' end
        return 'none'
    end

    if want == 'illenium-appearance' or want == 'fivem-appearance' then
        if started(want) then return want end
        warnOnce('res', ('Config.Appearance.Provider = "%s" but that resource is not started. /hswap will be unavailable.'):format(want))
        return 'none'
    end

    if want == 'custom_exports' then
        local C = A.Custom or {}
        if type(C.Resource) == 'string' and C.Resource ~= '' and type(C.GetExport) == 'string' and C.GetExport ~= ''
            and type(C.ApplyExport) == 'string' and C.ApplyExport ~= '' and started(C.Resource) then
            return 'custom_exports'
        end
        warnOnce('ce', 'Config.Appearance.Provider = "custom_exports" but Resource / GetExport / ApplyExport are missing or the resource is not started. /hswap will be unavailable.')
        return 'none'
    end

    if want == 'custom' then
        local c = Custom and Custom.Appearance
        if type(c) == 'table' and type(c.Get) == 'function' and type(c.Apply) == 'function' then return 'custom' end
        warnOnce('cu', 'Config.Appearance.Provider = "custom" but Custom.Appearance.Get / Apply are not defined (bridge/custom.lua). /hswap will be unavailable.')
        return 'none'
    end

    warnOnce('unk', ('Unknown Config.Appearance.Provider "%s". /hswap will be unavailable.'):format(tostring(want)))
    return 'none'
end

function Appearance.Provider()
    provider = provider or resolve()
    return provider
end

--- Reads the appearance of a ped. Returns a table or nil.
function Appearance.Get(ped)
    local p = Appearance.Provider()
    local ok, res
    if p == 'illenium-appearance' or p == 'fivem-appearance' then
        ok, res = pcall(callExport, p, 'getPedAppearance', ped)
    elseif p == 'custom_exports' then
        local C = Config.Appearance.Custom
        ok, res = pcall(callExport, C.Resource, C.GetExport, ped)
    elseif p == 'custom' then
        ok, res = pcall(Custom.Appearance.Get, ped)
    else
        return nil
    end
    if ok and type(res) == 'table' then return res end
    if not ok then warnOnce('get', 'Appearance.Get failed: ' .. tostring(res)) end
    return nil
end

--- Applies an appearance table to a ped. Returns true when the provider accepted it.
function Appearance.Apply(ped, data)
    if type(data) ~= 'table' then return false end
    local p = Appearance.Provider()
    local ok, res
    if p == 'illenium-appearance' or p == 'fivem-appearance' then
        ok, res = pcall(callExport, p, 'setPedAppearance', ped, data)
    elseif p == 'custom_exports' then
        local C = Config.Appearance.Custom
        if C.ApplyArgs == 'data,ped' then
            ok, res = pcall(callExport, C.Resource, C.ApplyExport, data, ped)
        else
            ok, res = pcall(callExport, C.Resource, C.ApplyExport, ped, data)
        end
    elseif p == 'custom' then
        ok, res = pcall(Custom.Appearance.Apply, ped, data)
    else
        return false
    end
    if not ok then warnOnce('apply', 'Appearance.Apply failed: ' .. tostring(res)) return false end
    return res ~= false
end

--- Model hash of a ped (so the server can refuse swaps between different models).
function Appearance.Model(ped)
    return GetEntityModel(ped)
end
