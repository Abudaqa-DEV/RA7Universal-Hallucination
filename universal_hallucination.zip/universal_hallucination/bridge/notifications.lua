--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/notifications.lua - notification adapter (CLIENT).

    Providers: internal (own NUI) | ox_lib | esx | qbcore/qbox | custom | none | auto.
    Any external provider that is missing silently falls back to the internal one.
]]

Notify = {}

local provider = nil
local warned = {}

local function running(res)
    return GetResourceState(res) == 'started'
end

local function warnOnce(key, msg)
    if warned[key] then return end
    warned[key] = true
    Utils.Warn(msg)
end

local function resolve()
    local want = Config.Notifications.Provider

    if want == 'none' then return 'none' end
    if want == 'internal' then return 'internal' end

    if want == 'custom' then
        if Custom and type(Custom.Notify) == 'function' then return 'custom' end
        warnOnce('custom', 'Notifications.Provider = "custom" but Custom.Notify is not defined (bridge/custom.lua). Using the internal notifications.')
        return 'internal'
    end

    local function framework()
        if running('qbx_core') then return 'qbox' end
        if running('qb-core') then return 'qbcore' end
        if running('es_extended') then return 'esx' end
        return nil
    end

    if want == 'ox_lib' then
        if running('ox_lib') then return 'ox_lib' end
        warnOnce('ox_lib', 'Notifications.Provider = "ox_lib" but ox_lib is not started. Using the internal notifications.')
        return 'internal'
    end

    if want == 'qbcore' then
        local f = framework()
        if f == 'qbox' or f == 'qbcore' then return f end
        warnOnce('qb', 'Notifications.Provider = "qbcore" but QBCore/Qbox is not started. Using the internal notifications.')
        return 'internal'
    end

    if want == 'esx' then
        if running('es_extended') then return 'esx' end
        warnOnce('esx', 'Notifications.Provider = "esx" but ES Extended is not started. Using the internal notifications.')
        return 'internal'
    end

    if want == 'auto' then
        if running('ox_lib') then return 'ox_lib' end
        return framework() or 'internal'
    end

    warnOnce('unknown', ('Unknown Notifications.Provider "%s". Using the internal notifications.'):format(tostring(want)))
    return 'internal'
end

local OX_TYPES = { inform = 'inform', success = 'success', warning = 'warning', error = 'error' }
local QB_TYPES = { inform = 'primary', success = 'success', warning = 'warning', error = 'error' }

local function send(kind, message, ntype, duration)
    if kind == 'internal' then
        UI.Notify(message, ntype, duration)
    elseif kind == 'ox_lib' then
        exports.ox_lib:notify({
            title       = (Config.Brand.ScriptName or 'Universal Hallucination'),
            description = message,
            type        = OX_TYPES[ntype] or 'inform',
            duration    = duration,
            position    = Config.Notifications.OxPosition,
        })
    elseif kind == 'qbcore' then
        TriggerEvent('QBCore:Notify', message, QB_TYPES[ntype] or 'primary', duration)
    elseif kind == 'qbox' then
        exports.qbx_core:Notify(message, ntype, duration)
    elseif kind == 'esx' then
        TriggerEvent('esx:showNotification', message, ntype, duration)
    elseif kind == 'custom' then
        Custom.Notify(message, ntype, duration)
    end
end

---@param message string
---@param ntype? string 'inform' | 'success' | 'warning' | 'error'
---@param duration? number ms
function Notify.Send(message, ntype, duration)
    if not Config.General.EnableNotifications then return end

    message = tostring(message or '')
    if message == '' then return end

    ntype = OX_TYPES[ntype] and ntype or 'inform'
    duration = tonumber(duration) or Config.Notifications.Duration

    provider = provider or resolve()
    if provider == 'none' then return end

    local ok, err = pcall(send, provider, message, ntype, duration)
    if not ok then
        warnOnce('fail_' .. provider, ('Notification provider "%s" failed (%s). Falling back to internal notifications.'):format(provider, tostring(err)))
        provider = 'internal'
        pcall(send, 'internal', message, ntype, duration)
    end
end

--- Translate a locale key then notify.
function Notify.Key(key, ntype, duration, ...)
    Notify.Send(Locale(key, ...), ntype, duration)
end

function Notify.GetProvider()
    provider = provider or resolve()
    return provider
end
