--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    bridge/appearance_server.lua - asks a client for its appearance / tells it to apply one (SERVER).
    Request/response with a timeout; the callback always runs exactly once.
]]

AppearanceServer = {}

local pending = {}   -- [reqId] = { src, cb, done }
local nextId = 0

local function newId()
    nextId = nextId + 1
    return nextId
end

local function finish(id, ok, data, extra)
    local p = pending[id]
    if not p or p.done then return end
    p.done = true
    pending[id] = nil
    pcall(p.cb, ok, data, extra)
end

local function request(src, event, payload, cb)
    local id = newId()
    pending[id] = { src = src, cb = cb, done = false }
    TriggerClientEvent(event, src, id, payload)
    SetTimeout(math.floor(Utils.Num(Config.Appearance.ResponseTimeoutMs, 4000, 1000, 15000)), function()
        finish(id, false, nil, 'timeout')
    end)
end

--- Reads the appearance of the player. cb(ok, data, model)
function AppearanceServer.Get(src, cb)
    request(src, 'universal_halluc:client:appearanceGet', nil, cb)
end

--- Applies an appearance table on the player. cb(ok)
function AppearanceServer.Apply(src, data, cb)
    request(src, 'universal_halluc:client:appearanceApply', data, cb)
end

--- Called from the net event the client answers with.
function AppearanceServer.OnResponse(src, id, ok, data, extra)
    local p = pending[id]
    if not p or p.src ~= src then return false end   -- only the asked player can answer
    finish(id, ok == true, data, extra)
    return true
end
