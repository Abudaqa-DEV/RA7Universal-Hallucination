--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/main.lua - events from the server, ready signal, appearance requests and the admin panel.
]]

local EV = 'universal_halluc:client:'

-- ----------------------------------------------------------------------
-- Boot
-- ----------------------------------------------------------------------
CreateThread(function()
    Framework.Init()
    State.LoadOptOut()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(250) end
    local waited = 0
    while not Framework.IsPlayerLoaded() and waited < 120000 do Wait(500) waited = waited + 500 end
    UI.Init()
    State.ready = true
    TriggerServerEvent('universal_halluc:server:ready', State.optout)
end)

-- a character switch (multicharacter) loads a new character: tell the server again
if Framework.RegisterLoadEvents then
    Framework.RegisterLoadEvents(function()
        if State.ready then TriggerServerEvent('universal_halluc:server:ready', State.optout) end
    end, function()
        Engine.StopAll(false)
    end)
end

-- ----------------------------------------------------------------------
-- Session events
-- ----------------------------------------------------------------------
RegisterNetEvent(EV .. 'start', function(sid, typeKey, data)
    if type(sid) ~= 'number' or type(typeKey) ~= 'string' or type(data) ~= 'table' then return end
    Engine.Start(sid, typeKey, data)
end)

RegisterNetEvent(EV .. 'stop', function(sid)
    if type(sid) == 'number' then Engine.Stop(sid, false) end
end)

RegisterNetEvent(EV .. 'update', function(sid, intensity)
    if type(sid) == 'number' then Engine.Update(sid, intensity) end
end)

RegisterNetEvent(EV .. 'say', function(sid, text, seconds)
    if type(sid) == 'number' and type(text) == 'string' then Dialogue.Say(sid, text, seconds) end
end)

RegisterNetEvent(EV .. 'cue', function(name, seconds, intensity)
    if type(name) == 'string' then Cue.Run(name, seconds, intensity) end
end)

RegisterNetEvent(EV .. 'resistDone', function(sid, success, ended)
    Resist.Done(sid, success == true, ended == true)
end)

RegisterNetEvent(EV .. 'possessInfo', function(sid, on, target, name, seconds)
    if type(sid) == 'number' then Possessing.Info(sid, on == true, target, name, seconds) end
end)

RegisterNetEvent(EV .. 'possessCam', function(sid, x, y, z, rx, ry, rz, fov)
    if type(sid) == 'number' then Possessing.OnCam(sid, x, y, z, rx, ry, rz, fov) end
end)

RegisterNetEvent(EV .. 'notify', function(key, ntype, duration, ...)
    if type(key) == 'string' then Notify.Key(key, ntype, duration, ...) end
end)

RegisterNetEvent(EV .. 'optout', function(state)
    State.SaveOptOut(state == true)
end)

-- ----------------------------------------------------------------------
-- Appearance (only used by /hswap and /hpossess)
-- ----------------------------------------------------------------------
RegisterNetEvent(EV .. 'appearanceGet', function(id)
    if type(id) ~= 'number' then return end
    local ped = PlayerPedId()
    local data = Appearance.Get(ped)
    TriggerServerEvent('universal_halluc:server:appearanceData', id, data ~= nil, data, GetEntityModel(ped))
end)

RegisterNetEvent(EV .. 'appearanceApply', function(id, data)
    if type(id) ~= 'number' then return end
    local ok = type(data) == 'table' and Appearance.Apply(PlayerPedId(), data) or false
    TriggerServerEvent('universal_halluc:server:appearanceData', id, ok == true, nil, GetEntityModel(PlayerPedId()))
end)

-- ----------------------------------------------------------------------
-- Admin panel
-- ----------------------------------------------------------------------
local function openPanel()
    if not Config.Panel.Enabled or State.panel then return end
    TriggerServerEvent('universal_halluc:server:panelOpen')
end

if Config.Panel.Enabled and type(Config.Commands.Menu) == 'string' and Config.Commands.Menu ~= '' then
    RegisterCommand(Config.Commands.Menu, openPanel, false)
    if type(Config.Panel.Key) == 'string' and Config.Panel.Key ~= '' then
        RegisterKeyMapping(Config.Commands.Menu, Locale('panel_title'), 'keyboard', Config.Panel.Key)
    end
end

RegisterNetEvent(EV .. 'panelData', function(data, first)
    if type(data) ~= 'table' then return end
    if first then UI.PanelOpen(data) elseif State.panel then UI.Send('panelData', data) end
end)

RegisterNetEvent(EV .. 'panelResult', function(action, ok, message)
    UI.Send('panelResult', { action = action, ok = ok == true, message = message })
end)

RegisterNetEvent(EV .. 'panelLog', function(kind, from, text)
    UI.Send('panelLog', { kind = kind, from = from, text = text })
end)

local ACTIONS = {
    start = true, scenario = true, stop = true, direct = true, say = true, swap = true, restore = true,
    hide = true, solo = true, ghost = true, cue = true, adjust = true, appear = true, possess = true, unpossess = true,
    takeover_talk = true, takeover_seize = true, takeover_release = true, world_send = true, world_return = true, world_join = true,
    place_save = true, place_delete = true, zone_save = true, zone_delete = true, mind_add = true, mind_set = true, scene_save = true, scene_delete = true,
}

RegisterNUICallback('panelAction', function(data, cb)
    cb({ ok = true })
    if type(data) ~= 'table' or type(data.action) ~= 'string' or not ACTIONS[data.action] then return end
    TriggerServerEvent('universal_halluc:server:panel', data.action, type(data.payload) == 'table' and data.payload or {})
end)

RegisterNUICallback('panelRefresh', function(_, cb)
    cb({ ok = true })
    if State.panel then TriggerServerEvent('universal_halluc:server:panelRefresh') end
end)

RegisterNUICallback('panelClose', function(_, cb)
    cb({ ok = true })
    UI.PanelClose()
end)
