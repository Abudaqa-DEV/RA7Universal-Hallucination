--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/takeover.lua - the target's side of the "takeover by swapping" (see server/takeover.lua).

      takeover        the duel: rounds of the resist mini-game until the server decides
      takeover_ghost  after losing: frozen, invincible, unseen and unheard (except by the controller)
]]

local function owner(ctx) return ctx.id('to') end

Fx.Register('takeover', function(ctx)
    UI.Overlay(ctx.id('tint'), 'tint', true, { color = '#5A0000', strength = 0.35, pulse = true })
    UI.Overlay(ctx.id('vig'), 'vignette', true, { color = '#000000', strength = 0.6, pulse = true })
    UI.Sound(ctx.id('hb'), 'heartbeat', { loop = true, volume = 0.9, rate = 1.4, fade = 0.5 })
    UI.Flash('#FFFFFF', 160, 0.5)
    local o = owner(ctx)
    Visual.Shake(o, 'DRUNK_SHAKE', 0.2)
    ctx.onStop(function() Visual.ShakeOff(o) end)

    if not ctx.wait(1500) then return end
    while ctx.alive() do
        if not Resist.IsRunning() and not Helpers.IsDead() then
            Resist.Start(ctx)
            ctx.wait(800)
            while ctx.alive() and Resist.IsRunning() do ctx.wait(100) end
            if not ctx.wait(2200) then break end     -- the result stays on the screen for a moment
        else
            ctx.wait(300)
        end
    end
end)

Fx.Register('takeover_ghost', function(ctx)
    local K = Config.Takeover or {}
    local G = K.Ghost or {}
    local o = owner(ctx)
    local ped = PlayerPedId()

    UI.Send('possessHud', { on = true, role = 'ghost', seconds = ctx.left() })
    UI.Overlay(ctx.id('vig'), 'vignette', true, { color = '#0A1A33', strength = 0.35, pulse = false })
    Visual.Timecycle(o, 'NG_filmic02', 0.35)

    ctx.onStop(function()
        local p = PlayerPedId()
        FreezeEntityPosition(p, false)
        SetEntityInvincible(p, false)
        Visual.TimecycleOff(o)
        UI.Send('possessHud', { on = false })
    end)

    while ctx.alive() do
        ped = PlayerPedId()
        if G.Freeze ~= false then FreezeEntityPosition(ped, true) end
        if G.Invincible ~= false then SetEntityInvincible(ped, true) end
        DisableAllControlActions(0)
        EnableControlAction(0, 1, true)      -- look
        EnableControlAction(0, 2, true)
        EnableControlAction(0, 249, true)    -- push to talk
        EnableControlAction(0, 200, true)    -- pause menu
        Wait(0)
    end
end)
