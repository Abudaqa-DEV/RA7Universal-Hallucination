--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/people.lua - what THIS player sees of other players (everything is local, nobody else is affected).

      hide_player   the viewer does not see `subject` (a player)
      solo_visible  runs on everyone except the viewers and the subject: they do not see `subject`
      ghost_vision  the viewer sees other players translucent
      possess       the viewer watches through the controller's eyes, frozen and silent
]]

local function hideSubject(ctx)
    local sid = ctx.subject
    if not sid then return end
    local lastPed
    ctx.onStop(function()
        local pl = GetPlayerFromServerId(sid)
        if pl and pl ~= -1 then SetPlayerInvisibleLocally(pl, false) end
    end)
    while ctx.alive() do
        local pl = GetPlayerFromServerId(sid)
        if pl and pl ~= -1 then
            local ped = GetPlayerPed(pl)
            if ped and ped ~= 0 and DoesEntityExist(ped) then
                SetEntityLocallyInvisible(ped)
                SetPlayerInvisibleLocally(pl, true)
                -- his vehicle too, when he is the driver (otherwise an empty looking car drives by)
                local veh = GetVehiclePedIsIn(ped, false)
                if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then SetEntityLocallyInvisible(veh) end
                lastPed = ped
            end
            Wait(0)
        else
            Wait(500)   -- not streamed in yet
        end
    end
end

Fx.Register('hide_player', hideSubject)
Fx.Register('solo_visible', hideSubject)

Fx.Register('ghost_vision', function(ctx)
    local alpha = math.floor(Utils.Clamp(tonumber(ctx.opt('Alpha', 'alpha')) or 110, 0, 255))
    local range = tonumber(ctx.cfg.Range) or 120.0
    local touched = {}
    ctx.onStop(function()
        for ped in pairs(touched) do
            if DoesEntityExist(ped) then ResetEntityAlpha(ped) end
        end
    end)
    local me = PlayerId()
    while ctx.alive() do
        local px, py, pz = Helpers.Coords()
        for _, pl in ipairs(GetActivePlayers()) do
            if pl ~= me then
                local ped = GetPlayerPed(pl)
                if ped and ped ~= 0 and DoesEntityExist(ped) then
                    local c = GetEntityCoords(ped)
                    if Utils.Dist3(px, py, pz, c.x, c.y, c.z) <= range then
                        SetEntityAlpha(ped, alpha, false)
                        touched[ped] = true
                    elseif touched[ped] then
                        ResetEntityAlpha(ped)
                        touched[ped] = nil
                    end
                end
            end
        end
        ctx.wait(400)
    end
end)
