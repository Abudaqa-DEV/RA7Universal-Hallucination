--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/visual.lua - screen perception effects.

    Several sessions can use the same global thing (timecycle, shake, time scale): Visual keeps a stack per
    owner so one session ending never cancels another one that is still running.
]]

Visual = {}

local tc, shakes, posts, scales = {}, {}, {}, {}   -- owner -> value
local order = {}                                   -- timecycle owners in the order they started

local function removeFrom(list, owner)
    for i = #list, 1, -1 do
        if list[i] == owner then table.remove(list, i) end
    end
end

--- An owner like "s12:df" belongs to session 12. A late call from a thread of a session that has already ended
--- (a Wait() finished after the stop) must not leave a timecycle / shake / time scale behind.
local function stale(owner)
    if type(owner) ~= 'string' or not Engine then return false end
    local sid = owner:match('^s(%d+):')
    return sid ~= nil and Engine.sessions[tonumber(sid)] == nil
end

local function applyTimecycle()
    local top = order[#order]
    if not top then
        ClearTimecycleModifier()
        return
    end
    local e = tc[top]
    SetTimecycleModifier(e.name)
    SetTimecycleModifierStrength(Utils.Clamp(e.strength, 0.0, 1.0))
end

function Visual.Timecycle(owner, name, strength)
    if type(name) ~= 'string' or name == '' or stale(owner) then return end
    if not tc[owner] then order[#order + 1] = owner end
    tc[owner] = { name = name, strength = strength or 0.5 }
    applyTimecycle()
end

function Visual.TimecycleOff(owner)
    if not tc[owner] then return end
    tc[owner] = nil
    removeFrom(order, owner)
    applyTimecycle()
end

local function applyShake()
    local bestName, best = nil, 0.0
    for _, e in pairs(shakes) do
        if e.amp >= best then best, bestName = e.amp, e.name end
    end
    if not bestName then
        StopGameplayCamShaking(true)
        return
    end
    ShakeGameplayCam(bestName, best)
end

function Visual.Shake(owner, name, amplitude)
    if stale(owner) then return end
    shakes[owner] = { name = name or 'HAND_SHAKE', amp = Utils.Clamp(amplitude or 0.2, 0.0, 3.0) }
    applyShake()
end

function Visual.ShakeOff(owner)
    if not shakes[owner] then return end
    shakes[owner] = nil
    applyShake()
end

--- One short camera shake that does not interfere with the stack.
function Visual.Kick(name, amplitude)
    ShakeGameplayCam(name or 'SMALL_EXPLOSION_SHAKE', Utils.Clamp(amplitude or 0.2, 0.0, 3.0))
    SetTimeout(450, function() applyShake() end)
end

function Visual.PostFx(owner, name)
    if type(name) ~= 'string' or name == '' or stale(owner) then return end
    posts[owner] = name
    AnimpostfxPlay(name, 0, true)
end

function Visual.PostFxOff(owner)
    local name = posts[owner]
    if not name then return end
    posts[owner] = nil
    for _, n in pairs(posts) do if n == name then return end end   -- another owner still uses it
    AnimpostfxStop(name)
end

local function applyScale()
    local m = 1.0
    for _, v in pairs(scales) do if v < m then m = v end end
    SetTimeScale(Utils.Clamp(m, Config.Safety.TimeScaleMin, 1.0))
end

function Visual.TimeScale(owner, scale)
    if not Config.Safety.AllowTimeScale or stale(owner) then return end
    scales[owner] = scale
    applyScale()
end

function Visual.TimeScaleOff(owner)
    if scales[owner] == nil then return end
    scales[owner] = nil
    applyScale()
end

function Visual.Reset()
    tc, shakes, posts, scales, order = {}, {}, {}, {}, {}
    ClearTimecycleModifier()
    StopGameplayCamShaking(true)
    SetTimeScale(1.0)
end

-- ----------------------------------------------------------------------
-- Handlers
-- ----------------------------------------------------------------------
local function owner(ctx) return 'v' .. ctx.sid end

--- Common start/stop for a timecycle effect that pulses with the intensity.
local function timecycleFx(ctx, name, base, pulse)
    local o = owner(ctx)
    local strength = function() return Utils.Clamp(base * (0.35 + 0.9 * ctx.intensity), 0.05, 1.0) end
    Visual.Timecycle(o, name, strength())
    ctx.onStop(function() Visual.TimecycleOff(o) end)
    local t = 0.0
    while ctx.alive() do
        t = t + 0.1
        local k = strength()
        if pulse then k = k * (0.75 + 0.25 * math.sin(t * 0.9)) end
        Visual.Timecycle(o, name, k)
        Wait(100)
    end
end

Fx.Register('distortion', function(ctx)
    timecycleFx(ctx, ctx.cfg.Timecycle or 'drug_wobbly', 1.0, ctx.cfg.Pulse ~= false)
end)

Fx.Register('double_vision', function(ctx)
    timecycleFx(ctx, ctx.cfg.Timecycle or 'drug_drive_blend01', 0.9, true)
end)

Fx.Register('acid_trip', function(ctx)
    local o = owner(ctx)
    local list = ctx.cfg.Timecycles
    if type(list) ~= 'table' or #list == 0 then list = { 'drug_flying_01' } end
    ctx.onStop(function() Visual.TimecycleOff(o) Visual.PostFxOff(o) Visual.ShakeOff(o) end)
    Visual.PostFx(o, ctx.cfg.PostFX)
    Visual.Shake(o, 'DRUNK_SHAKE', 0.08 + 0.25 * ctx.intensity)
    UI.Overlay(ctx.id('acid'), 'acid', true, { color = ctx.opt('Tint', 'color') or '#7B2FF7', strength = ctx.intensity })
    local every = math.max(3.0, tonumber(ctx.cfg.CycleSeconds) or 14.0)
    local i = 1
    while ctx.alive() do
        Visual.Timecycle(o, list[i], Utils.Clamp(0.4 + 0.6 * ctx.intensity, 0.1, 1.0))
        i = i % #list + 1
        ctx.wait(math.floor(every * 1000))
    end
end)

Fx.Register('tunnel_vision', function(ctx)
    local id = ctx.id('tunnel')
    ctx.live(function() UI.Overlay(id, 'vignette', true, { strength = 0.45 + 0.5 * ctx.intensity, pulse = ctx.cfg.Pulse ~= false }) end)
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('flicker', function(ctx)
    local I = Helpers.IScale(ctx.intensity)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, 7.0, 1.0 / I) * 1000)) then break end
        local n = (math.random() < ctx.intensity) and 2 or 1
        for _ = 1, n do
            UI.Flash(ctx.opt('Color', 'color') or '#000000', math.floor(Utils.Range(ctx.cfg.Length, 150)), 1.0)
            Wait(math.random(120, 300))
        end
    end
end)

Fx.Register('bugs', function(ctx)
    local id = ctx.id('bugs')
    ctx.live(function() UI.Overlay(id, 'bugs', true, { count = math.floor((tonumber(ctx.cfg.Count) or 60) * Helpers.IScale(ctx.intensity)), color = ctx.opt('Color', 'color') or '#120C08' }) end)
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('blood', function(ctx)
    ctx.live(function() UI.Overlay(ctx.id('blood'), 'blood', true, { strength = 0.35 + 0.65 * ctx.intensity, color = Config.UI.BloodColor }) end)
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('tint', function(ctx)
    local id = ctx.id('tint')
    ctx.live(function() UI.Overlay(id, 'tint', true, { color = ctx.opt('Color', 'color') or '#8B0000', strength = 0.2 + 0.5 * ctx.intensity, pulse = ctx.cfg.Pulse ~= false }) end)
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('words', function(ctx)
    local pool = Utils.Pool(ctx.cfg.Pool or 'Whispers')
    if #pool == 0 then return end
    local I = Helpers.IScale(ctx.intensity)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, 8.0, 1.0 / I) * 1000)) then break end
        UI.Word(Utils.Pick(pool), math.random(12, 88) / 100.0, math.random(14, 82) / 100.0, math.random(1800, 3200), math.random(22, 54))
    end
end)

Fx.Register('camera_sway', function(ctx)
    local o = owner(ctx)
    ctx.onStop(function() Visual.ShakeOff(o) end)
    while ctx.alive() do
        Visual.Shake(o, ctx.cfg.Shake or 'DRUNK_SHAKE', 0.05 + 0.5 * ctx.intensity)
        ctx.wait(2000)
    end
end)

Fx.Register('time_slow', function(ctx)
    if not Config.Safety.AllowTimeScale then return end
    local o = owner(ctx)
    ctx.onStop(function() Visual.TimeScaleOff(o) end)
    local depth = 1.0 - 0.55 * ctx.intensity
    local t = 0.0
    while ctx.alive() do
        t = t + 0.15
        local k = 0.5 + 0.5 * math.sin(t)                 -- 0..1
        Visual.TimeScale(o, 1.0 - (1.0 - depth) * k)
        Wait(120)
    end
end)

Fx.Register('fake_notify', function(ctx)
    local pool = Utils.Pool(ctx.cfg.Pool or 'FakeNotify')
    if #pool == 0 then return end
    local I = Helpers.IScale(ctx.intensity)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, 25.0, 1.0 / I) * 1000)) then break end
        Notify.Send(Utils.Pick(pool), 'inform')
        UI.Sound(ctx.id('notif'), 'notify', { volume = 0.5 })
    end
end)
