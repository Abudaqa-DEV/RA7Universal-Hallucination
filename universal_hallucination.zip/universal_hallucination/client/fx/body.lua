--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/body.lua - the body: weapon tremor, hand tremor, dizziness.
]]

local function owner(ctx) return 'b' .. ctx.sid end

--- Smooth pseudo-random sway (sum of sines) in -1..1.
local function noise(t, a, b)
    return (math.sin(t * a) + math.sin(t * b + 1.7) * 0.6) / 1.6
end

Fx.Register('weapon_tremor', function(ctx)
    local o = owner(ctx)
    ctx.onStop(function() Visual.ShakeOff(o) end)
    local cfg = ctx.cfg
    local shaking = false
    local prevH, prevP = 0.0, 0.0
    local nextCheck = 0
    local armed, aiming = false, false

    while ctx.alive() do
        local ped = PlayerPedId()
        local t = GetGameTimer()
        if t >= nextCheck then
            nextCheck = t + 150
            armed = IsPedArmed(ped, 4)
            aiming = IsPlayerFreeAiming(PlayerId())
            local want = 0.0
            if armed or cfg.OnlyWhenArmed == false then
                want = (tonumber(cfg.Amplitude) or 0.35) * (0.4 + ctx.intensity) * (aiming and 1.4 or 0.7)
            else
                want = tonumber(cfg.UnarmedAmplitude) or 0.0
            end
            if want > 0.01 then
                Visual.Shake(o, cfg.Shake or 'HAND_SHAKE', want)
                shaking = true
            elseif shaking then
                Visual.ShakeOff(o)
                shaking = false
            end
        end

        if aiming and armed and not Helpers.IsDead() then
            -- the crosshair drifts: apply the CHANGE of a smooth curve each frame (no permanent offset builds up)
            local sway = (tonumber(cfg.AimSway) or 0.6) * (0.3 + ctx.intensity)
            local s = t / 1000.0
            local h = noise(s, 2.3, 4.1) * sway * 0.35
            local p = noise(s, 1.9, 3.7) * sway * 0.25
            SetGameplayCamRelativeHeading(GetGameplayCamRelativeHeading() + (h - prevH))
            SetGameplayCamRelativePitch(GetGameplayCamRelativePitch() + (p - prevP), 0.2)
            prevH, prevP = h, p
            Wait(0)
        else
            prevH, prevP = 0.0, 0.0
            Wait(60)
        end
    end
end)

Fx.Register('hand_tremor', function(ctx)
    local o = owner(ctx)
    ctx.onStop(function() Visual.ShakeOff(o) end)
    ctx.live(function() Visual.Shake(o, ctx.cfg.Shake or 'HAND_SHAKE', (tonumber(ctx.cfg.Amplitude) or 0.25) * (0.4 + ctx.intensity)) end)
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('dizzy', function(ctx)
    local o = owner(ctx)
    local cfg = ctx.cfg
    local ped = PlayerPedId()
    local set = IsPedMale(ped) and cfg.ClipsetMale or cfg.ClipsetFemale
    local applied = false
    if type(set) == 'string' and set ~= '' and Helpers.LoadClipSet(set) then
        SetPedMovementClipset(ped, set, 0.4)
        applied = true
    end
    SetPedMotionBlur(ped, true)
    ctx.onStop(function()
        local p = PlayerPedId()
        if applied then ResetPedMovementClipset(p, 0.4) end
        SetPedMotionBlur(p, false)
        Visual.ShakeOff(o)
    end)
    ctx.live(function() Visual.Shake(o, cfg.Shake or 'DRUNK_SHAKE', 0.05 + 0.45 * ctx.intensity) end)

    local nextStumble = GetGameTimer() + math.floor(Utils.Range(cfg.StumbleEvery, 18.0) * 1000)
    while ctx.alive() do
        -- a vehicle or a new ped (after a model change) can reset the clipset: re-apply
        local p = PlayerPedId()
        if applied and p ~= ped then
            ped = p
            SetPedMovementClipset(ped, set, 0.4)
        end
        if Config.Safety.AllowRagdoll and GetGameTimer() >= nextStumble and not Helpers.InVehicle() and ctx.intensity > 0.5 then
            nextStumble = GetGameTimer() + math.floor(Utils.Range(cfg.StumbleEvery, 18.0) * 1000)
            SetPedToRagdoll(ped, 1200, 1200, 0, false, false, false)
        end
        ctx.wait(500)
    end
end)
