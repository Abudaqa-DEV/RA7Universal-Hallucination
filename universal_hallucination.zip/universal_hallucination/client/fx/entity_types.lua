--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/entity_types.lua - people and creatures only the target can see.

    All of them are LOCAL peds (Ents) that are harmless by construction. When a session is `controlled`
    (Director) the phantom stays, follows the player and speaks the controller's lines instead of vanishing.
]]

local function px() return Helpers.Coords() end

local function fadeIn(ped, alpha, ms)
    if not Ents.Exists(ped) then return end
    alpha = math.floor(alpha or 255)
    CreateThread(function()
        local steps = 6
        for i = 1, steps do
            if not Ents.Exists(ped) then return end
            Ents.Alpha(ped, alpha * i / steps)
            Wait(math.floor((ms or 360) / steps))
        end
    end)
end

local function look(ctx, x, y, z, h, alpha)
    local source = ctx.opt('Source', 'source') or 'model'
    return Ents.Look(ctx.sid, source, ctx.cfg.Models, ctx.subject, x, y, z, h, 0, ctx.params.model)
end

--- A short scare when something reaches the player.
local function reach(ctx, shake, blood)
    if shake and shake > 0 then Visual.Kick('SMALL_EXPLOSION_SHAKE', shake * (0.5 + ctx.intensity)) end
    if blood then UI.Flash(Config.UI.BloodColor, 160, 0.55) end
    UI.Sound(ctx.id('whoosh' .. math.random(1, 9999)), 'whoosh', { volume = 0.5 })
end

local function distTo(ped) return Ents.Distance(ped) end

local function faceMe(ped)
    local x, y = px()
    Ents.Face(ped, x, y)
end

--- Uniform "stays with the player" behaviour used by Director-controlled phantoms and `friend`.
local function followLoop(ctx, opts)
    opts = opts or {}
    local off = ctx.cfg.FollowOffset or { x = -0.9, y = -1.3, z = 0.0 }
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 255
    local ped
    local hidden = false
    local lastTask = 0
    local nextTalk = GetGameTimer() + math.floor(Utils.Range(ctx.cfg.AutoTalkEvery, 40.0) * 1000)
    local talking = false
    local hintOn = false

    local function spawnNear()
        local x, y, z, h = Helpers.PickSpot(4.0, 7.0, { behind = true, maxZDiff = 4.0 })
        if not x then return nil end
        local p = look(ctx, x, y, z, h, alpha)
        if p then fadeIn(p, alpha) end
        return p
    end

    ctx.onStop(function() if hintOn then UI.Hint('', '', false) end end)

    while ctx.alive() do
        local inVeh = Helpers.InVehicle()
        if inVeh and ctx.cfg.DisappearInVehicle ~= false then
            if ped then Ents.Delete(ctx.sid, ped) ped, ctx.phantom = nil, nil end
            hidden = true
            Wait(700)
        elseif Helpers.IsDead() then
            Wait(700)
        else
            if not Ents.Exists(ped) then
                if ctx.canSpawn() or (hidden and not Helpers.IsDead()) then
                    ped = spawnNear()
                    ctx.phantom = ped
                    hidden = false
                end
                Wait(900)
            else
                local d = distTo(ped)
                local now = GetGameTimer()
                if d > 40.0 then
                    -- the player teleported / drove away: bring the phantom back behind him
                    local x, y, z, h = Helpers.PickSpot(5.0, 8.0, { behind = true, maxZDiff = 4.0 })
                    if x then SetEntityCoordsNoOffset(ped, x, y, z, false, false, false) end
                elseif now - lastTask > 700 then
                    lastTask = now
                    local me = PlayerPedId()
                    local v = GetEntitySpeed(me)
                    local speed = (v < 2.5) and 1.0 or ((v < 5.0) and 2.0 or 3.0)
                    TaskFollowToOffsetOfEntity(ped, me, off.x, off.y, off.z, speed, -1, 1.2, true)
                end

                -- talk range hint + key
                local inRange = d <= (tonumber(ctx.cfg.TalkRange) or 3.0)
                local canTalk = inRange and not talking and not State.panel
                if Config.UI.TalkHint ~= false then
                    if canTalk ~= hintOn then
                        hintOn = canTalk
                        UI.Hint(ctx.controlled and Locale('ui_reply') or Locale('ui_talk'), ctx.cfg.TalkKeyLabel or 'E', canTalk)
                    end
                end
                if canTalk and IsControlJustPressed(0, tonumber(ctx.cfg.TalkKey) or 38) then
                    if ctx.controlled then
                        Dialogue.OpenReply(ctx.sid)
                    else
                        talking = true
                        faceMe(ped)
                        ctx.thread(function()
                            Dialogue.Run(ctx, ctx.opt('Dialogue', 'dialogue') or 'imaginary_friend')
                            talking = false
                            nextTalk = GetGameTimer() + math.floor(Utils.Range(ctx.cfg.AutoTalkEvery, 40.0) * 1000)
                        end)
                    end
                end
                if not ctx.controlled and ctx.cfg.AutoTalk and not talking and inRange and GetGameTimer() >= nextTalk then
                    talking = true
                    faceMe(ped)
                    ctx.thread(function()
                        Dialogue.Run(ctx, ctx.opt('Dialogue', 'dialogue') or 'imaginary_friend')
                        talking = false
                        nextTalk = GetGameTimer() + math.floor(Utils.Range(ctx.cfg.AutoTalkEvery, 40.0) * 1000)
                    end)
                end
                Wait(0)
            end
        end
    end
end

-- ----------------------------------------------------------------------
-- ghost
-- ----------------------------------------------------------------------
Fx.Register('ghost', function(ctx)
    if ctx.controlled then return followLoop(ctx) end
    local cfg = ctx.cfg
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 170
    local maxSpawns = math.max(1, math.floor((tonumber(cfg.MaxSpawns) or 6) * Helpers.IScale(ctx.intensity) * 0.8))
    local spawns = 0
    local failed = 0

    while ctx.alive() and spawns < maxSpawns do
        local appeared = false
        if ctx.canSpawn() then
            local range = Helpers.IsIndoors() and cfg.IndoorDistance or cfg.Distance
            local lo = type(range) == 'table' and range.min or 9.0
            local hi = type(range) == 'table' and range.max or 15.0
            -- it appears where the player can SEE it (Config.Types.ghost.SpawnAngle: 0 = straight ahead)
            local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 5.0, angle = cfg.SpawnAngle or { min = -70.0, max = 70.0 } })
            local ped = x and look(ctx, x, y, z, h, alpha)
            if ped then
                appeared = true
                failed = 0
                spawns = spawns + 1
                ctx.phantom = ped
                fadeIn(ped, alpha, tonumber(cfg.FadeInMs) or 900)
                if cfg.Whisper ~= false then UI.Sound(ctx.id('wh' .. spawns), 'whoosh', { volume = 0.25 }) end
                local lookTime, lastWalk = 0.0, 0
                local born = GetGameTimer()
                local life = Utils.Range(cfg.Lifetime, 25.0) * 1000.0
                local vanishNow = false
                local flicker = 0
                while ctx.alive() and Ents.Exists(ped) and not vanishNow and not Helpers.IsDead() and not (Config.Safety.NoEntitiesWhileDriving and Helpers.InVehicle()) do
                    local d = distTo(ped)
                    local looked = Helpers.IsLookingAt(ped, 26.0)
                    if looked then lookTime = lookTime + 0.12 else lookTime = math.max(0.0, lookTime - 0.04) end
                    faceMe(ped)
                    if GetGameTimer() - born >= life then
                        vanishNow = true
                    elseif cfg.VanishWhenLooked == true and lookTime >= (tonumber(cfg.LookSeconds) or 6.0) then
                        vanishNow = true
                    elseif d <= (tonumber(cfg.VanishDistance) or 1.8) then
                        reach(ctx, tonumber(cfg.Shake) or 0.25, false)
                        vanishNow = true
                    else
                        -- while it is stared at it stops and flickers; when the player looks away it takes steps closer
                        if looked and cfg.Flicker ~= false and GetGameTimer() > flicker then
                            flicker = GetGameTimer() + math.random(900, 2200)
                            CreateThread(function()
                                for _ = 1, 3 do
                                    if not Ents.Exists(ped) then return end
                                    Ents.Alpha(ped, alpha * 0.25)
                                    Wait(70)
                                    if not Ents.Exists(ped) then return end
                                    Ents.Alpha(ped, alpha)
                                    Wait(110)
                                end
                            end)
                        end
                        if cfg.Approach ~= false and not looked and GetGameTimer() - lastWalk > 600 then
                            lastWalk = GetGameTimer()
                            local mx, my, mz = Helpers.Coords()
                            TaskGoStraightToCoord(ped, mx, my, mz, tonumber(cfg.ApproachSpeed) or 1.0, 4000, GetEntityHeading(ped), 0.0)
                        elseif looked and (cfg.StopWhenLooked ~= false) then
                            ClearPedTasks(ped)
                        end
                    end
                    Wait(120)
                end
                if Ents.Exists(ped) then
                    UI.Sound(ctx.id('vanish'), 'whoosh', { volume = 0.35 })
                    Ents.FadeOut(ctx.sid, ped, 700)
                end
                ctx.phantom = nil
            end
        end
        if not appeared then
            -- no spot / model yet: try again soon instead of waiting a whole respawn period
            failed = failed + 1
            Utils.Debug('ghost: no spot or model, retry', failed)
            if not ctx.wait(1500) then break end
        elseif not ctx.wait(math.floor(Utils.Range(cfg.Respawn, 9.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
    end
    ctx.wait(ctx.left() * 1000)
end)

-- ----------------------------------------------------------------------
-- shadow: something crosses the corner of the eye
-- ----------------------------------------------------------------------
Fx.Register('shadow', function(ctx)
    local cfg = ctx.cfg
    local alpha = tonumber(cfg.Alpha) or 70
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(cfg.Interval, 14.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
        if ctx.canSpawn() then
            local lo = (cfg.Distance and cfg.Distance.min) or 7.0
            local hi = (cfg.Distance and cfg.Distance.max) or 12.0
            local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 4.0 })
            local ped = x and Ents.Look(ctx.sid, 'model', cfg.Models, nil, x, y, z, h, alpha, ctx.params.model)
            if ped then
                Ents.Alpha(ped, alpha)
                -- cross in front of the player, perpendicular to the view, then disappear
                local mx, my = px()
                local cam = Helpers.CamHeading()
                local side = (math.random() < 0.5) and 90.0 or -90.0
                local vx, vy = Helpers.HeadingVec((cam + side) % 360.0)
                local fx, fy = Helpers.HeadingVec(cam)
                local dist = Utils.Rand(lo, hi)
                local sx, sy = mx + fx * dist - vx * 8.0, my + fy * dist - vy * 8.0
                local ex, ey = mx + fx * dist + vx * 8.0, my + fy * dist + vy * 8.0
                local gz = Helpers.GroundZ(sx, sy, z) or z
                SetEntityCoordsNoOffset(ped, sx, sy, gz, false, false, false)
                local ez = Helpers.GroundZ(ex, ey, z) or z
                TaskGoStraightToCoord(ped, ex, ey, ez, tonumber(cfg.Speed) or 2.0, 6000, 0.0, 0.0)
                local untilT = GetGameTimer() + 5200
                while ctx.alive() and Ents.Exists(ped) and GetGameTimer() < untilT and Ents.Distance(ped) > 2.0 do Wait(100) end
                Ents.FadeOut(ctx.sid, ped, 300)
            end
        end
    end
end)

-- ----------------------------------------------------------------------
-- stalker (Weeping Angel): follows from behind, freezes when looked at
-- ----------------------------------------------------------------------
Fx.Register('stalker', function(ctx)
    if ctx.controlled then return followLoop(ctx) end
    local cfg = ctx.cfg
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 190
    local ped
    local lastWalk, frozenFor = 0, 0.0

    local function respawn()
        local want = tonumber(cfg.FollowDistance) or 7.0
        local x, y, z, h = Helpers.PickSpot(want, want + 3.0, { behind = true, maxZDiff = 4.0 })
        if not x then return nil end
        local p = look(ctx, x, y, z, h, alpha)
        if p then fadeIn(p, alpha) end
        return p
    end

    while ctx.alive() do
        if Helpers.InVehicle() or Helpers.IsDead() then
            if ped then Ents.Delete(ctx.sid, ped) ped = nil end
            Wait(800)
        elseif not Ents.Exists(ped) then
            ped = ctx.canSpawn() and respawn() or nil
            ctx.phantom = ped
            ctx.wait(ped and 400 or 1500)
        else
            local d = distTo(ped)
            local looked = Helpers.IsLookingAt(ped, 30.0)
            local want = (tonumber(cfg.FollowDistance) or 7.0) * (1.0 - 0.6 * ctx.intensity)
            faceMe(ped)
            if looked and cfg.FreezeWhenLooked ~= false then
                ClearPedTasks(ped)
                frozenFor = frozenFor + 0.1
                if frozenFor > 6.0 then
                    -- stared long enough: it slips away and comes back behind the player
                    Ents.FadeOut(ctx.sid, ped, 500)
                    ped, frozenFor = nil, 0.0
                    ctx.wait(math.floor(Utils.Rand(3000, 7000)))
                end
            else
                frozenFor = 0.0
                if d <= (tonumber(cfg.VanishDistance) or 2.0) then
                    reach(ctx, 0.2, false)
                    Ents.FadeOut(ctx.sid, ped, 300)
                    ped = nil
                    ctx.wait(math.floor(Utils.Rand(4000, 9000)))
                elseif d > want and GetGameTimer() - lastWalk > 500 then
                    lastWalk = GetGameTimer()
                    local mx, my, mz = Helpers.Coords()
                    TaskGoStraightToCoord(ped, mx, my, mz, tonumber(cfg.Speed) or 1.2, 3000, GetEntityHeading(ped), 0.0)
                elseif d <= want and GetGameTimer() - lastWalk > 500 then
                    lastWalk = GetGameTimer()
                    -- hovering at distance: creeps a little closer each time the player is not looking
                    local mx, my, mz = Helpers.Coords()
                    TaskGoStraightToCoord(ped, mx, my, mz, 0.6, 1200, GetEntityHeading(ped), 0.0)
                end
            end
            Wait(100)
        end
    end
end)

-- ----------------------------------------------------------------------
-- crowd
-- ----------------------------------------------------------------------
Fx.Register('crowd', function(ctx)
    local cfg = ctx.cfg
    local alpha = tonumber(cfg.Alpha) or 215
    local want = math.max(1, math.floor(Utils.Range(cfg.Count, 5.0, Helpers.IScale(ctx.intensity))))
    local list = {}
    local nextFace = 0

    local function add()
        local lo = (cfg.Radius and cfg.Radius.min) or 12.0
        local hi = (cfg.Radius and cfg.Radius.max) or 24.0
        local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 5.0 })
        local ped = x and Ents.Look(ctx.sid, 'model', cfg.Models, nil, x, y, z, h, 0, ctx.params.model)
        if ped then
            fadeIn(ped, alpha, 700)
            list[#list + 1] = ped
        end
    end

    while ctx.alive() do
        if ctx.canSpawn() then
            -- drop the ones that vanished / were deleted
            for i = #list, 1, -1 do if not Ents.Exists(list[i]) then table.remove(list, i) end end
            if #list < want then add() end
            if GetGameTimer() >= nextFace then
                nextFace = GetGameTimer() + 600
                local lim = tonumber(cfg.VanishWhenApproach) or 6.0
                for i = #list, 1, -1 do
                    local ped = list[i]
                    faceMe(ped)
                    if distTo(ped) <= lim then
                        Ents.FadeOut(ctx.sid, ped, 500)
                        table.remove(list, i)
                    end
                end
            end
        elseif Helpers.InVehicle() or Helpers.IsDead() then
            for i = #list, 1, -1 do Ents.Delete(ctx.sid, list[i]) end
            list = {}
        end
        Wait(#list < want and 700 or 200)
    end
end)

-- ----------------------------------------------------------------------
-- animals: things that run at the player and vanish before reaching him (zombie_horde: client/fx/realism.lua)
-- ----------------------------------------------------------------------
local function chargers(ctx, spec)
    local cfg = ctx.cfg
    local waves = spec.waves
    for wave = 1, waves do
        if not ctx.alive() then return end
        local count = math.max(1, math.floor(Utils.Range(cfg.Count, 4.0, Helpers.IScale(ctx.intensity)) / (spec.divide or 1)))
        local group = {}
        if ctx.canSpawn() then
            for _ = 1, count do
                local lo = (cfg.SpawnDistance and cfg.SpawnDistance.min) or (cfg.Distance and cfg.Distance.min) or 10.0
                local hi = (cfg.SpawnDistance and cfg.SpawnDistance.max) or (cfg.Distance and cfg.Distance.max) or 20.0
                local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 7.0 })
                local ped = x and Ents.Look(ctx.sid, 'model', cfg.Models, nil, x, y, z, h, 0, ctx.params.model)
                if ped then
                    fadeIn(ped, 255, 250)
                    group[#group + 1] = ped
                    if spec.groan then
                        local c = GetEntityCoords(ped)
                        Audio.PlayAt(ctx, math.random() < 0.5 and 'groan_1' or 'groan_2', c.x, c.y, 0.7)
                    end
                end
                Wait(math.random(80, 320))
            end
        end

        local deadline = GetGameTimer() + 26000
        local lastWalk = 0
        while ctx.alive() and #group > 0 and GetGameTimer() < deadline and not Helpers.IsDead() and not Helpers.InVehicle() do
            local doWalk = GetGameTimer() - lastWalk > 450
            if doWalk then lastWalk = GetGameTimer() end
            local mx, my, mz = Helpers.Coords()
            for i = #group, 1, -1 do
                local ped = group[i]
                if not Ents.Exists(ped) then
                    table.remove(group, i)
                else
                    local d = distTo(ped)
                    if d <= (tonumber(cfg.VanishDistance) or 1.5) then
                        reach(ctx, spec.shake and (tonumber(cfg.Shake) or 0.3) or 0.0, spec.blood and cfg.BloodFlash ~= false)
                        Ents.FadeOut(ctx.sid, ped, 200)
                        table.remove(group, i)
                    elseif doWalk then
                        TaskGoStraightToCoord(ped, mx, my, mz, tonumber(cfg.Speed) or 2.0, 2000, GetEntityHeading(ped), 0.0)
                    end
                end
            end
            Wait(60)
        end
        for _, ped in ipairs(group) do Ents.FadeOut(ctx.sid, ped, 300) end
        if wave < waves then
            if not ctx.wait(math.floor(Utils.Range(cfg.WaveGap, 10.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then return end
        end
    end
end

Fx.Register('animals', function(ctx)
    chargers(ctx, { waves = math.max(2, math.floor(4 * Helpers.IScale(ctx.intensity))), divide = 2, shake = false })
    ctx.wait(ctx.left() * 1000)
end)

-- ----------------------------------------------------------------------
-- gunman: points a weapon and "fires" - every shot misses and does 0 damage
-- ----------------------------------------------------------------------
local function loadWeapon(hash)
    if HasWeaponAssetLoaded(hash) then return true end
    RequestWeaponAsset(hash, 31, 26)
    local deadline = GetGameTimer() + 2500
    while not HasWeaponAssetLoaded(hash) do
        if GetGameTimer() > deadline then return false end
        Wait(20)
    end
    return true
end

local function fakeShot(ctx, ped, hash)
    local me = PlayerPedId()
    local mc = GetEntityCoords(me)
    local head = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
    -- the bullet passes beside the player (never at him) and does no damage at all; Realism.Fire refuses unsafe lines
    local miss = math.max(1.2, tonumber(ctx.cfg.MissBy) or 2.2)
    local fired = false
    for _ = 1, 2 do
        local ang = math.rad(Helpers.HeadingTo(head.x, head.y, mc.x, mc.y) + (math.random() < 0.5 and 90.0 or -90.0))
        local tx, ty = mc.x - math.sin(ang) * miss, mc.y + math.cos(ang) * miss
        fired = Realism.Fire(ctx, ped, hash, tx, ty, mc.z + Utils.Rand(0.8, 1.8), 'whiz')
        if fired then break end
    end
    if not fired then return end
    if ctx.cfg.Flash ~= false then UI.Flash('#FFFFFF', 70, 0.35) end
    Visual.Kick('SMALL_EXPLOSION_SHAKE', (tonumber(ctx.cfg.Shake) or 0.45) * (0.4 + ctx.intensity) * 0.5)
end

Fx.Register('gunman', function(ctx)
    local cfg = ctx.cfg
    local weapon = ctx.opt('Weapon', 'weapon') or 'WEAPON_PISTOL'
    local hash = joaat(weapon)
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 255
    if not loadWeapon(hash) then return end
    ctx.onStop(function() RemoveWeaponAsset(hash) end)

    local first = true
    while ctx.alive() do
        if ctx.canSpawn() then
            local lo = (cfg.Distance and cfg.Distance.min) or 6.0
            local hi = (cfg.Distance and cfg.Distance.max) or 11.0
            local x, y, z, h = Helpers.PickSpot(lo, hi, { front = first, maxZDiff = 4.0 })
            first = false
            local ped = x and look(ctx, x, y, z, h, alpha)
            if ped then
                ctx.phantom = ped
                fadeIn(ped, alpha, 300)
                GiveWeaponToPed(ped, hash, 0, true, true)      -- the weapon is only a prop: it has no ammo
                SetCurrentPedWeapon(ped, hash, true)
                faceMe(ped)
                local aim = math.floor(Utils.Range(cfg.AimSeconds, 3.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)
                TaskAimGunAtEntity(ped, PlayerPedId(), aim + 12000, true)
                if ctx.wait(aim) and Ents.Exists(ped) then
                    local shots = math.max(1, math.floor(Utils.Range(cfg.Shots, 2.0, Helpers.IScale(ctx.intensity) * 0.8)))
                    for _ = 1, shots do
                        if not (ctx.alive() and Ents.Exists(ped)) then break end
                        faceMe(ped)
                        fakeShot(ctx, ped, hash)
                        ctx.wait(math.floor(Utils.Range(cfg.ShotGap, 600.0)))
                    end
                end
                ctx.wait(700)
                Ents.FadeOut(ctx.sid, ped, 350)
                ctx.phantom = nil
            end
        end
        local gap = ctx.controlled and 7.0 or 14.0
        if not ctx.wait(math.floor(Utils.Rand(gap * 0.6, gap * 1.4) * 1000 / Helpers.IScale(ctx.intensity))) then break end
    end
end)

-- ----------------------------------------------------------------------
-- double: a copy of the player (or of another player) that stares / follows / mimics
-- ----------------------------------------------------------------------
Fx.Register('double', function(ctx)
    if ctx.controlled then return followLoop(ctx) end
    local cfg = ctx.cfg
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 210
    local behavior = ctx.opt('Behavior', 'behavior') or 'stare'
    local ped
    local lastWalk = 0
    local lookTime = 0.0

    local function spawn()
        local lo = (cfg.Distance and cfg.Distance.min) or 6.0
        local hi = (cfg.Distance and cfg.Distance.max) or 10.0
        local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 4.0 })
        if not x then return nil end
        local p = look(ctx, x, y, z, h, alpha)
        if p then fadeIn(p, alpha, 600) end
        return p
    end

    while ctx.alive() do
        if Helpers.InVehicle() or Helpers.IsDead() then
            if ped then Ents.Delete(ctx.sid, ped) ped = nil end
            Wait(800)
        elseif not Ents.Exists(ped) then
            ped = ctx.canSpawn() and spawn() or nil
            ctx.phantom = ped
            lookTime = 0.0
            ctx.wait(ped and 300 or 1500)
        else
            local me = PlayerPedId()
            local d = distTo(ped)
            local looked = Helpers.IsLookingAt(ped, 25.0)
            if looked then lookTime = lookTime + 0.12 end
            if behavior == 'mimic' then
                -- stands beside the player and turns when the player turns
                local mc = GetEntityCoords(me)
                local rx, ry = Helpers.HeadingVec((Helpers.CamHeading() - 90.0) % 360.0)
                local tx, ty = mc.x + rx * 1.6, mc.y + ry * 1.6
                if GetGameTimer() - lastWalk > 400 then
                    lastWalk = GetGameTimer()
                    if Utils.Dist2(tx, ty, GetEntityCoords(ped).x, GetEntityCoords(ped).y) > 0.8 then
                        TaskGoStraightToCoord(ped, tx, ty, mc.z, math.min(3.0, 1.0 + GetEntitySpeed(me) * 0.5), 1200, GetEntityHeading(me), 0.0)
                    else
                        SetEntityHeading(ped, GetEntityHeading(me))
                    end
                end
            elseif behavior == 'follow' then
                faceMe(ped)
                if d > 4.0 and GetGameTimer() - lastWalk > 500 then
                    lastWalk = GetGameTimer()
                    local mx, my, mz = Helpers.Coords()
                    TaskGoStraightToCoord(ped, mx, my, mz, tonumber(cfg.Speed) or 1.2, 3000, GetEntityHeading(ped), 0.0)
                end
            else
                faceMe(ped)
            end
            if d <= (tonumber(cfg.VanishDistance) or 1.5) or lookTime > 5.0 then
                reach(ctx, 0.1, false)
                Ents.FadeOut(ctx.sid, ped, 500)
                ped = nil
                ctx.phantom = nil
                ctx.wait(math.floor(Utils.Rand(5000, 11000) / Helpers.IScale(ctx.intensity)))
            end
            Wait(100)
        end
    end
end)

-- ----------------------------------------------------------------------
-- friend: a person only the player sees; they walk together and talk
-- ----------------------------------------------------------------------
Fx.Register('friend', function(ctx)
    followLoop(ctx)
end)
