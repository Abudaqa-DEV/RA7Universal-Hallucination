--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/realism.lua - the "real" layer: shooters with real peds and real bullets, near-death, scenes from the
    config, zombies with many peds and behaviours, insects, drunk, drowning, collapse.

    SAFETY (always): every bullet is fired with damage 0 and is checked against the player's body before it is
    fired (Realism.Fire): a shot whose line passes closer than Config.Realism.Gunfire.MinMiss (never below 1.0 m)
    to the head, the chest or the feet is NOT fired. Shooters have no ammo. Every ped is local (not networked).
]]

Realism = {}

local function R() return Config.Realism end
local function IS(ctx) return Helpers.IScale(ctx.intensity) end

-- ----------------------------------------------------------------------
-- Safe bullets
-- ----------------------------------------------------------------------

--- Distance of point P from the ray that starts at O and passes through T (the bullet keeps flying past T).
function Realism.RayDistance(ox, oy, oz, tx, ty, tz, px, py, pz)
    local dx, dy, dz = tx - ox, ty - oy, tz - oz
    local len2 = dx * dx + dy * dy + dz * dz
    if len2 < 0.0001 then return Utils.Dist3(ox, oy, oz, px, py, pz) end
    local t = ((px - ox) * dx + (py - oy) * dy + (pz - oz) * dz) / len2
    if t < 0.0 then t = 0.0 end
    return Utils.Dist3(px, py, pz, ox + dx * t, oy + dy * t, oz + dz * t)
end

--- Is a bullet along O -> T safe for the player? (never closer than MinMiss to head / chest / feet)
function Realism.IsSafeShot(ox, oy, oz, tx, ty, tz)
    local G = R().Gunfire or {}
    local minMiss = Utils.Clamp(Utils.Num(G.MinMiss, 1.2, 1.0, 6.0), 1.0, 6.0)
    local me = PlayerPedId()
    if Helpers.InVehicle() then minMiss = minMiss + 1.5 end
    local c = GetEntityCoords(me)
    local head = GetPedBoneCoords(me, 31086, 0.0, 0.0, 0.0)
    local pts = { { c.x, c.y, c.z }, { head.x, head.y, head.z }, { c.x, c.y, c.z - 0.9 } }
    for i = 1, #pts do
        local p = pts[i]
        if Realism.RayDistance(ox, oy, oz, tx, ty, tz, p[1], p[2], p[3]) < minMiss then return false end
    end
    return true
end

local function muzzleName(hash)
    local g = GetWeapontypeGroup(hash)
    if g == 416676503 then return 'muz_pistol' end        -- pistols
    if g == 860033945 then return 'muz_shotgun' end       -- shotguns
    if g == 3337201093 then return 'muz_smg' end          -- smg
    return 'muz_assault_rifle'
end

local ptfxReady = false
local function muzzleFlash(ped, hash)
    if not (R().Gunfire or {}).MuzzleFlash then return end
    pcall(function()
        if not ptfxReady then
            RequestNamedPtfxAsset('core')
            local t = GetGameTimer() + 800
            while not HasNamedPtfxAssetLoaded('core') and GetGameTimer() < t do Wait(0) end
            ptfxReady = HasNamedPtfxAssetLoaded('core')
        end
        if not ptfxReady then return end
        local w = GetCurrentPedWeaponEntityIndex(ped)
        if not w or w == 0 then return end
        UseParticleFxAsset('core')
        StartParticleFxNonLoopedOnEntity(muzzleName(hash), w, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, false, false, false)
    end)
end

local function gunSample(hash)
    local g = GetWeapontypeGroup(hash)
    if g == 860033945 then return 'gunshot_shotgun' end
    if g == 416676503 then return 'gunshot' end
    return 'gunshot_rifle'
end

--- Fires ONE harmless bullet from `ped` towards (tx, ty, tz). Returns true when it was fired.
--- kind: 'whiz' | 'impact' | 'wild' (only changes which sound is added)
function Realism.Fire(ctx, ped, hash, tx, ty, tz, kind)
    if not Ents.Exists(ped) then return false end
    local o = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
    local fx, fy, fz = o.x, o.y, o.z - 0.25
    local w = GetCurrentPedWeaponEntityIndex(ped)
    if w and w ~= 0 then
        local m = GetEntityCoords(w)
        fx, fy, fz = m.x, m.y, m.z
    end
    if not Realism.IsSafeShot(fx, fy, fz, tx, ty, tz) then return false end
    local mode = (R().Gunfire or {}).Sound or 'both'
    muzzleFlash(ped, hash)
    ShootSingleBulletBetweenCoords(fx, fy, fz, tx, ty, tz, 0, true, hash, ped, mode ~= 'sample', false, 2800.0)
    if mode ~= 'game' then Audio.PlayAt(ctx, gunSample(hash), fx, fy, 1.0) end
    if kind == 'impact' then
        SetTimeout(math.random(60, 140), function()
            if ctx.alive() then Audio.PlayAt(ctx, 'ricochet', tx, ty, 0.55) end
        end)
    end
    return true
end

--- A shot that passes the player's head from a side and climbs away (so it never travels along the ground).
local function whizTarget(ped)
    local me = PlayerPedId()
    local head = GetPedBoneCoords(me, 31086, 0.0, 0.0, 0.0)
    local o = GetEntityCoords(ped)
    local side = (math.random() < 0.5 and 1.0 or -1.0) * Utils.Rand(1.4, 2.6)
    local h = math.rad(Helpers.HeadingTo(o.x, o.y, head.x, head.y))
    local rx, ry = math.cos(h), math.sin(h)           -- perpendicular to the line of fire
    return head.x + rx * side, head.y + ry * side, head.z + Utils.Rand(1.2, 2.4)
end

--- A shot that lands on the ground a few metres from the player (dust, decals).
local function impactTarget()
    local px, py, pz = Helpers.Coords()
    local ang = math.rad(Utils.Rand(0.0, 360.0))
    local d = Utils.Rand(2.6, 7.0)
    local x, y = px + math.cos(ang) * d, py + math.sin(ang) * d
    return x, y, (Helpers.GroundZ(x, y, pz) or (pz - 1.0)) - 0.05
end

-- ----------------------------------------------------------------------
-- Movement helpers (own ped)
-- ----------------------------------------------------------------------

--- Falls to the ground (ragdoll) for a few seconds. Only when walking on the ground.
function Realism.Ragdoll(seconds)
    local me = PlayerPedId()
    if IsPedInAnyVehicle(me, false) or IsPedSwimming(me) or IsPedFalling(me) or IsPedClimbing(me)
        or IsPedOnVehicle(me) or IsPedDeadOrDying(me, true) then return false end
    local ms = math.floor(Utils.Clamp(seconds or 3.0, 0.5, 8.0) * 1000)
    SetPedToRagdoll(me, ms, ms, 0, false, false, false)
    return true
end

local function applyClipset(set)
    if type(set) ~= 'string' or set == '' then return false end
    if not Helpers.LoadClipSet(set) then return false end
    SetPedMovementClipset(PlayerPedId(), set, 0.4)
    return true
end

local function resetClipset()
    pcall(ResetPedMovementClipset, PlayerPedId(), 0.4)
    pcall(ResetPedWeaponMovementClipset, PlayerPedId())
end

local function dressWounds(ped, packs, count)
    if type(packs) ~= 'table' or #packs == 0 then return end
    for _ = 1, count do
        pcall(ApplyPedDamagePack, ped, Utils.Pick(packs), 0.0, 1.0)
    end
end

local function fadeIn(ped, alpha, ms)
    if not Ents.Exists(ped) then return end
    CreateThread(function()
        local steps = 6
        for i = 1, steps do
            if not Ents.Exists(ped) then return end
            Ents.Alpha(ped, (alpha or 255) * i / steps)
            Wait(math.floor((ms or 360) / steps))
        end
    end)
end

local function reach(ctx, shake, blood)
    if shake and shake > 0 then Visual.Kick('SMALL_EXPLOSION_SHAKE', shake * (0.5 + ctx.intensity)) end
    if blood then UI.Flash(Config.UI.BloodColor, 160, 0.55) end
    UI.Sound(ctx.id('whoosh' .. math.random(1, 9999)), 'whoosh', { volume = 0.5 })
end

local function groundAt(x, y, z) return Helpers.GroundZ(x, y, z) or z end

-- ----------------------------------------------------------------------
-- ZOMBIES: many peds, six behaviours, wounds, falls
-- ----------------------------------------------------------------------
local function pickVariant(Z)
    local total = 0
    for _, v in pairs(Z.Variants or {}) do total = total + math.max(0, tonumber(v.Weight) or 0) end
    if total <= 0 then return 'walker', { Speed = 1.0 } end
    local r = math.random() * total
    for name, v in pairs(Z.Variants) do
        r = r - math.max(0, tonumber(v.Weight) or 0)
        if r <= 0 then return name, v end
    end
    return 'walker', Z.Variants.walker or { Speed = 1.0 }
end

local function setupZombie(ctx, ped, name, v, Z)
    pcall(SetPedCanRagdoll, ped, name == 'faller')
    if Z.RandomLook ~= false then pcall(SetPedRandomComponentVariation, ped, 0) end
    dressWounds(ped, Z.Wounds, math.max(1, math.floor(Utils.Range(Z.WoundCount, 2.0))))
    -- blood on the face / chest / arms (zones: 0 head, 1 torso, 2-5 limbs) and a sick facial expression
    for _ = 1, math.max(0, math.floor(Utils.Range(Z.BloodSplats, 3.0))) do
        pcall(ApplyPedBlood, ped, math.random(0, 5), Utils.Rand(-1.0, 1.0), Utils.Rand(-1.0, 1.0), Utils.Rand(-1.0, 1.0), Utils.Pick({ 'wound_sheet', 'cs_flush_anger', 'BasicSlash' }))
    end
    if Z.SickFace ~= false then pcall(SetFacialIdleAnimOverride, ped, Utils.Pick({ 'mood_injured_1', 'mood_stressed_1', 'mood_angry_1' }), 0) end
    pcall(SetPedMoveRateOverride, ped, Utils.Rand(0.92, 1.12))
    if v.Clipset and v.Clipset ~= '' and Helpers.LoadClipSet(v.Clipset, 1500) then
        pcall(SetPedMovementClipset, ped, v.Clipset, 0.2)
    end
    if v.Anim and Helpers.LoadAnimDict(v.Anim.dict, 1500) then
        TaskPlayAnim(ped, v.Anim.dict, v.Anim.name, 8.0, -8.0, -1, v.Anim.flag or 1, 0.0, false, false, false)
    elseif v.Scenario then
        TaskStartScenarioInPlace(ped, v.Scenario, 0, true)
    end
end

Fx.Register('zombie_horde', function(ctx)
    local cfg = ctx.cfg
    local Z = R().Zombies or {}
    local models = (type(Z.Models) == 'table' and #Z.Models > 0) and Z.Models or cfg.Models
    local waves = math.max(1, math.floor((tonumber(cfg.Waves) or 3) * IS(ctx) * 0.8 + 0.5))
    local vanishD = tonumber(cfg.VanishDistance) or 1.7

    for wave = 1, waves do
        if not ctx.alive() then return end
        local group = {}
        if ctx.canSpawn() then
            local count = math.max(1, math.floor(Utils.Range(cfg.Count, 5.0, IS(ctx))))
            for _ = 1, count do
                local vname, v = pickVariant(Z)
                local lo = (cfg.SpawnDistance and cfg.SpawnDistance.min) or 22.0
                local hi = (cfg.SpawnDistance and cfg.SpawnDistance.max) or 38.0
                if vname == 'lurker' then lo, hi = 12.0, 22.0 end
                local x, y, z, h = Helpers.PickSpot(lo, hi, { maxZDiff = 7.0 })
                local ped = x and Ents.Look(ctx.sid, 'model', models, nil, x, y, z, h, 0, ctx.params.model)
                if ped then
                    setupZombie(ctx, ped, vname, v, Z)
                    fadeIn(ped, 255, 250)
                    group[#group + 1] = { ped = ped, name = vname, v = v, awake = vname ~= 'lurker', nextWalk = 0, fell = false, ragdollUntil = 0 }
                    if cfg.Groans ~= false then
                        local c = GetEntityCoords(ped)
                        Audio.PlayAt(ctx, math.random() < 0.5 and 'groan_1' or 'groan_2', c.x, c.y, 0.7)
                    end
                end
                Wait(math.random(80, 320))
            end
        end

        local deadline = GetGameTimer() + math.floor((tonumber(cfg.WaveSeconds) or 28.0) * 1000)
        local last = GetGameTimer()
        local seen = false
        while ctx.alive() and #group > 0 and GetGameTimer() < deadline and not Helpers.IsDead() and not Helpers.InVehicle() do
            local now = GetGameTimer()
            local dt = math.min(0.2, (now - last) / 1000.0)
            last = now
            local mx, my, mz = Helpers.Coords()
            for i = #group, 1, -1 do
                local z = group[i]
                local ped = z.ped
                if not Ents.Exists(ped) then
                    table.remove(group, i)
                else
                    local d = Ents.Distance(ped)
                    local c = GetEntityCoords(ped)
                    -- the first moment the player truly sees one: heartbeat, red edge, groan (the fear of "they are real")
                    if not seen and cfg.SightScare ~= false and d < 30.0 and Helpers.IsLookingAt(ped, 40.0) then
                        seen = true
                        UI.Flash(Config.UI.BloodColor, 140, 0.3)
                        UI.Sound(ctx.id('see' .. wave), 'heartbeat', { volume = 0.8, rate = 1.3 })
                        Audio.PlayAt(ctx, 'groan_2', c.x, c.y, 0.9)
                        Visual.Kick('HAND_SHAKE', 0.25 * (0.5 + ctx.intensity))
                    end
                    if d <= vanishD * (z.name == 'crawler' and 1.3 or 1.0) then
                        reach(ctx, tonumber(cfg.Shake) or 0.3, cfg.BloodFlash ~= false)
                        Ents.FadeOut(ctx.sid, ped, 200)
                        table.remove(group, i)
                    elseif z.name == 'lurker' and not z.awake then
                        -- stands swaying and stares until the player comes close, then rushes
                        TaskLookAtEntity(ped, PlayerPedId(), 1500, 2048, 3)
                        if d <= (tonumber(z.v.WakeDistance) or 11.0) then
                            z.awake = true
                            ClearPedTasksImmediately(ped)
                            Audio.PlayAt(ctx, 'groan_2', c.x, c.y, 0.9)
                            UI.Flash(Config.UI.BloodColor, 90, 0.25)
                        end
                    elseif z.name == 'crawler' then
                        -- crawls along the ground (moved by script, the ped lies in the writhing animation)
                        local hd = Helpers.HeadingTo(c.x, c.y, mx, my)
                        local vx, vy = Helpers.HeadingVec(hd)
                        local sp = (tonumber(z.v.Speed) or 0.9) * dt
                        local nx, ny = c.x + vx * sp, c.y + vy * sp
                        SetEntityHeading(ped, hd)
                        SetEntityCoordsNoOffset(ped, nx, ny, groundAt(nx, ny, c.z) + 0.05, false, false, false)
                    elseif now >= z.ragdollUntil then
                        if z.name == 'faller' and not z.fell and d < 20.0 and d > 5.0 and math.random() < 0.012 * (tonumber(z.v.FallChance) or 0.8) then
                            z.fell = true
                            local secs = Utils.Range(z.v.FallSeconds, 2.5)
                            z.ragdollUntil = now + math.floor(secs * 1000)
                            SetPedToRagdoll(ped, math.floor(secs * 1000), math.floor(secs * 1000), 0, false, false, false)
                            Audio.PlayAt(ctx, 'thump', c.x, c.y, 0.7)
                        elseif now >= z.nextWalk then
                            z.nextWalk = now + 450
                            TaskGoStraightToCoord(ped, mx, my, mz, tonumber(z.v.Speed) or 1.0, 2000, GetEntityHeading(ped), 0.0)
                        end
                    end
                end
            end
            Wait(60)
        end
        for _, z in ipairs(group) do Ents.FadeOut(ctx.sid, z.ped, 300) end
        if wave < waves then
            if not ctx.wait(math.floor(Utils.Range(cfg.WaveGap, 10.0, 1.0 / IS(ctx)) * 1000)) then return end
        end
    end
    ctx.wait(ctx.left() * 1000)
end)

-- ----------------------------------------------------------------------
-- GUNFIGHT: real shooter peds, real (harmless) bullets, whizzing and impacts
-- ----------------------------------------------------------------------
local function angularSpot(angle, dist)
    local px, py, pz = Helpers.Coords()
    local vx, vy = Helpers.HeadingVec(angle % 360.0)
    local x, y = px + vx * dist, py + vy * dist
    local gz = Helpers.GroundZ(x, y, pz)
    if gz and math.abs(gz - pz) <= 6.0 then return x, y, gz, Helpers.HeadingTo(x, y, px, py) end
    return nil
end

Fx.Register('gunfight', function(ctx)
    local cfg = ctx.cfg
    local pool = R().Shooters
    if type(pool) ~= 'table' or #pool == 0 then return end
    local mode = ctx.opt('Mode', 'mode')
    if mode ~= 'crossfire' and mode ~= 'distant' then mode = 'ambush' end
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 255
    local lo = (cfg.Distance and cfg.Distance.min) or 14.0
    local hi = (cfg.Distance and cfg.Distance.max) or 30.0
    if mode == 'distant' then lo, hi = lo * 2.0, hi * 1.8 end

    local shooters = {}
    local loaded = {}
    ctx.onStop(function() for h in pairs(loaded) do RemoveWeaponAsset(h) end end)

    local function spawnShooter(def, angle)
        for _ = 1, 6 do
            local x, y, z, h = angularSpot(angle + Utils.Rand(-8.0, 8.0), Utils.Rand(lo, hi))
            if x then
                local ped = Ents.Spawn(ctx.sid, def.Model, x, y, z, h, 0)
                if ped then
                    local hash = joaat(def.Weapon or 'WEAPON_PISTOL')
                    if not HasWeaponAssetLoaded(hash) then
                        RequestWeaponAsset(hash, 31, 26)
                        local t = GetGameTimer() + 2000
                        while not HasWeaponAssetLoaded(hash) and GetGameTimer() < t do Wait(20) end
                    end
                    loaded[hash] = true
                    GiveWeaponToPed(ped, hash, 0, true, true)     -- a prop only: no ammo
                    SetCurrentPedWeapon(ped, hash, true)
                    fadeIn(ped, alpha, 300)
                    TaskAimGunAtEntity(ped, PlayerPedId(), 600000, true)
                    return { ped = ped, def = def, hash = hash }
                end
                return nil
            end
        end
        return nil
    end

    local count = math.max(1, math.min(8, math.floor(Utils.Range(cfg.Count, 3.0, IS(ctx)))))
    local base = Helpers.CamHeading() + Utils.Rand(-50.0, 50.0)
    for i = 1, count do
        if not ctx.canSpawn() then break end
        local angle
        if mode == 'crossfire' then angle = base + (i % 2 == 0 and 80.0 or -80.0) + Utils.Rand(-25.0, 25.0)
        else angle = base + Utils.Rand(-35.0, 35.0) end
        local s = spawnShooter(Utils.Pick(pool), angle)
        if s then shooters[#shooters + 1] = s end
        Wait(math.random(120, 420))
    end
    if #shooters == 0 and mode ~= 'distant' then return end

    local panicId = ctx.id('panic')
    if cfg.Panic ~= false then
        ctx.live(function() UI.Overlay(panicId, 'vignette', true, { color = '#7A0000', strength = 0.25 + 0.5 * ctx.intensity, pulse = true }) end)
        UI.Sound(ctx.id('hb'), 'heartbeat', { loop = true, volume = 0.8, rate = 1.3 })
    end

    local bursts = 0
    while ctx.alive() and #shooters > 0 do
        if Helpers.IsDead() then break end
        local s = Utils.Pick(shooters)
        if not Ents.Exists(s.ped) then
            for i = #shooters, 1, -1 do if shooters[i] == s then table.remove(shooters, i) end end
        else
            local def = s.def
            local n = math.max(1, math.floor(Utils.Range(def.Burst, 3.0, IS(ctx))))
            for _ = 1, n do
                if not (ctx.alive() and Ents.Exists(s.ped)) then break end
                Ents.Face(s.ped, Helpers.Coords())
                local r = math.random()
                local kind, tx, ty, tz
                if mode == 'distant' then
                    kind = 'wild'
                    local px, py, pz = Helpers.Coords()
                    local ang = math.rad(Utils.Rand(0.0, 360.0))
                    tx, ty, tz = px + math.cos(ang) * 40.0, py + math.sin(ang) * 40.0, pz + 30.0   -- into the sky
                elseif r < (tonumber(cfg.WhizChance) or 0.6) then
                    kind = 'whiz'
                    tx, ty, tz = whizTarget(s.ped)
                elseif r < (tonumber(cfg.WhizChance) or 0.6) + (tonumber(cfg.ImpactChance) or 0.55) then
                    kind = 'impact'
                    tx, ty, tz = impactTarget()
                else
                    kind = 'wild'
                    local px, py, pz = Helpers.Coords()
                    local ang = math.rad(Utils.Rand(0.0, 360.0))
                    tx, ty, tz = px + math.cos(ang) * 12.0, py + math.sin(ang) * 12.0, (Helpers.GroundZ(px, py, pz) or pz) + 0.2
                end
                local fired = Realism.Fire(ctx, s.ped, s.hash, tx, ty, tz, kind)
                if fired and kind == 'whiz' then
                    local pan = Helpers.PanOf(tx, ty)
                    UI.Sound(ctx.id('whiz' .. math.random(1, 99999)), 'bullet_whiz', { volume = 0.9, pan = pan })
                    if cfg.DuckReaction ~= false then Visual.Kick('HAND_SHAKE', 0.25 + 0.25 * ctx.intensity) end
                end
                if fired then
                    Visual.Kick('SMALL_EXPLOSION_SHAKE', (tonumber(cfg.Shake) or 0.4) * 0.35 * (0.4 + ctx.intensity))
                end
                if not ctx.wait(math.floor((tonumber(def.Rate) or 300) * Utils.Rand(0.85, 1.2))) then break end
            end
            bursts = bursts + 1
            -- real shooters do not stand still: sometimes they run to a new spot and aim again
            if mode ~= 'distant' and Ents.Exists(s.ped) and math.random() < 0.45 then
                local c = GetEntityCoords(s.ped)
                local ang = math.rad(Helpers.HeadingTo(c.x, c.y, Helpers.Coords()) + (math.random() < 0.5 and 90.0 or -90.0))
                local nx, ny = c.x - math.sin(ang) * Utils.Rand(3.0, 6.0), c.y + math.cos(ang) * Utils.Rand(3.0, 6.0)
                local nz = Helpers.GroundZ(nx, ny, c.z)
                if nz and math.abs(nz - c.z) < 2.5 then
                    TaskGoStraightToCoord(s.ped, nx, ny, nz, 3.0, 2500, GetEntityHeading(s.ped), 0.0)
                    ctx.wait(1700)
                    if Ents.Exists(s.ped) then TaskAimGunAtEntity(s.ped, PlayerPedId(), 600000, true) end
                end
            end
            if cfg.Panic ~= false and bursts == 3 then UI.Sound(ctx.id('tin'), 'tinnitus', { loop = true, volume = 0.18 + 0.2 * ctx.intensity, fade = 3.0 }) end
        end
        local gap = Utils.Range(cfg.BurstGap, 2.0, 1.0 / IS(ctx))
        if not ctx.wait(math.floor(gap * 1000)) then break end
    end
    for _, s in ipairs(shooters) do Ents.FadeOut(ctx.sid, s.ped, 350) end
    ctx.wait(500)
end)

-- ----------------------------------------------------------------------
-- SCENES (Config.Scenes): actors with real peds, past or present
-- ----------------------------------------------------------------------
local envOwners = 0

local function rel(sc, fwd, right, up)
    local k = sc.k or 1.0
    fwd, right = (fwd or 0.0) * k, (right or 0.0) * k
    return sc.px + sc.fx * fwd + sc.rx * right, sc.py + sc.fy * fwd + sc.ry * right, up or 0.0
end

local function sceneSpot(sc, at)
    local x, y, up = rel(sc, at.fwd, at.right, at.up)
    return x, y, groundAt(x, y, sc.pz) + (up or 0.0)
end

local function actorByRef(sc, ref)
    if ref == 'me' then return PlayerPedId() end
    local a = sc.actors[ref]
    return a and a.ped or nil
end

--- Plays a scene from Config.Scenes. Blocks until it ends. Returns true when it ran.
--- opts.seconds caps the scene length; opts.quiet skips the environment changes.
function Realism.RunScene(ctx, name, opts)
    opts = opts or {}
    local def = Config.Scenes and Config.Scenes[name]
    if type(def) ~= 'table' then return false end
    local px, py, pz = Helpers.Coords()
    local heading = Helpers.CamHeading()
    local fx, fy = Helpers.HeadingVec(heading)
    local rx, ry = Helpers.HeadingVec(heading - 90.0)
    local sc = { px = px, py = py, pz = pz, fx = fx, fy = fy, rx = rx, ry = ry, actors = {}, k = 1.0 }
    -- the whole scene shrinks towards the player when a wall is in front of him (nobody stands inside a building)
    do
        local far = 3.0
        for _, a in ipairs(def.Actors or {}) do far = math.max(far, math.abs(tonumber(a.At and a.At.fwd) or 0.0)) end
        local wall = Helpers.Blocked(px, py, pz + 0.7, px + fx * (far + 1.0), py + fy * (far + 1.0), pz + 0.7)
        if wall and wall < far + 1.0 then sc.k = Utils.Clamp((wall - 0.8) / far, 0.3, 1.0) end
    end
    local total = math.min(tonumber(opts.seconds) or tonumber(def.Duration) or 30.0, ctx.left())
    local owner = ctx.id('scene:' .. name)
    local L = def.Look or {}
    local envOn = false

    -- the look of the scene
    if L.Timecycle then Visual.Timecycle(owner, L.Timecycle, tonumber(L.Strength) or 0.6) end
    if L.Tint then UI.Overlay(owner .. ':tint', 'tint', true, { color = L.Tint, strength = tonumber(L.TintStrength) or 0.2, pulse = false }) end
    if L.Grain then UI.Overlay(owner .. ':grain', 'noise', true, {}) end
    if L.Sound then UI.Sound(owner .. ':snd', L.Sound, { loop = true, volume = tonumber(L.SoundVolume) or 0.4, fade = 2.0 }) end
    if ctx.opt('Environment', 'environment') ~= false and not opts.quiet then
        if L.Clock and tonumber(L.Clock.h) then
            pcall(NetworkOverrideClockTime, math.floor(L.Clock.h), math.floor(L.Clock.m or 0), 0)
            envOn = true
        end
        if type(L.Weather) == 'string' and L.Weather ~= '' then
            pcall(function()
                SetWeatherTypeNowPersist(L.Weather)
            end)
            envOn = true
        end
        if envOn then envOwners = envOwners + 1 end
    end

    local function finish()
        Visual.TimecycleOff(owner)
        UI.Overlay(owner .. ':tint', 'tint', false)
        UI.Overlay(owner .. ':grain', 'noise', false)
        UI.SoundStop(owner .. ':snd', 1.5)
        if envOn then
            envOn = false
            envOwners = math.max(0, envOwners - 1)
            if envOwners == 0 then
                pcall(NetworkClearClockTimeOverride)
                pcall(ClearOverrideWeather)
                pcall(ClearWeatherTypePersist)
            end
        end
        for _, a in pairs(sc.actors) do
            if a.ped then Ents.FadeOut(ctx.sid, a.ped, 350) end
        end
        ctx.phantom = nil
    end
    ctx.onStop(function()
        -- a stop in the middle of a scene releases the environment as well
        if envOn then
            envOn = false
            envOwners = math.max(0, envOwners - 1)
            if envOwners == 0 then
                pcall(NetworkClearClockTimeOverride)
                pcall(ClearOverrideWeather)
                pcall(ClearWeatherTypePersist)
            end
        end
        Visual.TimecycleOff(owner)
    end)

    -- actors
    local queue = {}
    for _, a in ipairs(def.Actors or {}) do
        local x, y, z = sceneSpot(sc, a.At or {})
        local h = (a.Heading == nil or a.Heading == 'face') and Helpers.HeadingTo(x, y, px, py) or tonumber(a.Heading) or 0.0
        local ped
        if a.Model == 'self' or a.Model == 'subject' then
            ped = Ents.Look(ctx.sid, a.Model, { 'a_m_y_hipster_01' }, ctx.subject, x, y, z, h, 0)
        else
            ped = Ents.Spawn(ctx.sid, a.Model or 'a_m_y_hipster_01', x, y, z, h, 0)
        end
        if ped then
            local actor = { ped = ped, def = a, name = a.Name and Utils.Text(a.Name) or nil }
            if a.Id then sc.actors[a.Id] = actor else sc.actors[#sc.actors + 1] = actor end
            pcall(SetPedCanRagdoll, ped, true)
            if a.Weapon then
                local hash = joaat(a.Weapon)
                RequestWeaponAsset(hash, 31, 26)
                local t = GetGameTimer() + 1500
                while not HasWeaponAssetLoaded(hash) and GetGameTimer() < t do Wait(20) end
                GiveWeaponToPed(ped, hash, 0, true, true)
                SetCurrentPedWeapon(ped, hash, true)
                actor.hash = hash
            end
            fadeIn(ped, tonumber(a.Alpha) or 255, 700)
            if a.LookAtMe ~= false then pcall(TaskLookAtEntity, ped, PlayerPedId(), -1, 2048, 2) end   -- the head follows the player
            if a.Anim and Helpers.LoadAnimDict(a.Anim.dict, 1500) then
                TaskPlayAnim(ped, a.Anim.dict, a.Anim.name, 8.0, -8.0, -1, a.Anim.flag or 1, 0.0, false, false, false)
            elseif a.Scenario then
                TaskStartScenarioInPlace(ped, a.Scenario, 0, true)
            end
            for _, ln in ipairs(a.Lines or {}) do
                queue[#queue + 1] = { t = tonumber(ln.t) or 0, kind = 'say', actor = actor, text = Utils.Text(ln.text) }
            end
            for _, tl in ipairs(a.Timeline or {}) do
                queue[#queue + 1] = { t = tonumber(tl.t) or 0, kind = 'act', actor = actor, step = tl }
            end
        end
    end
    for _, ev in ipairs(def.Events or {}) do
        queue[#queue + 1] = { t = tonumber(ev.t) or 0, kind = 'event', step = ev }
    end
    table.sort(queue, function(a, b) return a.t < b.t end)

    local function doStep(item)
        local st, actor = item.step, item.actor
        local ped = actor and actor.ped
        if item.kind == 'say' then
            if ctx.cfg.Subtitles ~= false and item.text and item.text ~= '' then
                ctx.phantom = ped
                Dialogue.Say(ctx.sid, item.text, 5.5, actor.name)
                if Ents.Exists(ped) then
                    pcall(SetFacialIdleAnimOverride, ped, 'mood_talking_1', 0)      -- the mouth moves while he speaks
                    local secs = math.min(5.5, 0.9 + #item.text * 0.07)
                    SetTimeout(math.floor(secs * 1000), function()
                        if Ents.Exists(ped) then pcall(ClearFacialIdleAnimOverride, ped) end
                    end)
                end
            end
            return
        end
        if item.kind == 'event' then
            if st.Do == 'flash' then UI.Flash(st.color or '#FFFFFF', 90, 0.6)
            elseif st.Do == 'shake' then Visual.Kick('SMALL_EXPLOSION_SHAKE', tonumber(st.amount) or 0.3)
            elseif st.Do == 'sound' and type(st.name) == 'string' then UI.Sound(ctx.id('ev' .. math.random(1, 99999)), st.name, { volume = tonumber(st.volume) or 0.8 })
            elseif st.Do == 'cue' and type(st.name) == 'string' and Cue then Cue.Run(st.name, tonumber(st.seconds) or 4.0, ctx.intensity)
            elseif st.Do == 'blood' then UI.Flash(Config.UI.BloodColor, 160, 0.5) end
            return
        end
        if not Ents.Exists(ped) then return end
        local d = st.Do
        if d == 'walk' then
            local x, y, z = sceneSpot(sc, st.to or {})
            TaskGoStraightToCoord(ped, x, y, z, tonumber(st.speed) or 1.0, -1, GetEntityHeading(ped), 0.0)
        elseif d == 'face' then
            local mx, my = Helpers.Coords()
            Ents.Face(ped, mx, my)
        elseif d == 'anim' and st.dict and Helpers.LoadAnimDict(st.dict, 1500) then
            TaskPlayAnim(ped, st.dict, st.name, 8.0, -8.0, -1, st.flag or 1, 0.0, false, false, false)
        elseif d == 'scenario' and st.name then
            TaskStartScenarioInPlace(ped, st.name, 0, true)
        elseif d == 'aim' then
            local target = actorByRef(sc, st.at or 'me')
            if target then TaskAimGunAtEntity(ped, target, 15000, true) end
        elseif d == 'shoot' and actor.hash then
            local shots = math.max(1, math.min(12, math.floor(tonumber(st.shots) or 3)))
            local gap = tonumber(st.gap) or 300
            local target = actorByRef(sc, st.at or 'me')
            CreateThread(function()
                for _ = 1, shots do
                    if not (ctx.alive() and Ents.Exists(ped)) then return end
                    local fired = false
                    if st.at ~= nil and st.at ~= 'me' and Ents.Exists(target) then
                        -- at another actor: at his chest; if the line is unsafe for the player it goes to the ground beside him
                        local c = GetPedBoneCoords(target, 24818, 0.0, 0.0, 0.0)
                        fired = Realism.Fire(ctx, ped, actor.hash, c.x, c.y, c.z, 'wild')
                        if not fired then
                            local g = GetEntityCoords(target)
                            fired = Realism.Fire(ctx, ped, actor.hash, g.x + 0.6, g.y, g.z - 0.9, 'impact')
                        end
                    else
                        local tx, ty, tz
                        if math.random() < 0.6 then tx, ty, tz = whizTarget(ped) else tx, ty, tz = impactTarget() end
                        fired = Realism.Fire(ctx, ped, actor.hash, tx, ty, tz, 'whiz')
                    end
                    if fired then Visual.Kick('SMALL_EXPLOSION_SHAKE', 0.14 + 0.12 * ctx.intensity) end
                    Wait(math.floor(gap * Utils.Rand(0.85, 1.2)))
                end
            end)
        elseif d == 'fall' then
            ClearPedTasksImmediately(ped)
            SetPedToRagdoll(ped, 6000, 6000, 0, false, false, false)
            pcall(ApplyPedDamagePack, ped, 'BigHitByVehicle', 0.0, 1.0)
            UI.Sound(ctx.id('fall' .. math.random(1, 99999)), 'body_hit', { volume = 0.7 })
        elseif d == 'rise' then
            ClearPedTasksImmediately(ped)
        elseif d == 'vanish' then
            Ents.FadeOut(ctx.sid, ped, 600)
            actor.ped = nil
        end
    end

    local started = GetGameTimer()
    local idx = 1
    while ctx.alive() and not Helpers.IsDead() do
        local el = (GetGameTimer() - started) / 1000.0
        if el >= total then break end
        while queue[idx] and queue[idx].t <= el do
            local item = queue[idx]
            idx = idx + 1
            local ok, err = pcall(doStep, item)
            if not ok then Utils.Debug('scene step failed', tostring(err)) end
        end
        Wait(50)
    end
    finish()
    return true
end

Fx.Register('scene', function(ctx)
    local name = ctx.params.scene or ctx.cfg.Default
    if not (Config.Scenes and Config.Scenes[name]) then
        Utils.Warn('scene not found in Config.Scenes: ' .. tostring(name))
        return ctx.finish()
    end
    Realism.RunScene(ctx, name, {})
    if ctx.cfg.EndWhenDone ~= false then return ctx.finish() end
    ctx.wait(ctx.left() * 1000)
end)

-- ----------------------------------------------------------------------
-- DEATH FEELING: hit -> fading sight -> memories -> last words -> faint -> wake (never kills)
-- ----------------------------------------------------------------------
Fx.Register('death_feeling', function(ctx)
    local cfg = ctx.cfg
    local I = ctx.intensity
    local o = ctx.id('df')
    ctx.onStop(function()
        Visual.TimecycleOff(o)
        Visual.TimeScaleOff(o)
        Visual.ShakeOff(o)
    end)

    -- 1) hits
    local hits = math.max(1, math.floor(Utils.Range(cfg.Hits, 2.0, Helpers.IScale(I) * 0.9)))
    UI.Overlay(ctx.id('blood'), 'blood', true, { strength = 0.5 + 0.5 * I, color = Config.UI.BloodColor })
    for i = 1, hits do
        if not ctx.alive() then return end
        UI.Flash('#7A0000', 220, 0.6)
        UI.Sound(ctx.id('hit' .. i), 'body_hit', { volume = 1.0 })
        Visual.Kick('LARGE_EXPLOSION_SHAKE', 0.3 + 0.3 * I)
        if i == 1 and cfg.Ragdoll ~= false then Realism.Ragdoll(tonumber(cfg.RagdollSeconds) or 2.5) end
        if not ctx.wait(650) then return end
    end

    -- 2) the world fades
    UI.Sound(ctx.id('tin'), 'tinnitus', { loop = true, volume = 0.3 + 0.3 * I, fade = 1.5 })
    UI.Sound(ctx.id('hb'), 'heartbeat', { loop = true, volume = 1.0, rate = 1.5, fade = 0.4 })
    UI.Sound(ctx.id('br'), 'breathing', { loop = true, volume = 0.7, rate = 0.8, fade = 1.0 })
    UI.Overlay(ctx.id('tunnel'), 'vignette', true, { color = '#000000', strength = 0.5, pulse = true })
    if cfg.SlowMotion ~= false then Visual.TimeScale(o, Config.Safety.TimeScaleMin) end
    local rampMs = 5000
    local t0 = GetGameTimer()
    while ctx.alive() and GetGameTimer() - t0 < rampMs do
        local k = (GetGameTimer() - t0) / rampMs
        Visual.Timecycle(o, 'REDMIST_blend', 0.25 + 0.65 * k * I)
        UI.Overlay(ctx.id('tunnel'), 'vignette', true, { color = '#000000', strength = 0.5 + 0.5 * k, pulse = true })
        UI.SoundUpdate(ctx.id('hb'), 0.0, 1.0, false, 1.5 - 0.7 * k)
        if math.floor((GetGameTimer() - t0) / 850) ~= math.floor((GetGameTimer() - t0 - 100) / 850) then Visual.Kick('HAND_SHAKE', 0.12 + 0.12 * I) end
        Wait(100)
    end

    -- 3) flashes of memories (scenes from the config)
    local LF = cfg.LifeFlash or {}
    if LF.Enabled ~= false and type(LF.Scenes) == 'table' and #LF.Scenes > 0 and ctx.left() > (tonumber(LF.Seconds) or 7) + 8 then
        Realism.RunScene(ctx, Utils.Pick(LF.Scenes), { seconds = tonumber(LF.Seconds) or 7, quiet = true })
    end

    -- 4) last words
    if cfg.LastWords ~= false then
        local pool = Utils.Pool('LastWords')
        local w = Utils.Pick(pool)
        if w then UI.Word(w, 0.5, 0.5, 3200, 34) end
        if not ctx.wait(3000) then return end
    end

    -- 5) black: flatline, lying on the ground
    local black = tonumber(cfg.Blackout) or 4.0
    UI.Send('cue', { name = 'blackout', seconds = black, strength = 1.0 })
    UI.Sound(ctx.id('fl'), 'flatline', { volume = 0.6 })
    UI.SoundStop(ctx.id('hb'), 0.8)
    if cfg.Faint ~= false then Realism.Ragdoll(black + 0.8) end
    if not ctx.wait(math.floor(black * 1000)) then return end

    -- 6) wake up
    UI.SoundStop(ctx.id('tin'), 2.5)
    UI.SoundStop(ctx.id('br'), 0.5)
    UI.Overlay(ctx.id('tunnel'), 'vignette', false)
    UI.Overlay(ctx.id('blood'), 'blood', false)
    if cfg.WakeUp ~= false then
        UI.Sound(ctx.id('gasp'), 'breathing', { loop = true, volume = 0.9, rate = 1.5, fade = 0.3 })
        local w0 = GetGameTimer()
        while GetGameTimer() - w0 < 4500 do
            if not ctx.alive() then return end
            local k = (GetGameTimer() - w0) / 4500
            Visual.Timecycle(o, 'REDMIST_blend', math.max(0.0, (1.0 - k) * 0.5 * I))
            Wait(100)
        end
        UI.SoundStop(ctx.id('gasp'), 2.0)
    end
    ctx.finish()
end)

-- ----------------------------------------------------------------------
-- SELF ZOMBIE: infection -> the walk -> falling in the street
-- ----------------------------------------------------------------------
Fx.Register('self_zombie', function(ctx)
    local cfg = ctx.cfg
    local I = ctx.intensity
    local o = ctx.id('sz')
    local me = PlayerPedId()
    local wounded = false
    ctx.onStop(function()
        Visual.TimecycleOff(o)
        Visual.ShakeOff(o)
        resetClipset()
        if wounded then
            pcall(ClearPedBloodDamage, PlayerPedId())
            pcall(ResetPedVisibleDamage, PlayerPedId())
        end
    end)

    local tintId = ctx.id('tint')
    local infection = tonumber(cfg.InfectionSeconds) or 18.0
    local t0 = GetGameTimer()
    UI.Sound(ctx.id('br'), 'breathing', { loop = true, volume = 0.5, rate = 0.9, fade = 2.0 })
    while ctx.alive() and (GetGameTimer() - t0) / 1000.0 < infection do
        local k = ((GetGameTimer() - t0) / 1000.0) / infection
        UI.Overlay(tintId, 'tint', true, { color = cfg.Tint or '#4A5A2A', strength = (0.1 + 0.4 * k) * (0.5 + 0.5 * I), pulse = true })
        Visual.Timecycle(o, 'drug_wobbly', 0.15 + 0.4 * k * I)
        Visual.Shake(o, 'HAND_SHAKE', 0.1 + 0.4 * k * I)
        Wait(250)
    end
    if not ctx.alive() then return end

    -- the turn
    UI.Flash('#1A2A10', 260, 0.7)
    UI.Sound(ctx.id('g0'), 'groan_1', { volume = 0.9 })
    Visual.Kick('LARGE_EXPLOSION_SHAKE', 0.3 + 0.3 * I)
    Visual.Timecycle(o, 'REDMIST_blend', 0.3 + 0.3 * I)
    applyClipset(cfg.Clipset)
    if cfg.Wounds ~= false then
        wounded = true
        dressWounds(me, (R().Zombies or {}).Wounds, 3)
    end
    UI.Overlay(ctx.id('bl'), 'blood', true, { strength = 0.3 + 0.3 * I, color = Config.UI.BloodColor })

    local nextFall = GetGameTimer() + math.floor(Utils.Range(cfg.FallEvery, 18.0, 1.0 / Helpers.IScale(I)) * 1000)
    local nextGroan = GetGameTimer() + 6000
    while ctx.alive() do
        local now = GetGameTimer()
        if not Helpers.InVehicle() and now >= nextFall then
            nextFall = now + math.floor(Utils.Range(cfg.FallEvery, 18.0, 1.0 / Helpers.IScale(I)) * 1000)
            UI.Flash('#000000', 400, 0.6)
            if Realism.Ragdoll(Utils.Range(cfg.FallSeconds, 3.5)) and cfg.Groans ~= false then
                UI.Sound(ctx.id('gf' .. math.random(1, 99999)), 'groan_2', { volume = 0.9 })
            end
        end
        if cfg.Groans ~= false and now >= nextGroan then
            nextGroan = now + math.random(8000, 17000)
            UI.Sound(ctx.id('gg' .. math.random(1, 99999)), math.random() < 0.5 and 'groan_1' or 'groan_2', { volume = 0.6 })
        end
        -- the walk can be reset by the game (after a ragdoll, entering a vehicle): re-apply it
        if not IsPedInAnyVehicle(me, false) and cfg.Clipset and math.random() < 0.05 then applyClipset(cfg.Clipset) end
        Wait(300)
    end
end)

-- ----------------------------------------------------------------------
-- COLLAPSE: dizziness, black, falls in the street, gets up gasping
-- ----------------------------------------------------------------------
Fx.Register('collapse', function(ctx)
    local cfg = ctx.cfg
    local I = ctx.intensity
    local o = ctx.id('col')
    ctx.onStop(function() Visual.TimecycleOff(o) Visual.ShakeOff(o) end)
    local falls = math.max(1, math.floor(Utils.Range(cfg.Falls, 2.0, Helpers.IScale(I) * 0.8)))
    for n = 1, falls do
        if not ctx.alive() then return end
        -- prelude
        local pre = tonumber(cfg.PreludeSeconds) or 3.0
        Visual.Timecycle(o, 'drug_wobbly', 0.2 + 0.5 * I)
        Visual.Shake(o, 'DRUNK_SHAKE', 0.3 + 0.5 * I)
        UI.Overlay(ctx.id('tun'), 'vignette', true, { color = '#000000', strength = 0.6, pulse = true })
        UI.Sound(ctx.id('hb' .. n), 'heartbeat', { volume = 0.7, rate = 1.3 })
        if not ctx.wait(math.floor(pre * 1000)) then return end
        -- the fall
        local secs = Utils.Range(cfg.FallSeconds, 3.5)
        if Realism.Ragdoll(secs) then
            UI.Send('cue', { name = 'blackout', seconds = math.min(secs, 2.5), strength = 0.9 })
            UI.Sound(ctx.id('th' .. n), 'body_hit', { volume = 0.8 })
            if not ctx.wait(math.floor(secs * 1000)) then return end
        end
        UI.Overlay(ctx.id('tun'), 'vignette', false)
        Visual.ShakeOff(o)
        Visual.TimecycleOff(o)
        UI.Sound(ctx.id('ga' .. n), 'breathing', { volume = 0.8, rate = 1.4 })
        if n < falls then
            if not ctx.wait(math.floor(Utils.Range(cfg.GapSeconds, 12.0, 1.0 / Helpers.IScale(I)) * 1000)) then return end
        end
    end
    ctx.wait(1500)
    ctx.finish()
end)

-- ----------------------------------------------------------------------
-- DRUNK
-- ----------------------------------------------------------------------
Fx.Register('drunk', function(ctx)
    local cfg = ctx.cfg
    local o = ctx.id('dr')
    ctx.onStop(function()
        Visual.TimecycleOff(o)
        Visual.ShakeOff(o)
        resetClipset()
        pcall(SetPedIsDrunk, PlayerPedId(), false)
    end)
    applyClipset(cfg.Clipset)
    pcall(SetPedIsDrunk, PlayerPedId(), true)
    ctx.live(function()
        Visual.Timecycle(o, cfg.Timecycle or 'drug_drive_blend01', 0.2 + 0.6 * ctx.intensity)
        Visual.Shake(o, cfg.Shake or 'DRUNK_SHAKE', 0.2 + 0.9 * ctx.intensity)
    end)
    local nextStumble = GetGameTimer() + math.floor(Utils.Range(cfg.StumbleEvery, 20.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)
    while ctx.alive() do
        if GetGameTimer() >= nextStumble then
            nextStumble = GetGameTimer() + math.floor(Utils.Range(cfg.StumbleEvery, 20.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)
            if math.random() < (tonumber(cfg.StumbleChance) or 0.3) * Helpers.IScale(ctx.intensity) then
                Realism.Ragdoll(Utils.Rand(1.0, 2.0))
            end
        end
        if not IsPedInAnyVehicle(PlayerPedId(), false) and math.random() < 0.04 then applyClipset(cfg.Clipset) end
        Wait(300)
    end
end)

-- ----------------------------------------------------------------------
-- UNDERWATER
-- ----------------------------------------------------------------------
Fx.Register('underwater', function(ctx)
    local cfg = ctx.cfg
    local o = ctx.id('uw')
    ctx.onStop(function() Visual.TimecycleOff(o) Visual.ShakeOff(o) end)
    ctx.live(function()
        Visual.Timecycle(o, cfg.Timecycle or 'underwater', 0.4 + 0.6 * ctx.intensity)
        Visual.Shake(o, cfg.Shake or 'SKY_DIVING_SHAKE', 0.15 + 0.35 * ctx.intensity)
        UI.Overlay(ctx.id('tint'), 'tint', true, { color = '#1F6F8B', strength = 0.15 + 0.25 * ctx.intensity, pulse = true })
    end)
    UI.Sound(ctx.id('br'), 'breathing', { loop = true, volume = 0.6, rate = 0.6, fade = 1.5 })
    UI.Sound(ctx.id('rb'), 'rumble', { loop = true, volume = 0.25, fade = 2.0 })
    while ctx.alive() do
        if cfg.Bubbles ~= false then UI.Sound(ctx.id('bu' .. math.random(1, 99999)), 'whoosh', { volume = 0.25, rate = 0.6 }) end
        if not ctx.wait(math.random(2500, 6000)) then break end
    end
end)

-- ----------------------------------------------------------------------
-- INSECTS: screen + particles + real creatures + your props + sound + itch
-- ----------------------------------------------------------------------
local function loadPtfx(candidates)
    for _, c in ipairs(candidates or {}) do
        if type(c) == 'table' and c.Asset and c.Name then
            RequestNamedPtfxAsset(c.Asset)
            local t = GetGameTimer() + 700
            while not HasNamedPtfxAssetLoaded(c.Asset) and GetGameTimer() < t do Wait(0) end
            if HasNamedPtfxAssetLoaded(c.Asset) then return c end
        end
    end
    return nil
end

Fx.Register('insects', function(ctx)
    local cfg = ctx.cfg
    local L = cfg.Layers or {}
    local Ins = R().Insects or {}
    local I = ctx.intensity
    local me = PlayerPedId()
    local o = ctx.id('ins')
    local handles, objects = {}, {}
    ctx.onStop(function()
        for _, h in ipairs(handles) do pcall(StopParticleFxLooped, h, false) end
        for _, ob in ipairs(objects) do if DoesEntityExist(ob.e) then DeleteEntity(ob.e) end end
        Visual.ShakeOff(o)
    end)

    if L.Screen ~= false then
        ctx.live(function() UI.Overlay(ctx.id('bugs'), 'bugs', true, { count = math.floor(55 * Helpers.IScale(ctx.intensity)), color = '#120C08' }) end)
    end
    if L.Sound ~= false then
        UI.Sound(ctx.id('fly'), 'fly_buzz', { loop = true, volume = 0.25 + 0.4 * I, fade = 1.5 })
        ctx.thread(function()
            local k = 0.0
            while ctx.alive() do
                k = k + 0.12
                UI.SoundUpdate(ctx.id('fly'), math.sin(k) * 0.9, 0.2 + 0.45 * ctx.intensity, math.cos(k) < 0)
                Wait(100)
            end
        end)
        ctx.thread(function()
            while ctx.alive() do
                if not ctx.wait(math.random(3500, 9000)) then break end
                local x, y = Audio.PointFor('around', Utils.Rand(0.5, 2.5))
                Audio.PlayAt(ctx, 'skitter', x, y, 0.5 + 0.3 * ctx.intensity)
            end
        end)
    end

    -- particles around the body
    if L.Particles ~= false then
        local c = loadPtfx(Ins.Particles)
        if c then
            local bones = Ins.Bones or { 31086 }
            local n = math.max(1, math.floor(#bones * (0.4 + I)))
            for i = 1, math.min(n, #bones) do
                pcall(function()
                    UseParticleFxAsset(c.Asset)
                    local h = StartParticleFxLoopedOnEntityBone(c.Name, me, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, GetPedBoneIndex(me, bones[i]), 0.9, false, false, false)
                    if h and h ~= 0 then handles[#handles + 1] = h end
                end)
            end
        end
    end

    -- props crawling over the body (your own insect models)
    if L.Props ~= false and type(Ins.PropModels) == 'table' and #Ins.PropModels > 0 and ctx.canSpawn() then
        local count = math.max(1, math.floor(Utils.Range(Ins.PropCount, 8.0, Helpers.IScale(I))))
        for _ = 1, count do
            local hash = Helpers.LoadModel(Utils.Pick(Ins.PropModels), 2000)
            if hash then
                local c = GetEntityCoords(me)
                local e = CreateObject(hash, c.x, c.y, c.z, false, false, false)
                SetModelAsNoLongerNeeded(hash)
                if e and e ~= 0 then
                    SetEntityCollision(e, false, false)
                    local bones = Ins.Bones or { 31086 }
                    objects[#objects + 1] = { e = e, bone = GetPedBoneIndex(me, Utils.Pick(bones)), ox = Utils.Rand(-0.12, 0.12), oy = Utils.Rand(-0.12, 0.12), oz = Utils.Rand(-0.12, 0.12), a = Utils.Rand(0, 360) }
                end
            end
        end
        ctx.thread(function()
            while ctx.alive() do
                for _, ob in ipairs(objects) do
                    if DoesEntityExist(ob.e) then
                        ob.ox = Utils.Clamp(ob.ox + Utils.Rand(-0.03, 0.03), -0.2, 0.2)
                        ob.oy = Utils.Clamp(ob.oy + Utils.Rand(-0.03, 0.03), -0.2, 0.2)
                        ob.oz = Utils.Clamp(ob.oz + Utils.Rand(-0.03, 0.03), -0.2, 0.2)
                        ob.a = (ob.a + Utils.Rand(-40, 40)) % 360
                        AttachEntityToEntity(ob.e, PlayerPedId(), ob.bone, ob.ox, ob.oy, ob.oz, 0.0, 0.0, ob.a, false, false, false, false, 2, true)
                    end
                end
                Wait(220)
            end
        end)
    end

    -- real creatures around the feet
    if L.Creatures ~= false and type(Ins.Creatures) == 'table' and #Ins.Creatures > 0 and ctx.canSpawn() then
        local count = math.max(1, math.floor(Utils.Range(Ins.CreatureCount, 4.0, Helpers.IScale(I))))
        local crowd = {}
        for _ = 1, count do
            local x, y, z, h = Helpers.PickSpot(4.0, 11.0, { maxZDiff = 3.0 })
            local ped = x and Ents.Look(ctx.sid, 'model', Ins.Creatures, nil, x, y, z, h, 0)
            if ped then
                fadeIn(ped, 255, 300)
                crowd[#crowd + 1] = ped
            end
            Wait(math.random(100, 350))
        end
        ctx.thread(function()
            while ctx.alive() and #crowd > 0 do
                local mx, my, mz = Helpers.Coords()
                for i = #crowd, 1, -1 do
                    local ped = crowd[i]
                    if not Ents.Exists(ped) then
                        table.remove(crowd, i)
                    elseif Ents.Distance(ped) < 0.9 then
                        Audio.PlayAt(ctx, 'skitter', mx, my, 0.6)
                        Ents.FadeOut(ctx.sid, ped, 150)
                        table.remove(crowd, i)
                    else
                        TaskGoStraightToCoord(ped, mx + Utils.Rand(-1.5, 1.5), my + Utils.Rand(-1.5, 1.5), mz, 2.0, 2500, GetEntityHeading(ped), 0.0)
                    end
                end
                Wait(1200)
            end
        end)
    end

    -- itch: the camera twitches and he swats
    if L.Itch ~= false then
        ctx.thread(function()
            while ctx.alive() do
                if not ctx.wait(math.floor(Utils.Range(cfg.ItchEvery, 9.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
                Visual.Kick('HAND_SHAKE', 0.25 + 0.3 * ctx.intensity)
                local a = Ins.SwatAnim
                local ped = PlayerPedId()
                if a and a.dict and not IsPedInAnyVehicle(ped, false) and not IsPedRagdoll(ped) and not IsPlayerFreeAiming(PlayerId()) and Helpers.LoadAnimDict(a.dict, 1200) then
                    TaskPlayAnim(ped, a.dict, a.name, 8.0, -8.0, 1100, a.flag or 49, 0.0, false, false, false)
                end
            end
        end)
    end
    ctx.wait(ctx.left() * 1000)
end)
