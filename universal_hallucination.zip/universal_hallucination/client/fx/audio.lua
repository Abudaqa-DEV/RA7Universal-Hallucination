--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/audio.lua - hallucinated sounds. Played by the NUI (WebAudio) with real stereo panning.
    The sound files are html/assets/sounds/<name>.ogg - replace any of them with your own (same name).
]]

Audio = {}

-- length in seconds of each shipped sound (used to follow a moving source while it plays)
Audio.Lengths = {
    heartbeat = 1.0, breathing = 4.0, whisper_1 = 2.4, whisper_2 = 2.8, whisper_3 = 2.2, footsteps = 5.0, knock = 1.8,
    phone_ring = 3.2, static = 3.0, drone = 8.0, music_box = 12.0, tinnitus = 6.0, gunshot_far = 1.6, gunshot = 1.1, success = 0.9, fail = 0.7, frost = 3.0,
    groan_1 = 1.6, groan_2 = 1.9, whoosh = 1.0, glitch = 0.6, blip = 0.06, notify = 0.5, jumpscare = 1.4,
    thump = 0.5, rumble = 4.0, breath_cold = 2.5, sting = 1.2,
    bullet_whiz = 0.55, ricochet = 0.9, body_hit = 0.8, flatline = 4.0, fly_buzz = 4.0, skitter = 3.0, gunshot_rifle = 1.5, gunshot_shotgun = 1.4,
}

local DIR_ANGLE = { behind = 180.0, left = 90.0, right = -90.0, front = 0.0 }

--- World position of a sound relative to the player: direction name -> x, y.
function Audio.PointFor(direction, dist)
    local px, py = Helpers.Coords()
    local rel
    if direction == 'random' or direction == 'around' or DIR_ANGLE[direction] == nil then
        rel = Utils.Rand(0.0, 360.0)
    else
        rel = DIR_ANGLE[direction] + Utils.Rand(-18.0, 18.0)
    end
    local h = (Helpers.CamHeading() + rel) % 360.0
    local vx, vy = Helpers.HeadingVec(h)
    dist = dist or Utils.Rand(4.0, 14.0)
    return px + vx * dist, py + vy * dist, dist
end

--- Plays a sound from a fixed point in the world. Pan and "muffled when behind" follow the camera while it plays.
---@return string id
function Audio.PlayAt(ctx, name, x, y, volume, opts)
    opts = opts or {}
    local id = ctx.id(name .. tostring(math.random(1, 99999)))
    local len = Audio.Lengths[name] or 2.0
    local px, py = Helpers.Coords()
    local d0 = Utils.Dist2(px, py, x, y)
    local function level()
        local px2, py2 = Helpers.Coords()
        local d = Utils.Dist2(px2, py2, x, y)
        return Utils.Clamp(volume * (1.0 - math.min(d, 40.0) / 55.0), 0.05, 1.0)
    end
    local pan, rear = Helpers.PanOf(x, y)
    UI.Sound(id, name, { volume = level(), pan = pan, rear = rear, rate = opts.rate, loop = opts.loop })
    if opts.loop or len > 0.4 then
        CreateThread(function()
            local untilT = GetGameTimer() + math.floor(len * 1000)
            while ctx.alive() and (opts.loop or GetGameTimer() < untilT) and not (opts.stop and opts.stop()) do
                local p, r = Helpers.PanOf(x, y)
                UI.SoundUpdate(id, p, level(), r)
                Wait(100)
            end
            if opts.stop and opts.stop() then UI.SoundStop(id, 0.3) end
            if opts.loop then UI.SoundStop(id, 0.5) end
        end)
    end
    return id
end

--- Plays a sound in the head (no direction).
function Audio.Play(ctx, name, volume, opts)
    local id = ctx.id(name .. tostring(math.random(1, 99999)))
    opts = opts or {}
    UI.Sound(id, name, { volume = volume, pan = 0.0, rate = opts.rate, loop = opts.loop, fade = opts.fade })
    return id
end

local function vol(ctx, base)
    return Utils.Clamp((tonumber(ctx.cfg.Volume) or 0.8) * (0.45 + 0.7 * ctx.intensity), 0.05, 1.0) * (base or 1.0)
end

--- Loop that stays alive with the session and follows live intensity.
local function loopFx(ctx, name, opts)
    opts = opts or {}
    local id = ctx.id(name)
    local function play()
        UI.Sound(id, name, {
            loop = true, volume = vol(ctx, opts.base), rate = opts.rate and opts.rate(ctx) or 1.0,
            fade = opts.fade or 1.5, pan = 0.0,
        })
    end
    play()
    ctx.onStop(function() UI.SoundStop(id, 0.6) end)
    if ctx.live then ctx.live(function() UI.SoundUpdate(id, 0.0, vol(ctx, opts.base), nil, opts.rate and opts.rate(ctx) or 1.0) end, true) end
    return id
end

--- Repeats a one-shot with random gaps.
local function repeatFx(ctx, names, dirKey, intervalDefault, volBase)
    local I = Helpers.IScale(ctx.intensity)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, intervalDefault, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
        local name = type(names) == 'table' and Utils.Pick(names) or names
        local x, y = Audio.PointFor(ctx.opt('Direction', 'direction') or dirKey)
        Audio.PlayAt(ctx, name, x, y, vol(ctx, volBase))
    end
end

Fx.Register('heartbeat', function(ctx)
    local rate = function(c) return 0.75 + 0.75 * c.intensity end
    loopFx(ctx, 'heartbeat', { rate = rate, fade = 0.8 })
    if ctx.cfg.Pulse ~= false then
        -- sudden spikes: the heart races for a few seconds
        while ctx.alive() do
            if not ctx.wait(math.random(9000, 17000)) then break end
            Visual.Kick('SMALL_EXPLOSION_SHAKE', 0.06 + 0.1 * ctx.intensity)
            UI.Send('pulse', { strength = 0.5 + 0.5 * ctx.intensity })
        end
    else
        ctx.wait(ctx.left() * 1000)
    end
end)

Fx.Register('breathing', function(ctx)
    loopFx(ctx, 'breathing', { rate = function(c) return 0.85 + 0.5 * c.intensity end })
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('static_noise', function(ctx)
    loopFx(ctx, 'static', { base = 0.7 })
    UI.Overlay(ctx.id('noise'), 'noise', true, { strength = 0.1 + 0.3 * ctx.intensity })
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('drone', function(ctx)
    loopFx(ctx, 'drone', { fade = 3.0 })
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('tinnitus', function(ctx)
    loopFx(ctx, 'tinnitus', { fade = 2.0, base = 0.8 })
    ctx.wait(ctx.left() * 1000)
end)

Fx.Register('whispers_audio', function(ctx)
    repeatFx(ctx, { 'whisper_1', 'whisper_2', 'whisper_3' }, 'around', 9.0)
end)

Fx.Register('knocking', function(ctx)
    repeatFx(ctx, 'knock', 'random', 14.0)
end)

Fx.Register('distant_gunshots', function(ctx)
    repeatFx(ctx, 'gunshot_far', 'random', 11.0, 0.9)
end)

Fx.Register('phone_ring', function(ctx)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, 20.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
        Audio.Play(ctx, 'phone_ring', vol(ctx))
        ctx.wait(3300)
    end
end)

Fx.Register('footsteps_behind', function(ctx)
    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(ctx.cfg.Interval, 16.0, 1.0 / Helpers.IScale(ctx.intensity)) * 1000)) then break end
        local x, y = Audio.PointFor(ctx.opt('Direction', 'direction') or 'behind', Utils.Rand(3.0, 7.0))
        local stop
        if ctx.cfg.StopWhenTurn ~= false then
            stop = function() return Helpers.IsInView(x, y, 30.0) end
        end
        Audio.PlayAt(ctx, 'footsteps', x, y, vol(ctx), { stop = stop })
        ctx.wait(5200)
    end
end)

Fx.Register('music_box', function(ctx)
    local x, y = Audio.PointFor(ctx.opt('Direction', 'direction') or 'around', Utils.Rand(5.0, 9.0))
    Audio.PlayAt(ctx, 'music_box', x, y, vol(ctx), { loop = true })
    ctx.wait(ctx.left() * 1000)
end)
