--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/fx/more.lua - echo (a copy of you walks your own old path), fake_lag (rubber-band / hitch), fake_wounds.
]]

local function IS(ctx) return Helpers.IScale(ctx.intensity) end

-- ----------------------------------------------------------------------
-- ECHO: a copy of the player that retraces the exact path he walked `Delay` seconds ago
-- ----------------------------------------------------------------------
Fx.Register('echo', function(ctx)
    local cfg = ctx.cfg
    local alpha = tonumber(ctx.opt('Alpha', 'alpha')) or 170
    local delay = Utils.Num(Utils.Range(cfg.Delay, 6.0), 6.0, 1.5, 40.0)
    local minGap = Utils.Num(cfg.MinGap, 4.0, 1.5, 30.0)
    local vanish = Utils.Num(cfg.VanishDistance, 2.0, 0.5, 10.0)
    local rest = Utils.Num(cfg.RestSeconds, 5.0, 0.5, 120.0)
    local trail, last = {}, nil
    local ped
    local nextSpawn = 0
    local lastPace = 0.0

    local function record()
        local x, y, z = Helpers.Coords()
        local h = GetEntityHeading(PlayerPedId())
        if last and Utils.Dist2(x, y, last.x, last.y) < 0.12 and math.abs(Helpers.AngleDiff(h, last.h)) < 4.0 then return end
        last = { t = GetGameTimer(), x = x, y = y, z = z, h = h }
        trail[#trail + 1] = last
        -- keep only what is needed
        local cut = GetGameTimer() - math.floor((delay + 6.0) * 1000)
        while #trail > 2 and trail[2].t < cut do table.remove(trail, 1) end
    end

    --- the point where the player was `delay` seconds ago (and the one right after, for the speed)
    local function pointThen()
        local at = GetGameTimer() - math.floor(delay * 1000)
        local a, b
        for i = 1, #trail do
            if trail[i].t <= at then a, b = trail[i], trail[i + 1] else break end
        end
        return a, b
    end

    local function paceOf(a, b)
        if not b then return 0.0 end
        local dt = (b.t - a.t) / 1000.0
        if dt <= 0.0 then return 0.0 end
        local v = Utils.Dist2(a.x, a.y, b.x, b.y) / dt
        if v < 0.4 then return 0.0 elseif v < 2.6 then return 1.0 elseif v < 5.8 then return 2.0 end
        return 3.0
    end

    while ctx.alive() do
        if Helpers.InVehicle() or Helpers.IsDead() then
            if ped then Ents.Delete(ctx.sid, ped) ped = nil ctx.phantom = nil end
            trail, last = {}, nil
            Wait(900)
        else
            record()
            local a, b = pointThen()
            if not Ents.Exists(ped) then
                ped = nil
                ctx.phantom = nil
                if a and GetGameTimer() >= nextSpawn and ctx.canSpawn() then
                    local mx, my = Helpers.Coords()
                    if Utils.Dist2(a.x, a.y, mx, my) >= minGap then
                        local source = ctx.opt('Source', 'source') or 'self'
                        local p = Ents.Look(ctx.sid, source, cfg.Models, ctx.subject, a.x, a.y, a.z, a.h, 0, ctx.params.model)
                        if p then
                            ped = p
                            ctx.phantom = p
                            for i = 1, 6 do Ents.Alpha(p, alpha * i / 6) Wait(60) end
                        end
                    end
                end
            elseif a then
                local d = Ents.Distance(ped)
                local mx, my = Helpers.Coords()
                local pc = GetEntityCoords(ped)
                if Utils.Dist2(pc.x, pc.y, a.x, a.y) > 14.0 then
                    SetEntityCoordsNoOffset(ped, a.x, a.y, a.z, false, false, false)
                else
                    local pace = paceOf(a, b)
                    local gap = Utils.Dist2(pc.x, pc.y, a.x, a.y)
                    -- no later point yet (the player stopped): keep going to the last place he stood at
                    if not b then pace = (lastPace > 0.0) and lastPace or 1.0 end
                    -- never stand still while far from the old path
                    if pace == 0.0 and gap > 1.2 then pace = 1.0 end
                    if b and pace > 0.0 then lastPace = pace end
                    if pace > 0.0 and gap > 0.45 then
                        TaskGoStraightToCoord(ped, a.x, a.y, a.z, pace, 600, a.h, 0.0)
                    elseif pace == 0.0 then
                        SetEntityHeading(ped, a.h)
                    end
                end
                if d <= vanish then
                    UI.Sound(ctx.id('whoosh' .. math.random(1, 9999)), 'whoosh', { volume = 0.4 })
                    Ents.FadeOut(ctx.sid, ped, 600)
                    ped = nil
                    ctx.phantom = nil
                    nextSpawn = GetGameTimer() + math.floor(rest * 1000)
                end
            end
            ctx.wait(150)
        end
    end
end)

-- ----------------------------------------------------------------------
-- FAKE LAG: the game "hitches": the character stops for a moment and may snap back a few metres
-- ----------------------------------------------------------------------
Fx.Register('fake_lag', function(ctx)
    local cfg = ctx.cfg
    local frozen = false
    ctx.onStop(function()
        if frozen then FreezeEntityPosition(PlayerPedId(), false) frozen = false end
    end)
    local function ok()
        local me = PlayerPedId()
        if Helpers.InVehicle() or Helpers.IsDead() then return false end
        if IsPedRagdoll(me) or IsPedClimbing(me) or IsPedFalling(me) or IsPedSwimming(me) or IsPedJumping(me) then return false end
        return GetEntitySpeed(me) >= Utils.Num(cfg.MinSpeed, 1.5, 0.0, 10.0)
    end

    while ctx.alive() do
        if not ctx.wait(math.floor(Utils.Range(cfg.Interval, 16.0, 1.0 / IS(ctx)) * 1000)) then break end
        if ok() then
            local me = PlayerPedId()
            local x, y, z = Helpers.Coords()
            local h = GetEntityHeading(me)
            UI.Flash('#FFFFFF', 50, 0.18)
            -- keep moving for a moment, then the "server" pulls him back
            if not ctx.wait(math.floor(Utils.Range(cfg.Lag, 0.8) * 1000)) then break end
            if ok() then
                local nx, ny = Helpers.Coords()
                local back = math.random() < Utils.Num(cfg.RubberChance, 0.6, 0.0, 1.0)
                if back and Utils.Dist2(x, y, nx, ny) <= Utils.Num(cfg.MaxBack, 8.0, 1.0, 30.0) then
                    SetEntityCoordsNoOffset(me, x, y, z, false, false, false)
                    SetEntityHeading(me, h)
                end
                frozen = true
                FreezeEntityPosition(me, true)
                UI.Flash('#FFFFFF', 70, 0.2)
                Wait(math.floor(Utils.Range(cfg.Freeze, 0.45) * 1000))
                FreezeEntityPosition(PlayerPedId(), false)
                frozen = false
            end
        end
    end
end)

-- ----------------------------------------------------------------------
-- FAKE WOUNDS: bruises and blood appear on his body one by one, and he starts limping
-- ----------------------------------------------------------------------
Fx.Register('fake_wounds', function(ctx)
    local cfg = ctx.cfg
    local packs = type(cfg.Packs) == 'table' and cfg.Packs or {}
    local total = math.max(1, math.floor((tonumber(cfg.Count) or 4) * (0.5 + IS(ctx) * 0.5) + 0.5))
    local gap = Utils.Num(cfg.GapSeconds, 5.0, 0.5, 60.0)
    local limping = false
    local applied = 0
    ctx.onStop(function()
        pcall(ClearPedBloodDamage, PlayerPedId())
        pcall(ResetPedVisibleDamage, PlayerPedId())
        if limping then
            pcall(ResetPedMovementClipset, PlayerPedId(), 0.4)
        end
    end)

    while ctx.alive() and applied < total and #packs > 0 do
        local me = PlayerPedId()
        pcall(ApplyPedDamagePack, me, Utils.Pick(packs), 0.0, 1.0)
        applied = applied + 1
        UI.Flash(Config.UI.BloodColor, 140, 0.4)
        Visual.Kick('SMALL_EXPLOSION_SHAKE', 0.15 + 0.2 * ctx.intensity)
        UI.Sound(ctx.id('pain' .. applied), 'breathing', { volume = 0.5, rate = 1.2 })
        if cfg.Limp ~= false and not limping and applied >= 2 and type(cfg.Clipset) == 'string' and Helpers.LoadClipSet(cfg.Clipset) then
            SetPedMovementClipset(me, cfg.Clipset, 0.5)
            limping = true
        end
        if not ctx.wait(math.floor(gap * 1000)) then break end
    end
    ctx.wait(ctx.left() * 1000)
end)
