--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/resist.lua - the resist mini-games.

    The logic runs here (controls are read from the game); the NUI only draws the state.
    The result goes to the server, which validates it (minimum time, cooldown, session ownership)
    and then lowers/raises the intensity or ends the hallucination.

      mash      press the key fast to fill the bar before it drains
      hold      breath control: hold the key to raise the marker, release to lower it, keep it in the zone
      timing    stop the needle inside the zone (3 rounds)
      sequence  press the arrows in the order shown
]]

Resist = {}

local running = false
local cooldownUntil = 0
local promptUntil = 0
local nextPrompt = 0

local function RKEY() return Utils.Num(Config.Resist.Key, 47, 0, 360) end

local ARROWS = {
    { code = 174, name = 'left' }, { code = 175, name = 'right' },
    { code = 172, name = 'up' },   { code = 173, name = 'down' },
}

local function now() return GetGameTimer() end

local function allowed(typeKey)
    local R = Config.Resist
    if not R.Enabled then return false end
    if Utils.Contains(R.Exclude, typeKey) then return false end
    local c = Config.Types[typeKey]
    if c and c.Resist == false then return false end
    return true
end

--- The most intense eligible session (the one the player is fighting).
local function pickSession()
    local best
    for _, ctx in pairs(Engine.sessions) do
        if allowed(ctx.type) and (not best or ctx.intensity > best.intensity) then best = ctx end
    end
    return best
end

local function settings(ctx)
    local o = type(ctx.cfg.Resist) == 'table' and ctx.cfg.Resist or {}
    local R = Config.Resist
    local games = R.Games
    local game = o.Game
    if not game then
        game = Utils.Pick(games) or 'mash'
    end
    return {
        game = game,
        difficulty = Utils.Clamp(tonumber(o.Difficulty) or tonumber(R.Difficulty) or 0.5, 0.0, 1.0)
            * (0.7 + 0.6 * ctx.intensity),
        seconds = Utils.Clamp(tonumber(R.GameSeconds) or 7, 3, 20),
    }
end

local function keyDown() return IsControlPressed(0, RKEY()) or IsDisabledControlPressed(0, RKEY()) end
local function keyHit() return IsControlJustPressed(0, RKEY()) or IsDisabledControlJustPressed(0, RKEY()) end

local function blockControls(game)
    DisableControlAction(0, RKEY(), true)
    if game == 'sequence' then
        for _, a in ipairs(ARROWS) do DisableControlAction(0, a.code, true) end
    end
end

-- ----------------------------------------------------------------------
-- Games: each returns true (won) / false (lost) / nil (cancelled), ticks at frame rate
-- ----------------------------------------------------------------------
local function push(state) UI.Send('resist', state) end

local GAMES = {}

GAMES.mash = function(st, alive)
    local needed = math.floor(12 + 20 * st.difficulty)
    local drain = 0.16 + 0.22 * st.difficulty
    local progress = 0.0
    local t0, last, lastPush = now(), now(), 0
    while alive() do
        local t = now()
        local dt = (t - last) / 1000.0
        last = t
        blockControls('mash')
        if keyHit() then
            progress = progress + 1.0 / needed
            UI.Send('resistTap', {})
        end
        progress = math.max(0.0, progress - drain * dt)
        local left = st.seconds - (t - t0) / 1000.0
        if t - lastPush > 40 then
            lastPush = t
            push({ game = 'mash', progress = progress, left = left, total = st.seconds })
        end
        if progress >= 1.0 then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

GAMES.hold = function(st, alive)
    local need = 2.6 + 2.0 * st.difficulty            -- seconds that must be spent inside the zone
    local width = 0.30 - 0.14 * st.difficulty
    local pos, inZone = 0.2, 0.0
    local t0, last, lastPush = now(), now(), 0
    local seed = math.random() * 6.28
    while alive() do
        local t = now()
        local dt = (t - last) / 1000.0
        last = t
        blockControls('hold')
        local e = (t - t0) / 1000.0
        local center = 0.5 + 0.28 * math.sin(e * (0.9 + 0.9 * st.difficulty) + seed) + 0.08 * math.sin(e * 2.3)
        local rise = keyDown() and (0.75 + 0.2 * st.difficulty) or -(0.55 + 0.2 * st.difficulty)
        pos = Utils.Clamp(pos + rise * dt, 0.0, 1.0)
        local inside = math.abs(pos - center) <= width / 2
        if inside then inZone = inZone + dt else inZone = math.max(0.0, inZone - dt * 0.6) end
        local left = st.seconds + 3.0 - e
        if t - lastPush > 40 then
            lastPush = t
            push({ game = 'hold', pos = pos, center = center, width = width, progress = inZone / need, inside = inside, left = left, total = st.seconds + 3.0 })
        end
        if inZone >= need then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

GAMES.timing = function(st, alive)
    local rounds, lives = 3, 2
    local hits = 0
    local t0, lastPush = now(), 0
    for round = 1, rounds do
        local width = 0.22 - 0.10 * st.difficulty - 0.02 * round
        local zone = Utils.Rand(0.25, 0.75)
        local speed = 0.9 + 0.8 * st.difficulty + 0.2 * round
        local phase = 0.0
        local last = now()
        local settled = false
        while alive() and not settled do
            local t = now()
            local dt = (t - last) / 1000.0
            last = t
            blockControls('timing')
            phase = phase + dt * speed * 2.0
            local needle = math.abs((phase % 2.0) - 1.0)    -- ping-pong 0..1..0
            local left = st.seconds * rounds * 0.7 - (t - t0) / 1000.0
            if t - lastPush > 40 then
                lastPush = t
                push({ game = 'timing', needle = needle, zone = zone, width = width, round = round, rounds = rounds, hits = hits, lives = lives, left = left })
            end
            if keyHit() then
                if math.abs(needle - zone) <= width / 2 then
                    hits = hits + 1
                    UI.Send('resistTap', { good = true })
                else
                    lives = lives - 1
                    UI.Send('resistTap', { good = false })
                    if lives <= 0 then return false end
                end
                settled = true
                Wait(350)
            end
            if left <= 0 then return false end
            Wait(0)
        end
        if not alive() then return nil end
    end
    return hits >= rounds - 0     -- every round hit (misses cost lives, but need all rounds cleared)
end

GAMES.sequence = function(st, alive)
    local n = math.floor(4 + 4 * st.difficulty)
    local seq = {}
    for i = 1, n do seq[i] = math.random(1, #ARROWS) end
    local idx = 1
    local t0, lastPush = now(), 0
    local lives = 1
    local list = {}
    for i, k in ipairs(seq) do list[i] = ARROWS[k].name end
    while alive() do
        local t = now()
        blockControls('sequence')
        local left = st.seconds + 2.0 - (t - t0) / 1000.0
        if t - lastPush > 60 then
            lastPush = t
            push({ game = 'sequence', seq = list, idx = idx, left = left, total = st.seconds + 2.0 })
        end
        for k, a in ipairs(ARROWS) do
            if IsDisabledControlJustPressed(0, a.code) or IsControlJustPressed(0, a.code) then
                if k == seq[idx] then
                    idx = idx + 1
                    UI.Send('resistTap', { good = true })
                else
                    lives = lives - 1
                    UI.Send('resistTap', { good = false })
                    if lives < 0 then return false end
                    idx = 1
                end
            end
        end
        if idx > n then return true end
        if left <= 0 then return false end
        Wait(0)
    end
end

-- ----------------------------------------------------------------------
-- Flow
-- ----------------------------------------------------------------------
function Resist.IsRunning() return running end

function Resist.Start(ctx)
    if running or not ctx then return false end
    running = true
    local sid = ctx.sid
    local st = settings(ctx)
    cooldownUntil = now() + math.floor(Config.Resist.Cooldown * 1000)
    UI.Send('resistOpen', { game = st.game, key = Config.Resist.KeyLabel, type = ctx.type, label = Locale('type_' .. ctx.type), seconds = st.seconds })
    local t0 = now()

    CreateThread(function()
        Wait(550)   -- let the UI appear before the clock starts
        t0 = now()
        local fn = GAMES[st.game] or GAMES.mash
        local ok, res = pcall(fn, st, function() return Engine.sessions[sid] ~= nil and not Helpers.IsDead() end)
        if not ok then Utils.Error('resist: ' .. tostring(res)) res = nil end
        local elapsed = now() - t0
        running = false
        if res == nil then
            UI.Send('resistClose', {})
            return
        end
        UI.Send('resistEnd', { ok = res == true })
        UI.Sound('resist_end', res and 'success' or 'fail', { volume = 0.7 })
        Wait(1400)
        UI.Send('resistClose', {})
        TriggerServerEvent('universal_halluc:server:resist', sid, res == true, math.floor(elapsed))
    end)
    return true
end

--- Server confirmed the result.
function Resist.Done(sid, success, ended)
    local c = Engine.Get and Engine.Get(sid)
    if c and c.type == 'takeover' then
        Notify.Key(success and 'takeover_round_ok' or 'takeover_round_fail', success and 'success' or 'error')
        return
    end
    Notify.Key(ended and 'resist_ended' or (success and 'resist_ok' or 'resist_fail'), success and 'success' or 'warning')
end

-- key / prompt loop
CreateThread(function()
    nextPrompt = now() + 30000
    while true do
        if not Config.Resist.Enabled or Engine.Count() == 0 then
            Wait(800)
        else
            local ctx = pickSession()
            if not ctx then
                Wait(800)
            else
                local t = now()
                local P = Config.Resist.Prompt
                -- automatic invitation
                if P and P.Enabled and not running and t >= nextPrompt and t >= cooldownUntil then
                    nextPrompt = t + math.floor(Utils.Range(P.Every, 55.0) * 1000)
                    if ctx.intensity >= 0.25 then
                        promptUntil = t + math.floor((tonumber(P.Seconds) or 8) * 1000)
                        UI.Send('resistPrompt', { on = true, key = Config.Resist.KeyLabel, seconds = tonumber(P.Seconds) or 8 })
                        UI.Sound('resist_prompt', 'heartbeat', { volume = 0.6, rate = 1.5 })
                    end
                end
                if promptUntil > 0 and t > promptUntil then
                    promptUntil = 0
                    UI.Send('resistPrompt', { on = false })
                end
                -- key
                if not running and not State.panel and (IsControlJustPressed(0, RKEY())) then
                    if t >= cooldownUntil then
                        promptUntil = 0
                        UI.Send('resistPrompt', { on = false })
                        Resist.Start(ctx)
                    else
                        Notify.Key('resist_cooldown', 'inform', 2500, math.ceil((cooldownUntil - t) / 1000))
                    end
                end
                Wait(0)
            end
        end
    end
end)
