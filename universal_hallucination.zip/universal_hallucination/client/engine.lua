--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/engine.lua - runs one session per hallucination: context, threads, automatic cleanup.

    A handler (Fx.Register) receives a `ctx`:
        ctx.sid, ctx.type, ctx.cfg, ctx.intensity (0..1), ctx.subject, ctx.controlled, ctx.params
        ctx.alive()            -> false once the session is stopped or expired
        ctx.left()             -> seconds left
        ctx.wait(ms)           -> sleeps in small steps, returns ctx.alive()
        ctx.thread(fn)         -> CreateThread that is wrapped in pcall and stops with the session
        ctx.onStop(fn)         -> cleanup callback (runs in reverse order, always)
        ctx.opt(Name, name)    -> value from the start params (lowercase name) or the type config (Name)
        ctx.id(suffix)         -> NUI id owned by this session (cleared automatically)
        ctx.finish()           -> ends the session from inside the handler
        ctx.canSpawn()         -> false when entities are not allowed right now (driving, dead...)
]]

Engine = { sessions = {} }

local function now() return GetGameTimer() end

local function buildCtx(sid, typeKey, data)
    local cfg = Config.Types[typeKey] or {}
    local ctx = {
        sid = sid, type = typeKey, cfg = cfg,
        intensity = Utils.Clamp(tonumber(data.intensity) or cfg.Intensity or 0.5, 0.0, 1.0),
        subject = tonumber(data.subject),
        controlled = data.controlled == true,
        params = type(data.params) == 'table' and data.params or {},
        endsAt = now() + math.floor((tonumber(data.duration) or cfg.Duration or 30) * 1000),
        stopped = false,
        stops = {},
        updaters = {},
    }

    function ctx.alive() return not ctx.stopped and now() < ctx.endsAt end
    function ctx.left() return math.max(0.0, (ctx.endsAt - now()) / 1000.0) end

    function ctx.wait(ms)
        local target = now() + ms
        while ctx.alive() and now() < target do
            Wait(math.max(0, math.min(100, target - now())))
        end
        return ctx.alive()
    end

    function ctx.thread(fn)
        CreateThread(function()
            local ok, err = pcall(fn)
            if not ok then Utils.Error(('%s (session %s): %s'):format(typeKey, tostring(sid), tostring(err))) end
        end)
    end

    function ctx.onStop(fn) ctx.stops[#ctx.stops + 1] = fn end

    --- Registers a function that re-applies the effect when the intensity changes live (resist / Director).
    function ctx.live(fn, skipNow)
        ctx.updaters[#ctx.updaters + 1] = fn
        if not skipNow then pcall(fn) end
    end

    function ctx.opt(name, lower)
        local v = ctx.params[lower or name:lower()]
        if v == nil then v = ctx.params[name] end
        if v == nil then v = cfg[name] end
        return v
    end

    function ctx.id(suffix) return ('s%d:%s'):format(sid, suffix or ctx.type) end

    function ctx.finish() Engine.Stop(sid, true) end

    function ctx.canSpawn()
        if not ctx.alive() then return false end
        if Config.Safety.NoEntitiesWhileDriving and Helpers.InVehicle() then return false end
        if Helpers.IsDead() then return false end
        return true
    end

    return ctx
end

--- Starts a session from the server's `client:start` event.
function Engine.Start(sid, typeKey, data)
    if type(sid) ~= 'number' or type(typeKey) ~= 'string' or type(data) ~= 'table' then return end
    if Engine.sessions[sid] then Engine.Stop(sid, false) end

    local handler = Fx.handlers[typeKey]
    if not handler then
        Utils.Warn('no client effect for type ' .. typeKey)
        TriggerServerEvent('universal_halluc:server:ended', sid)
        return
    end

    local ctx = buildCtx(sid, typeKey, data)
    Engine.sessions[sid] = ctx
    Utils.Debug('start', sid, typeKey, ctx.intensity)

    ctx.thread(function() handler(ctx) end)
end

--- Stops one session and removes everything it created.
function Engine.Stop(sid, tellServer)
    local ctx = Engine.sessions[sid]
    if not ctx then return end
    Engine.sessions[sid] = nil
    ctx.stopped = true
    for i = #ctx.stops, 1, -1 do
        local ok, err = pcall(ctx.stops[i])
        if not ok then Utils.Debug('cleanup error', tostring(err)) end
    end
    ctx.stops = {}
    Ents.CleanSession(sid)
    if Dialogue then Dialogue.CleanSession(sid) end
    UI.Send('clearSession', { prefix = ('s%d:'):format(sid) })
    if tellServer then TriggerServerEvent('universal_halluc:server:ended', sid) end
end

function Engine.StopAll(tellServer)
    local ids = {}
    for sid in pairs(Engine.sessions) do ids[#ids + 1] = sid end
    for _, sid in ipairs(ids) do Engine.Stop(sid, tellServer) end
    -- anything that might still be left
    Ents.CleanAll()
    if Visual and Visual.Reset then Visual.Reset() end
    UI.ClearAll()
end

--- Live intensity change from the server (resist mini-game, /hadjust, panel slider).
function Engine.Update(sid, intensity)
    local ctx = Engine.sessions[sid]
    if not ctx then return end
    ctx.intensity = Utils.Clamp(tonumber(intensity) or ctx.intensity, 0.0, 1.0)
    for _, fn in ipairs(ctx.updaters) do pcall(fn) end
end

function Engine.Count()
    local n = 0
    for _ in pairs(Engine.sessions) do n = n + 1 end
    return n
end

function Engine.Get(sid) return Engine.sessions[sid] end

--- Sessions expire here; a dead player ends everything.
CreateThread(function()
    while true do
        Wait(250)
        if next(Engine.sessions) then
            local dead = Config.Safety.StopOnDeath and Helpers.IsDead()
            local ids = {}
            for sid, ctx in pairs(Engine.sessions) do
                if dead or now() >= ctx.endsAt then ids[#ids + 1] = sid end
            end
            for _, sid in ipairs(ids) do Engine.Stop(sid, true) end
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    Engine.StopAll(false)
    if State.panel then SetNuiFocus(false, false) end
    ClearTimecycleModifier()
    SetTimeScale(1.0)
end)
