--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/dialogue.lua - talking with an imaginary person.

      Dialogue.Say(sid, text, seconds)   one line (from the Director or a script)
      Dialogue.Run(ctx, dialogueId)      scripted tree from Config.Dialogues (blocks until finished)
      Dialogue.OpenReply(sid)            small typed reply box (NUI focus)

    Choices are picked with the number keys 1-4.
]]

Dialogue = {}

local KEYS = { 157, 158, 160, 164 }   -- 1 2 3 4
local current = nil                    -- { sid, token }
local token = 0

local function speakerOf(ctx, d)
    if d and d.Speaker then return Utils.Text(d.Speaker) end
    local nm = ctx and ctx.cfg and ctx.cfg.Name
    if nm then return Utils.Text(nm) end
    return Locale('type_' .. (ctx and ctx.type or 'friend'))
end

local function phantomOf(ctx)
    return ctx and ctx.phantom and Ents.Exists(ctx.phantom) and ctx.phantom or nil
end

--- Keeps the speech bubble glued above the phantom's head while a line is shown.
local function followBubble(ctx, id, text, myToken)
    if Config.UI.Bubble.Enabled == false then return end
    CreateThread(function()
        local sent = false
        local lx, ly = -1, -1
        while current and current.token == myToken do
            local ped = phantomOf(ctx)
            if ped then
                local c = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
                local onScreen, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z + 0.35)
                if onScreen then
                    local ix, iy = math.floor(sx * 1000), math.floor(sy * 1000)
                    if not sent then
                        UI.Bubble(id, text, sx, sy)
                        sent = true
                    elseif ix ~= lx or iy ~= ly then
                        UI.Send('bubblePos', { id = id, x = sx, y = sy })
                    end
                    lx, ly = ix, iy
                else
                    if sent then UI.BubbleHide(id) sent = false end
                end
            end
            Wait(0)
        end
        UI.BubbleHide(id)
    end)
end

local function hide(sid)
    if current and (sid == nil or current.sid == sid) then
        current = nil
        UI.DialogueHide()
    end
end

function Dialogue.CleanSession(sid)
    hide(sid)
end

--- One line of speech. `choices` is an optional list of { Text = }.
local function show(ctx, text, seconds, speaker, choices, hint)
    token = token + 1
    local my = token
    current = { sid = ctx.sid, token = my }
    local list
    if choices then
        list = {}
        for i, c in ipairs(choices) do
            if i > 4 then break end
            list[#list + 1] = { n = i, text = Utils.Text(c.Text) }
        end
    end
    UI.Dialogue({
        speaker = Config.UI.Dialogue.ShowSpeaker and speaker or '',
        text = text, seconds = seconds, choices = list, hint = hint,
        typeSpeed = Config.UI.Dialogue.TypeSpeed, token = my,
    })
    if ctx.opt and ctx.cfg and ctx.cfg.Speech ~= false then
        UI.Sound(ctx.id('blip'), 'blip', { volume = 0.35 })
    end
    followBubble(ctx, ctx.id('bubble'), text, my)
    return my
end

--- A single line (Director /hsay).
function Dialogue.Say(sid, text, seconds, speaker)
    local ctx = Engine.Get(sid)
    if not ctx or type(text) ~= 'string' or text == '' then return end
    seconds = Utils.Clamp(tonumber(seconds) or Config.Director.LineSeconds, 2.0, 30.0)
    local hint = ctx.controlled and Locale('ui_hint_reply', Config.Commands.Reply or 'hr') or nil
    local my = show(ctx, text, seconds, speaker or speakerOf(ctx), nil, hint)
    CreateThread(function()
        Wait(math.floor(seconds * 1000))
        if current and current.token == my then hide(sid) end
    end)
end

--- Scripted dialogue tree. Blocks the calling thread; returns when the dialogue ends or the session dies.
function Dialogue.Run(ctx, dialogueId)
    local d = Config.Dialogues[dialogueId]
    if type(d) ~= 'table' or type(d.Nodes) ~= 'table' then return end
    local nodeId = d.Start
    local guard = 0
    while nodeId and ctx.alive() and guard < 40 do
        guard = guard + 1
        local node = d.Nodes[nodeId]
        if not node then break end
        local text = Utils.Text(node.Text)
        local choices = (type(node.Choices) == 'table' and #node.Choices > 0) and node.Choices or nil
        local delay = Utils.Clamp(tonumber(node.Delay) or 5.0, 1.0, 60.0)
        local my = show(ctx, text, choices and 0 or delay, speakerOf(ctx, d), choices, choices and Locale('ui_hint_choose') or nil)

        if choices then
            local picked
            while ctx.alive() and not picked and current and current.token == my do
                for i = 1, math.min(#choices, 4) do
                    if IsControlJustPressed(0, KEYS[i]) or IsDisabledControlJustPressed(0, KEYS[i]) then picked = i break end
                end
                Wait(0)
            end
            if not picked then break end
            TriggerServerEvent('universal_halluc:server:choice', ctx.sid, dialogueId, nodeId, picked)
            UI.Send('dialogueChoice', { n = picked })
            Wait(450)
            nodeId = choices[picked].Next
            if not nodeId then break end
        else
            if not ctx.wait(math.floor(delay * 1000) + 300) then break end
            if node.End then break end
            nodeId = node.Next
        end
    end
    hide(ctx.sid)
end

-- ----------------------------------------------------------------------
-- Typed reply box (NUI focus)
-- ----------------------------------------------------------------------
local replyFor = nil

function Dialogue.OpenReply(sid)
    if State.panel or replyFor then return end
    replyFor = sid
    SetNuiFocus(true, true)
    UI.Send('replyOpen', { sid = sid, max = Config.Director.ReplyMaxLength })
end

local function closeReply()
    if not replyFor then return end
    replyFor = nil
    if not State.panel then SetNuiFocus(false, false) end
    UI.Send('replyClose', {})
end

RegisterNUICallback('reply', function(data, cb)
    cb({ ok = true })
    local sid = replyFor
    closeReply()
    if sid and type(data) == 'table' and type(data.text) == 'string' then
        local text = data.text:gsub('^%s+', ''):gsub('%s+$', '')
        if text ~= '' then TriggerServerEvent('universal_halluc:server:reply', sid, text:sub(1, Config.Director.ReplyMaxLength)) end
    end
end)

RegisterNUICallback('replyClose', function(_, cb)
    cb({ ok = true })
    closeReply()
end)
