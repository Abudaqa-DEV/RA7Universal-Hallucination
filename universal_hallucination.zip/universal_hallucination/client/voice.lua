--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/voice.lua - lets the controller's real microphone be heard around ANOTHER player (the "possessed" target).
    Uses pma-voice's proximity override when present, or Custom.Voice.SpeakAs(targetServerId, range) from bridge/custom.lua.
]]

VoiceClient = { target = nil }

local function around(targetServerId, range)
    return function(player)
        local tp = GetPlayerFromServerId(targetServerId)
        if not tp or tp == -1 then return false end
        local tped, pped = GetPlayerPed(tp), GetPlayerPed(player)
        if not tped or tped == 0 or not pped or pped == 0 then return false end
        local a, b = GetEntityCoords(tped), GetEntityCoords(pped)
        return Utils.Dist3(a.x, a.y, a.z, b.x, b.y, b.z) <= range
    end
end

function VoiceClient.SpeakAs(targetServerId)
    local V = Config.Voice or {}
    if not V.Enabled then return end
    if targetServerId == nil then
        VoiceClient.target = nil
        if V.Provider == 'custom' then
            if Custom and Custom.Voice and Custom.Voice.SpeakAs then pcall(Custom.Voice.SpeakAs, nil, 0) end
        else
            pcall(function() exports['pma-voice']:resetProximityCheck() end)
        end
        return
    end
    targetServerId = tonumber(targetServerId)
    if not targetServerId then return end
    VoiceClient.target = targetServerId
    local range = tonumber(V.SpeakAsRange) or 12.0
    if V.Provider == 'custom' then
        if Custom and Custom.Voice and Custom.Voice.SpeakAs then pcall(Custom.Voice.SpeakAs, targetServerId, range) end
    else
        local ok, err = pcall(function() exports['pma-voice']:overrideProximityCheck(around(targetServerId, range)) end)
        if not ok then Utils.Warn('speak-as voice override failed (use Provider = "custom"): ' .. tostring(err)) end
    end
end

RegisterNetEvent('universal_halluc:client:voiceAs', function(target)
    if target ~= nil and type(target) ~= 'number' then return end
    VoiceClient.SpeakAs(target)
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and VoiceClient.target then VoiceClient.SpeakAs(nil) end
end)

-- ----------------------------------------------------------------------
-- Isolate: my microphone is heard ONLY by `controllerServerId` (the takeover target). nil = back to normal.
-- Without a voice provider the safe fallback is to mute the microphone completely.
-- ----------------------------------------------------------------------
local isolated = false

local function mute(on)
    if Custom and type(Custom.Mute) == 'function' then pcall(Custom.Mute, on) return end
    pcall(NetworkSetVoiceActive, not on)
end

function VoiceClient.Isolate(controllerServerId)
    local V = Config.Voice or {}
    if controllerServerId == nil then
        if not isolated then return end
        isolated = false
        if V.Enabled then
            if V.Provider == 'custom' then
                if Custom and Custom.Voice and Custom.Voice.Isolate then pcall(Custom.Voice.Isolate, nil) end
            else
                pcall(function() exports['pma-voice']:resetProximityCheck() end)
            end
        else
            mute(false)
        end
        return
    end
    controllerServerId = tonumber(controllerServerId)
    if not controllerServerId then return end
    isolated = true
    if not V.Enabled then mute(true) return end
    if V.Provider == 'custom' then
        if Custom and Custom.Voice and Custom.Voice.Isolate then pcall(Custom.Voice.Isolate, controllerServerId) else mute(true) end
    else
        local ok = pcall(function()
            exports['pma-voice']:overrideProximityCheck(function(player)
                return GetPlayerServerId(player) == controllerServerId
            end)
        end)
        if not ok then mute(true) end
    end
end

RegisterNetEvent('universal_halluc:client:voiceIsolate', function(controller)
    if controller ~= nil and type(controller) ~= 'number' then return end
    VoiceClient.Isolate(controller)
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and isolated then VoiceClient.Isolate(nil) end
end)
