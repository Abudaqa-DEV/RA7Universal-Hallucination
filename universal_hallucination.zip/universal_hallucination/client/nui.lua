--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/nui.lua - the single gateway to the NUI (overlay + admin panel).
]]

UI = {}

local ready = false
local queue = {}
local last = {}          -- last payload per "keyed" message, to avoid resending identical data

local function post(action, data)
    SendNUIMessage({ action = action, data = data })
end

--- Sends a message to the NUI. Messages are queued until the page says it is ready.
--- `key` (optional) de-duplicates identical consecutive payloads for the same key.
function UI.Send(action, data, key)
    if key then
        local enc = json.encode(data or {})
        if last[key] == enc then return end
        last[key] = enc
    end
    if not ready then
        queue[#queue + 1] = { action, data }
        if #queue > 80 then table.remove(queue, 1) end
        return
    end
    post(action, data)
end

function UI.Forget(key) last[key] = nil end

local function dir()
    local d = Config.UI.Direction
    if d == 'rtl' or d == 'ltr' then return d end
    return Config.General.Language == 'ar' and 'rtl' or 'ltr'
end

function UI.Rtl() return dir() == 'rtl' end

--- All UI words the page needs: every locale key starting with ui_ / type_ / cat_ / sc_ (no hard-coded text in the NUI).
local function uiTexts()
    local out = {}
    local function take(set)
        for k, v in pairs(set or {}) do
            if type(k) == 'string' and (k:sub(1, 3) == 'ui_' or k:sub(1, 5) == 'type_' or k:sub(1, 4) == 'cat_') then
                out[k] = v
            end
        end
    end
    take(Locales['en'])
    take(Locales[Config.General.Language])
    return out
end

function UI.Config()
    local B = Config.Brand
    return {
        brand = {
            name = B.ScriptName, server = B.ServerName,
            dev = Config.General.Developer, discord = Config.General.Discord, version = Config.General.Version,
            colors = B.Colors,
        },
        lang = Config.General.Language,
        rtl = UI.Rtl(),
        font = Config.UI.Font, fontSize = Config.UI.FontSize,
        dialogue = Config.UI.Dialogue,
        bubble = Config.UI.Bubble.Enabled ~= false,
        talkHint = Config.UI.TalkHint ~= false,
        bloodColor = Config.UI.BloodColor,
        sounds = { enabled = Config.Sounds.Enabled ~= false, master = Config.Sounds.Master },
        panelRefresh = Config.Panel.RefreshMs,
        texts = uiTexts(),
    }
end

function UI.Init()
    UI.Send('config', UI.Config())
end

--- Called by the NUI page when it finishes loading.
RegisterNUICallback('ready', function(_, cb)
    ready = true
    post('config', UI.Config())
    for i = 1, #queue do post(queue[i][1], queue[i][2]) end
    queue = {}
    cb({ ok = true })
end)

-- ----------------------------------------------------------------------
-- Convenience wrappers (overlay, no focus)
-- ----------------------------------------------------------------------
function UI.Notify(message, ntype, duration)
    if Config.UI.Enabled == false then return end
    UI.Send('notify', { message = tostring(message or ''), type = ntype or 'inform', duration = duration or Config.Notifications.Duration })
end

--- Full-screen / HUD style overlays: kind = tint | vignette | bugs | blood | scanlines | noise
function UI.Overlay(id, kind, on, opts)
    UI.Send('overlay', { id = id, kind = kind, on = on == true, opts = opts or {} })
end

function UI.Flash(color, ms, alpha)
    UI.Send('flash', { color = color or '#FFFFFF', ms = ms or 120, alpha = alpha or 0.9 })
end

function UI.Word(text, x, y, ms, size)
    UI.Send('word', { text = text, x = x, y = y, ms = ms or 2200, size = size })
end

function UI.Sound(id, name, opts)
    if not (Config.Sounds.Enabled ~= false) then return end
    local o = opts or {}
    o.id, o.name = id, name
    UI.Send('sound', o)
end

function UI.SoundUpdate(id, pan, volume, rear, rate)
    UI.Send('soundUpdate', { id = id, pan = pan, volume = volume, rear = rear, rate = rate })
end

function UI.SoundStop(id, fade)
    UI.Send('soundStop', { id = id, fade = fade or 0.25 })
end

function UI.SoundStopAll()
    UI.Send('soundStop', { all = true, fade = 0.2 })
end

function UI.ClearAll()
    UI.Send('clear', {})
    last = {}
end

function UI.Hint(text, key, show)
    UI.Send('hint', { text = text, key = key, show = show == true }, 'hint')
end

function UI.Bubble(id, text, x, y, scale)
    UI.Send('bubble', { id = id, text = text, x = x, y = y, scale = scale, on = text ~= nil })
end

function UI.BubbleHide(id)
    UI.Send('bubble', { id = id, on = false })
end

function UI.Dialogue(data)
    UI.Send('dialogue', data)
end

function UI.DialogueHide()
    UI.Send('dialogueHide', {})
end

-- ----------------------------------------------------------------------
-- Panel focus
-- ----------------------------------------------------------------------
function UI.PanelOpen(payload)
    State.panel = true
    SetNuiFocus(true, true)
    UI.Send('panelOpen', payload)
end

function UI.PanelClose()
    if not State.panel then return end
    State.panel = false
    SetNuiFocus(false, false)
    post('panelClose', {})
end
