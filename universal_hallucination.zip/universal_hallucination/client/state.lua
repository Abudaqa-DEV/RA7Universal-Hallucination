--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/6EkqysEwD | Copyright (c) Ra7 DEV
    client/state.lua - shared client state and the effect registry.
]]

State = {
    ready   = false,   -- the server knows this client is loaded
    optout  = false,   -- the player disabled command hallucinations (/hoff)
    panel   = false,   -- the admin panel is open (NUI focus)
}

--- Effect handlers: Fx.Register('ghost', function(ctx) ... end)
Fx = { handlers = {} }

function Fx.Register(typeKey, fn)
    Fx.handlers[typeKey] = fn
end

function Fx.Has(typeKey)
    return Fx.handlers[typeKey] ~= nil
end

--- Persisted opt-out (so /hoff survives reconnects).
local KVP = 'universal_halluc:optout'

function State.LoadOptOut()
    local ok, v = pcall(GetResourceKvpString, KVP)
    State.optout = ok and v == '1'
    return State.optout
end

function State.SaveOptOut(v)
    State.optout = v == true
    pcall(SetResourceKvp, KVP, State.optout and '1' or '0')
end
