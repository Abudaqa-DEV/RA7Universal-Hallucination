--[[
    Universal Hallucination | Ra7 DEV | Dev by: Abudaqa
    Discord: https://discord.gg/Zk5CrhHYe | Copyright (c) Ra7 DEV
    client/fx/jumpscare.lua - the jump scare as a REAL PED (an NPC in the world), not a picture.

    A local, harmless zombie/ghost ped (the same looks as the zombie horde: wounds, blood, mood) shows up for ONE
    player only, in one of three styles, with a white flash, the scream and a camera kick at the moment it hits:
      pop     appears right in front of you, 2-4 m away, stares for a moment, then lunges
      rush    appears far ahead and sprints straight at you
      behind  appears right behind you; the scare lands when you turn around (or after a few seconds)
    It vanishes the moment it reaches you. It never hurts, never blocks, never exists for anyone else.
    Config.Jumpscare.Mode = 'ped' (default) | 'image' (old picture/face on screen) | 'both'.
    If no ped can be placed (no model, no free spot) the scare still lands as flash + scream + shake: never silent.
]]

Jumpscare = {}

local busy = false

local function J() return type(Config.Jumpscare) == 'table' and Config.Jumpscare or {} end

--- 'ped' | 'image' | 'both'
function Jumpscare.Mode()
    local m = J().Mode
    if m == 'image' or m == 'both' then return m end
    return 'ped'
end

local STYLE_DEFAULTS = {
    pop    = { Weight = 4, Distance = { min = 2.4, max = 3.6 }, Stay = 0.8, Speed = 3.0 },
    rush   = { Weight = 4, Distance = { min = 12.0, max = 20.0 }, Speed = 3.0 },
    behind = { Weight = 3, Distance = { min = 1.8, max = 2.6 }, Wait = 2.5, Speed = 3.0 },
}
local ORDER = { 'pop', 'rush', 'behind' }

local function styleCfg(name)
    local S = J().Styles
    local c = type(S) == 'table' and S[name]
    return type(c) == 'table' and c or STYLE_DEFAULTS[name]
end

--- Weighted pick of a style. `forced` (a name) wins when it exists.
function Jumpscare.PickStyle(forced, inVehicle)
    if forced and STYLE_DEFAULTS[forced] then
        if forced == 'behind' and inVehicle then return 'pop' end
        return forced
    end
    local total, list = 0, {}
    for _, n in ipairs(ORDER) do
        local c = styleCfg(n)
        local w = (type(c) == 'table' and c.Enabled ~= false) and math.max(0, tonumber(c.Weight) or 0) or 0
        if n == 'behind' and inVehicle then w = 0 end
        if w > 0 then total = total + w; list[#list + 1] = { n, w } end
    end
    if total <= 0 then return 'pop' end
    local r = math.random() * total
    for _, e in ipairs(list) do
        r = r - e[2]
        if r <= 0 then return e[1] end
    end
    return list[#list][1]
end

--- A look name from Config.Jumpscare.Looks (empty = any look of the zombie horde).
local function pickLook()
    local list = J().Looks
    local forced
    if type(list) == 'table' and #list > 0 then forced = Utils.Pick(list) end
    return Realism.PickLook(forced)
end

local function models(look)
    if look and type(look.Models) == 'table' and #look.Models > 0 then return look.Models end
    local Z = (Config.Realism or {}).Zombies or {}
    if type(Z.Models) == 'table' and #Z.Models > 0 then return Z.Models end
    return { 'u_m_y_zombie_01' }
end

local seq = 0

--- The moment it hits: white flash, the hit + scream, camera kick (and the picture only in image/both mode).
function Jumpscare.Burst(ctx, I, quiet)
    seq = seq + 1
    UI.Flash('#FFFFFF', 90, 0.9)
    if not quiet then
        UI.Sound(ctx.id('js' .. seq), 'jumpscare', { volume = 1.0 })
        if Config.Sounds.Layered ~= false then UI.Sound(ctx.id('jx' .. seq), 'shriek', { volume = 0.55 }) end
    end
    Visual.Kick('LARGE_EXPLOSION_SHAKE', 0.35 + 0.4 * I)
    if Jumpscare.Mode() ~= 'ped' then UI.Send('cue', { name = 'jumpscare', seconds = 1.4, strength = I }) end
end

local function vanish(ctx, ped, I)
    Ents.Delete(ctx.sid, ped)
    UI.Flash(Config.UI.BloodColor, 110, 0.55)
    Visual.Kick('SMALL_EXPLOSION_SHAKE', 0.3 + 0.25 * I)
    UI.Sound(ctx.id('jv' .. seq), 'whoosh', { volume = 0.6 })
end

--- Sends the ped at the player. Returns true when it reached him.
local function lunge(ctx, ped, vname, speed, vanishD, untilT, I)
    local lastTask, last = 0, GetGameTimer()
    while ctx.alive() and Ents.Exists(ped) and GetGameTimer() < untilT and not Helpers.IsDead() do
        local now = GetGameTimer()
        local dt = math.min(0.2, (now - last) / 1000.0)
        last = now
        local d = Ents.Distance(ped)
        if d <= vanishD then return true end
        local mx, my, mz = Helpers.Coords()
        local c = GetEntityCoords(ped)
        local hd = Helpers.HeadingTo(c.x, c.y, mx, my)
        if vname == 'crawler' then
            -- lies in the writhing animation and is moved by script (same as in the horde)
            local vx, vy = Helpers.HeadingVec(hd)
            local sp = 3.2 * dt
            local nx, ny = c.x + vx * sp, c.y + vy * sp
            SetEntityHeading(ped, hd)
            SetEntityCoordsNoOffset(ped, nx, ny, (Helpers.GroundZ(nx, ny, c.z) or c.z) + 0.05, false, false, false)
        elseif now - lastTask > 250 then
            lastTask = now
            SetEntityHeading(ped, hd)
            TaskGoStraightToCoord(ped, mx, my, mz, speed, 700, hd, 0.0)
        end
        Wait(30)
    end
    return false
end

--- Only fails (returns false) when no ped could be placed.
local function runPed(ctx, sec, I, styleName, opts)
    local inVeh = Helpers.InVehicle()
    local style = Jumpscare.PickStyle(styleName, inVeh)
    local sc = styleCfg(style) or {}
    local lookName, look = pickLook()
    local lo = (sc.Distance and tonumber(sc.Distance.min)) or STYLE_DEFAULTS[style].Distance.min
    local hi = (sc.Distance and tonumber(sc.Distance.max)) or STYLE_DEFAULTS[style].Distance.max
    local spotOpts
    if style == 'pop' then spotOpts = { angle = { min = -22.0, max = 22.0 }, maxZDiff = 3.0 }
    elseif style == 'rush' then spotOpts = { angle = { min = -35.0, max = 35.0 }, maxZDiff = 5.0 }
    else spotOpts = { behind = true, maxZDiff = 3.0 } end
    local x, y, z, h = Helpers.PickSpot(lo, hi, spotOpts)
    if not x then return false end

    local ped = Ents.Look(ctx.sid, 'model', models(look), nil, x, y, z, h, 0, nil)
    if not ped then return false end
    local vname = Realism.Dress(ped, look)
    if vname ~= 'crawler' then
        ClearPedTasksImmediately(ped)
        pcall(ResetPedMovementClipset, ped, 0.0)      -- a drunk/limping gait must not slow the lunge: it sprints
    end
    SetEntityHeading(ped, h)

    local speed = Utils.Clamp(tonumber(sc.Speed) or 3.0, 1.0, 3.0)
    local vanishD = Utils.Clamp(tonumber(J().VanishDistance) or 1.3, 0.8, 3.0)
    local deadline = GetGameTimer() + math.floor(sec * 1000)
    local reached = false

    if style == 'behind' then
        -- stands right behind you, staring; the scare lands when you turn around or after a few seconds
        UI.Sound(ctx.id('jb' .. seq), 'breath_cold', { volume = 0.8 })
        TaskLookAtEntity(ped, PlayerPedId(), 6000, 2048, 3)
        local t0 = GetGameTimer()
        local maxWait = math.floor(Utils.Clamp(tonumber(sc.Wait) or 2.5, 0.5, 10.0) * 1000)
        while ctx.alive() and Ents.Exists(ped) and GetGameTimer() < deadline do
            local waited = GetGameTimer() - t0
            if waited >= maxWait or (waited > 500 and Helpers.IsLookingAt(ped, 55.0)) then break end
            Wait(50)
        end
        if not Ents.Exists(ped) then return true end
        Ents.Alpha(ped, 255)
        Jumpscare.Burst(ctx, I, opts.quiet)
        reached = lunge(ctx, ped, vname, speed, vanishD, math.min(deadline, GetGameTimer() + 1100), I)
    else
        -- pop / rush: it appears (alpha 0 -> 255 in one frame, together with the flash and the scream)
        Ents.Alpha(ped, 255)
        Jumpscare.Burst(ctx, I, opts.quiet)
        local untilT = deadline
        if style == 'pop' then
            -- it stands there staring for `Stay` seconds (face to face), then lunges
            local stay = Utils.Clamp(tonumber(opts.stay) or tonumber(sc.Stay) or 0.8, 0.1, 6.0)
            local t0 = GetGameTimer()
            TaskLookAtEntity(ped, PlayerPedId(), 3000, 2048, 3)
            while ctx.alive() and Ents.Exists(ped) and GetGameTimer() - t0 < math.floor(stay * 1000) and GetGameTimer() < deadline do
                Ents.Face(ped, Helpers.Coords())
                Wait(40)
            end
            untilT = math.min(deadline, GetGameTimer() + 1500)
        end
        reached = lunge(ctx, ped, vname, speed, vanishD, untilT, I)
    end
    if Ents.Exists(ped) then vanish(ctx, ped, I) end
    return true
end

--- The jump scare. `ctx` is a cue context (Cue.Ctx). Non-blocking: runs in its own thread.
---@param opts table|nil  { style = 'pop'|'rush'|'behind', stay = seconds, quiet = bool }
function Jumpscare.Play(ctx, sec, I, opts)
    opts = opts or {}
    I = Utils.Clamp(tonumber(I) or 0.8, 0.1, 1.0)
    sec = Utils.Clamp(tonumber(sec) or 5.0, 1.0, 30.0)
    if Jumpscare.Mode() == 'image' then
        Jumpscare.Burst(ctx, I, opts.quiet)
        return
    end
    if Helpers.IsDead() then return end      -- nothing is shown to a dead player
    busy = true
    CreateThread(function()
        local ok, placed = pcall(runPed, ctx, sec, I, opts.style, opts)
        if not ok then Utils.Error('jumpscare: ' .. tostring(placed)) end
        if not ok or not placed then
            -- no ped could be placed: the scare still lands (flash + scream + shake), never silent, never a crash
            Jumpscare.Burst(ctx, I, opts.quiet)
            if J().Fallback == 'image' and Jumpscare.Mode() == 'ped' then UI.Send('cue', { name = 'jumpscare', seconds = 1.4, strength = I }) end
        end
        pcall(Ents.CleanSession, ctx.sid)
        busy = false
    end)
end

--- A short ped scare for the resist games (a spike). Skipped when a jump scare is already running.
function Jumpscare.Spike(I)
    if busy or Jumpscare.Mode() == 'image' or not Cue or not Cue.Ctx then return false end
    Jumpscare.Play(Cue.Ctx(2.5, I or 0.7), 2.5, I or 0.7, { style = 'pop', stay = 0.45, quiet = true })
    return true
end

function Jumpscare.Busy() return busy end
